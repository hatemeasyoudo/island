import SwiftUI
import Combine

/// Живая кошка в приложении: дышит, ходит по комнате, следит за игрушкой,
/// мурчит, мяукает, сопит во сне. Всё считается покадрово (60 кадров/с).
struct AnimatedCatView: View {
    let state: PetAttributes.ContentState

    // ходьба
    @State private var fromX: CGFloat = 0
    @State private var toX: CGFloat = 0
    @State private var moveStart: Date = .distantPast
    @State private var moveDuration: Double = 2.2
    @State private var facingLeft = false
    // когда началось текущее занятие (для миски с кормом)
    @State private var activityStart = Date()

    private let wanderTimer = Timer.publish(every: 3.8, on: .main, in: .common).autoconnect()

    var body: some View {
        TimelineView(.animation) { tl in
            GeometryReader { g in
                scene(now: tl.date, size: g.size)
            }
        }
        .animation(.easeInOut(duration: 0.7), value: state.activity)
        .onReceive(wanderTimer) { _ in wander() }
        .onChange(of: state.activity) { _, _ in activityStart = Date() }
    }

    // MARK: - Кадр

    @ViewBuilder
    private func scene(now: Date, size: CGSize) -> some View {
        let t = now.timeIntervalSinceReferenceDate
        let a = state.activity
        let w = min(size.width * 0.62, size.height * 0.92)
        let floorY = size.height - 10

        // ходьба: плавный разгон и торможение + подпрыгивающая походка
        let mp: Double = min(1, max(0, now.timeIntervalSince(moveStart) / moveDuration))
        let ease = CGFloat(mp * mp * (3 - 2 * mp))
        let walking = mp > 0 && mp < 1
        let x: CGFloat = size.width / 2 + fromX + (toX - fromX) * ease
        let hop: CGFloat = walking ? CGFloat(abs(sin(mp * .pi * 5)) * 7) : 0

        // дыхание: во сне медленнее и глубже
        let period: Double = a == .sleep ? 4.4 : 3.1
        let depth: Double = a == .sleep ? 0.024 : 0.012
        let breath = CGFloat(1 + depth * sin(t * 2 * .pi / period))
        // лёгкое покачивание, мурчание, подпрыгивания при мяуканье
        let sway: Double = a.canWalk && !walking ? 1.4 * sin(t * 2 * .pi / 6.5) : 0
        let purr: CGFloat = a == .loved ? CGFloat(0.9 * sin(t * 95)) : 0
        let meowJump: CGFloat = a == .meow ? CGFloat(pow(max(0, sin(t * 2 * .pi / 1.5)), 3) * 9) : 0
        let eatNod: CGFloat = a == .eat ? CGFloat(abs(sin(t * 2 * .pi / 1.1)) * 3) : 0
        let shadowW: CGFloat = w * 0.66 * (1 - (hop + meowJump) / 60)

        ZStack {
            // тень сжимается, когда кошка подпрыгивает
            Ellipse()
                .fill(Color.black.opacity(0.35))
                .frame(width: shadowW, height: w * 0.07)
                .blur(radius: 7)
                .position(x: x, y: floorY - 4)

            Image(a.imageName)
                .resizable()
                .scaledToFit()
                .frame(width: w, height: w, alignment: .bottom)
                .scaleEffect(x: facingLeft && a.canWalk ? -1 : 1, y: breath, anchor: .bottom)
                .rotationEffect(.degrees(sway), anchor: .bottom)
                .offset(x: purr, y: -hop - meowJump + eatNod)
                .position(x: x, y: floorY - w / 2)
                .id(a.photo)
                .transition(.asymmetric(
                    insertion: .opacity.combined(with: .scale(scale: 0.92, anchor: .bottom)),
                    removal: .opacity))

            if a == .eat {
                let left: Double = max(0.1, 1 - now.timeIntervalSince(activityStart) / CatBrain.eatDuration)
                BowlView(fill: left)
                    .frame(width: w * 0.36, height: w * 0.18)
                    .position(x: x + w * 0.22, y: floorY - w * 0.08)
                    .transition(.scale.combined(with: .opacity))
            }

            if a == .play, let toy = state.toy {
                toyView(toy, t: t, x: x, w: w, floorY: floorY, roomWidth: size.width)
            }

            effects(a, t: t, x: x, w: w, floorY: floorY)
        }
    }

    // MARK: - Игрушка: каждая двигается по-своему

    @ViewBuilder
    private func toyView(_ toy: CatToy, t: Double, x: CGFloat, w: CGFloat, floorY: CGFloat, roomWidth: CGFloat) -> some View {
        let range = min(roomWidth * 0.35, 130)
        switch toy {
        case .butterfly:
            // порхает восьмёркой над головой, крылышки машут
            let bx: CGFloat = x + range * CGFloat(sin(t * 0.9))
            let by: CGFloat = floorY - w + CGFloat(22 * sin(t * 1.8))
            let flap = CGFloat(0.55 + 0.45 * abs(sin(t * 14)))
            Image(toy.imageName).resizable().scaledToFit()
                .frame(width: 40, height: 40)
                .scaleEffect(x: flap, y: 1)
                .rotationEffect(.degrees(10 * sin(t * 1.8)))
                .position(x: bx, y: by)
        case .feather:
            // плавно парит и покачивается
            let fx: CGFloat = x - w * 0.35 + CGFloat(30 * sin(t * 0.7))
            let fy: CGFloat = floorY - w * 0.95 + CGFloat(18 * sin(t * 1.3))
            Image(toy.imageName).resizable().scaledToFit()
                .frame(width: 46, height: 46)
                .rotationEffect(.degrees(25 * sin(t * 1.3)))
                .position(x: fx, y: fy)
        default:
            // клубок, мышка, мячик — прыгают и катаются перед ней
            let px: CGFloat = x + range * 0.8 * CGFloat(sin(t * 1.25))
            let bounce = CGFloat(abs(sin(t * 2.5)) * 38)
            let spin: Double = t * 140 * (cos(t * 1.25) >= 0 ? 1 : -1)
            Image(toy.imageName).resizable().scaledToFit()
                .frame(width: 40, height: 40)
                .rotationEffect(.degrees(spin))
                .position(x: px, y: floorY - 20 - bounce)
        }
    }

    // MARK: - Эффекты: z Z, сердечки, «Мяу!»

    @ViewBuilder
    private func effects(_ a: CatActivity, t: Double, x: CGFloat, w: CGFloat, floorY: CGFloat) -> some View {
        switch a {
        case .sleep:
            ForEach(0..<3, id: \.self) { i in
                let p: Double = (t / 3.2 + Double(i) / 3).truncatingRemainder(dividingBy: 1)
                let zx: CGFloat = x + w * 0.22 + CGFloat(26 * p + 6 * sin(p * 9))
                let zy: CGFloat = floorY - w * 0.55 - CGFloat(80 * p)
                Text(i == 2 ? "Z" : "z")
                    .font(.system(size: CGFloat(13 + 13 * p), weight: .heavy, design: .rounded))
                    .foregroundStyle(Color(hex: 0xAEB8F0).opacity(sin(p * .pi)))
                    .position(x: zx, y: zy)
            }
        case .loved:
            ForEach(0..<4, id: \.self) { i in
                let p: Double = (t / 2.6 + Double(i) / 4).truncatingRemainder(dividingBy: 1)
                let side: CGFloat = i % 2 == 0 ? 1 : -1
                let hx: CGFloat = x + side * (w * 0.25 + CGFloat(10 * sin(p * 7)))
                let hy: CGFloat = floorY - w * 0.6 - CGFloat(90 * p)
                Image(systemName: "heart.fill")
                    .font(.system(size: CGFloat(12 + 10 * p)))
                    .foregroundStyle(Color(hex: 0xF48FB1).opacity(sin(p * .pi)))
                    .position(x: hx, y: hy)
            }
        case .meow:
            Text("Мяу!")
                .font(.system(size: 20, weight: .heavy, design: .rounded))
                .foregroundStyle(Color(hex: 0x3A3634))
                .padding(.horizontal, 12)
                .padding(.vertical, 5)
                .background(Capsule().fill(Color.white))
                .scaleEffect(CGFloat(1 + 0.1 * pow(max(0, sin(t * 2 * .pi / 1.5)), 3)))
                .position(x: x + w * 0.42, y: floorY - w * 0.95)
        default:
            EmptyView()
        }
    }

    // MARK: - Прогулки

    private func wander() {
        guard state.activity.canWalk else { return }
        let now = Date()
        // ещё идёт — не перебиваем
        if now.timeIntervalSince(moveStart) < moveDuration { return }
        // иногда просто стоит
        if Double.random(in: 0...1) < 0.35 { return }
        let current = toX
        var target = CGFloat.random(in: -95...95)
        if abs(target - current) < 40 { target = current > 0 ? current - 80 : current + 80 }
        fromX = current
        toX = target
        facingLeft = target < current
        moveDuration = Double(abs(target - current)) / 70 + 0.9
        moveStart = now
    }
}
