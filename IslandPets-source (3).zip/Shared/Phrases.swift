import Foundation

enum Phrases {
    static func list(for activity: CatActivity) -> [String] {
        switch activity {
        case .look:
            return ["*смотрит на тебя*", "Мур?", "*медленно моргает* — это значит «люблю»",
                    "Что делаешь?", "*внимательно наблюдает*", "*наклоняет голову*"]
        case .play:
            return ["Поймала!", "Это моё!", "*охотится*", "Тыгыдык!", "*прыг!*"]
        case .rest:
            return ["*лежит красиво*", "Я отдыхаю. Не мешай", "*потягивается*", "Жизнь удалась"]
        case .sleep:
            return ["Zzz…", "*сопит*", "*дёргает лапкой во сне*", "Мр-р… zzz"]
        case .meow:
            return ["МЯУ!", "Мяу! Мяу! Еды!", "Покорми меня!", "Мя-я-яу!!!"]
        case .eat:
            return ["Ням-ням!", "Вкуснотища!", "*хрум-хрум*"]
        case .loved:
            return ["Мур-р-р…", "*мурчит*", "Ещё!", "*трётся о руку*"]
        }
    }

    /// Предсказуемый выбор фразы: приложение и виджет показывают одно и то же.
    static func pick(for activity: CatActivity, seed: UInt64) -> String {
        let l = list(for: activity)
        return l[Int(seed % UInt64(l.count))]
    }
}
