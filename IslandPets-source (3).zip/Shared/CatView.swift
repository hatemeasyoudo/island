import SwiftUI

/// Кошка (её фото) с тенью, игрушкой, миской и подписями — для виджетов и островка.
/// Смена позы плавно растворяется (iOS анимирует переход между кадрами виджета).
/// small = true — маленькие картинки (для островка).
struct CatScene: View {
    let state: PetAttributes.ContentState
    var small: Bool = false
    var showEffects: Bool = true

    var body: some View {
        GeometryReader { g in
            let w = min(g.size.width, g.size.height)
            let cx = g.size.width / 2
            let floorY = g.size.height / 2 + w / 2
            ZStack {
                // мягкая тень
                Ellipse()
                    .fill(Color.black.opacity(0.32))
                    .frame(width: w * 0.68, height: w * 0.07)
                    .blur(radius: w * 0.025)
                    .position(x: cx, y: floorY - w * 0.035)

                Image(small ? state.activity.islandImageName : state.activity.imageName)
                    .resizable()
                    .scaledToFit()
                    .frame(width: w, height: w, alignment: .bottom)
                    .position(x: cx, y: floorY - w / 2)
                    .id(state.activity.photo)
                    .transition(.opacity.combined(with: .scale(scale: 0.95, anchor: .bottom)))

                if state.activity == .eat {
                    BowlView()
                        .frame(width: w * 0.38, height: w * 0.19)
                        .position(x: cx + w * 0.2, y: floorY - w * 0.1)
                }

                if state.activity == .play, let toy = state.toy {
                    Image(toy.imageName)
                        .resizable()
                        .scaledToFit()
                        .frame(width: w * 0.24, height: w * 0.24)
                        .rotationEffect(.degrees(-15))
                        .position(x: cx - w * 0.3, y: floorY - w * 0.88)
                }

                if showEffects {
                    switch state.activity {
                    case .sleep:
                        Text("z Z")
                            .font(.system(size: max(8, w * 0.12), weight: .heavy, design: .rounded))
                            .foregroundStyle(Color(hex: 0xAEB8F0))
                            .position(x: cx + w * 0.3, y: floorY - w * 0.72)
                    case .meow:
                        Text("Мяу!")
                            .font(.system(size: max(8, w * 0.1), weight: .heavy, design: .rounded))
                            .foregroundStyle(Color(hex: 0x3A3634))
                            .padding(.horizontal, w * 0.04)
                            .padding(.vertical, w * 0.015)
                            .background(Capsule().fill(Color.white))
                            .position(x: cx + w * 0.3, y: floorY - w * 0.9)
                    case .loved:
                        Text("💕")
                            .font(.system(size: max(8, w * 0.13)))
                            .position(x: cx + w * 0.34, y: floorY - w * 0.85)
                    default:
                        EmptyView()
                    }
                }
            }
            .frame(width: g.size.width, height: g.size.height)
        }
    }
}

/// Её мордочка — для маленьких мест (компактный островок, экран блокировки).
struct CatHead: View {
    let activity: CatActivity

    var body: some View {
        Image(activity.headImageName)
            .resizable()
            .scaledToFit()
            .id(activity.headImageName)
            .transition(.opacity)
    }
}

/// Металлическая миска с кормом. fill — сколько корма осталось (0…1).
struct BowlView: View {
    var fill: Double = 1

    var body: some View {
        GeometryReader { g in
            let w = g.size.width, h = g.size.height
            ZStack {
                // корм
                Ellipse()
                    .fill(Color(hex: 0x8A5A34))
                    .frame(width: w * 0.8, height: h * (0.16 + 0.22 * max(0, min(1, fill))))
                    .position(x: w / 2, y: h * 0.32)
                Ellipse()
                    .fill(Color(hex: 0xB07A4A).opacity(0.8))
                    .frame(width: w * 0.5, height: h * 0.1 * max(0.2, fill))
                    .position(x: w * 0.45, y: h * 0.27)
                // миска
                BowlShape()
                    .fill(LinearGradient(colors: [Color(hex: 0xEEF2F7), Color(hex: 0x8794A3)],
                                         startPoint: .top, endPoint: .bottom))
                BowlShape()
                    .stroke(Color(hex: 0x5D6672), lineWidth: max(1, h * 0.03))
                // блик
                Capsule()
                    .fill(Color.white.opacity(0.55))
                    .frame(width: w * 0.35, height: h * 0.06)
                    .position(x: w * 0.4, y: h * 0.62)
            }
        }
    }
}

struct BowlShape: Shape {
    func path(in r: CGRect) -> Path {
        var p = Path()
        let w = r.width, h = r.height
        p.move(to: CGPoint(x: r.minX, y: r.minY + h * 0.3))
        p.addCurve(to: CGPoint(x: r.minX + w * 0.5, y: r.maxY),
                   control1: CGPoint(x: r.minX + w * 0.02, y: r.minY + h * 0.85),
                   control2: CGPoint(x: r.minX + w * 0.22, y: r.maxY))
        p.addCurve(to: CGPoint(x: r.maxX, y: r.minY + h * 0.3),
                   control1: CGPoint(x: r.minX + w * 0.78, y: r.maxY),
                   control2: CGPoint(x: r.maxX - w * 0.02, y: r.minY + h * 0.85))
        p.addQuadCurve(to: CGPoint(x: r.minX, y: r.minY + h * 0.3),
                       control: CGPoint(x: r.minX + w * 0.5, y: r.minY + h * 0.62))
        p.closeSubpath()
        return p
    }
}
