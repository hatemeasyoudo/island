import Foundation
import ActivityKit
import SwiftUI

/// Чем кошка сейчас занята.
enum CatActivity: String, Codable, Hashable {
    case look, rest, play, sleep, meow, eat, loved

    /// Какое её фото показывать
    var photo: String {
        switch self {
        case .look, .loved: return "look"
        case .rest, .eat: return "lying"
        case .play: return "up"
        case .sleep: return "sleep"
        case .meow: return "meow"
        }
    }

    var imageName: String { "photo_" + photo }        // большая картинка
    var islandImageName: String { "isl_" + photo }    // маленькая — для островка

    var headImageName: String {
        switch self {
        case .sleep: return "face_sleep"
        case .meow: return "face_meow"
        case .play: return "face_up"
        default: return "face_look"
        }
    }

    var emoji: String {
        switch self {
        case .look: return "👀"
        case .rest: return "😌"
        case .play: return "🧶"
        case .sleep: return "💤"
        case .meow: return "📢"
        case .eat: return "🐟"
        case .loved: return "💕"
        }
    }

    func status(toy: CatToy?) -> String {
        switch self {
        case .look: return "Смотрит на тебя"
        case .rest: return "Отдыхает"
        case .play: return "Играет \(toy?.withName ?? "")".trimmingCharacters(in: .whitespaces)
        case .sleep: return "Спит"
        case .meow: return "Мяукает! Покорми её"
        case .eat: return "Кушает"
        case .loved: return "Мурчит"
        }
    }

    var symbol: String {
        switch self {
        case .look: return "eye.fill"
        case .rest: return "sofa.fill"
        case .play: return "sparkles"
        case .sleep: return "moon.zzz.fill"
        case .meow: return "speaker.wave.3.fill"
        case .eat: return "fork.knife"
        case .loved: return "heart.fill"
        }
    }

    /// Может ли в этом занятии ходить по комнате
    var canWalk: Bool { self == .look || self == .loved || self == .play }
}

/// Игрушки, которые появляются рядом с кошкой.
enum CatToy: String, Codable, Hashable, CaseIterable {
    case yarn, mouse, butterfly, feather, ball

    var imageName: String { "toy_" + rawValue }

    var withName: String {
        switch self {
        case .yarn: return "с клубком"
        case .mouse: return "с мышкой"
        case .butterfly: return "с бабочкой"
        case .feather: return "с пёрышком"
        case .ball: return "с мячиком"
        }
    }
}

/// Что может сделать человек.
enum PetAction: String, Codable {
    case feed, pet, play
}

/// Данные Live Activity. ContentState — то, что меняется со временем.
struct PetAttributes: ActivityAttributes {
    public struct ContentState: Codable, Hashable {
        var name: String
        var activity: CatActivity
        var toy: CatToy?
        var phrase: String
        /// Место в виджете: 0 — слева, 1 — по центру, 2 — справа
        var spot: Int
    }

    /// Когда запущена эта Live Activity (iOS держит её ~8 часов).
    var startedAt: Date
}

extension Color {
    init(hex: UInt32) {
        self.init(
            .sRGB,
            red: Double((hex >> 16) & 0xFF) / 255,
            green: Double((hex >> 8) & 0xFF) / 255,
            blue: Double(hex & 0xFF) / 255,
            opacity: 1
        )
    }

    static let catAccent = Color(hex: 0xA9BC5C)   // цвет её глаз
}
