import WidgetKit
import SwiftUI
import AppIntents

// MARK: - Кнопки в виджете

/// Действие из виджета. Выполняется в самом виджете, приложение открывать не нужно.
struct WidgetPetIntent: AppIntent {
    static var title: LocalizedStringResource = "Позаботиться о кошке (виджет)"
    static var isDiscoverable: Bool = false

    @Parameter(title: "Действие")
    var action: String

    init() {}

    init(action: PetAction) {
        self.action = action.rawValue
    }

    func perform() async throws -> some IntentResult {
        if let a = PetAction(rawValue: action) {
            CatBrain().apply(a, at: Date())
        }
        return .result() // после этого iOS сама перерисует виджет
    }
}

// MARK: - Расписание кадров

struct PetEntry: TimelineEntry {
    let date: Date
    let state: PetAttributes.ContentState
}

struct PetProvider: TimelineProvider {
    func placeholder(in context: Context) -> PetEntry {
        PetEntry(date: Date(), state: .preview)
    }

    func getSnapshot(in context: Context, completion: @escaping (PetEntry) -> Void) {
        let now = Date()
        completion(PetEntry(date: now, state: CatBrain().state(at: now)))
    }

    func getTimeline(in context: Context, completion: @escaping (Timeline<PetEntry>) -> Void) {
        // Расписание на 8 часов вперёд: сон, игры, лоток, мяуканье наступают сами
        let frames = CatBrain().timeline(from: Date(), hours: 8)
        let entries = frames.map { PetEntry(date: $0.0, state: $0.1) }
        completion(Timeline(entries: entries, policy: .atEnd))
    }
}

// MARK: - Вид виджета

struct PetWidgetView: View {
    @Environment(\.widgetFamily) private var family
    let entry: PetEntry

    var body: some View {
        let s = entry.state
        switch family {
        case .accessoryCircular:
            ZStack {
                AccessoryWidgetBackground()
                CatHead(activity: s.activity).padding(6)
            }
            .containerBackground(for: .widget) { Color.clear }

        case .accessoryRectangular:
            HStack(spacing: 8) {
                CatHead(activity: s.activity)
                    .frame(width: 40, height: 40)
                VStack(alignment: .leading, spacing: 1) {
                    Text("\(s.name) \(s.activity.emoji)")
                        .font(.headline)
                        .lineLimit(1)
                    Text(s.activity.status(toy: s.toy))
                        .font(.caption)
                        .lineLimit(2)
                }
                Spacer(minLength: 0)
            }
            .containerBackground(for: .widget) { Color.clear }

        case .systemSmall:
            VStack(spacing: 4) {
                HStack {
                    Text(s.name).font(.caption.weight(.bold)).lineLimit(1)
                    Spacer(minLength: 0)
                    Text(s.activity.emoji).font(.caption)
                }
                CatScene(state: s)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .animation(.easeInOut(duration: 0.8), value: s.activity)
                WidgetActionRow(compact: true)
            }
            .foregroundStyle(.white)
            .containerBackground(for: .widget) { roomBackground }

        default: // medium и large — комната, по которой она переходит
            VStack(alignment: .leading, spacing: 6) {
                HStack(alignment: .firstTextBaseline) {
                    Text(s.name).font(.headline)
                    Text(s.activity.emoji)
                    Spacer(minLength: 0)
                    Text(s.phrase)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                }
                GeometryReader { g in
                    let size = min(g.size.height, g.size.width * 0.45)
                    let xs: [CGFloat] = [size * 0.55, g.size.width / 2, g.size.width - size * 0.55]
                    CatScene(state: s)
                        .frame(width: size, height: size)
                        .position(x: xs[max(0, min(2, s.spot))], y: g.size.height - size / 2)
                        // переход на новое место и смена позы — плавно
                        .animation(.smooth(duration: 1.2), value: s.spot)
                        .animation(.easeInOut(duration: 0.8), value: s.activity)
                }
                if family == .systemLarge {
                    StatusLine(state: s)
                }
                WidgetActionRow(compact: false)
            }
            .foregroundStyle(.white)
            .containerBackground(for: .widget) { roomBackground }
        }
    }

    private var roomBackground: some View {
        ZStack(alignment: .bottom) {
            LinearGradient(colors: [Color(hex: 0x3A2E58), Color(hex: 0x1A1428)],
                           startPoint: .top, endPoint: .bottom)
            // «пол»
            Rectangle()
                .fill(Color(hex: 0x2A2140))
                .frame(height: 40)
        }
    }
}

struct WidgetActionRow: View {
    let compact: Bool

    var body: some View {
        HStack(spacing: compact ? 4 : 6) {
            button(.feed, "Еда", "fork.knife")
            button(.pet, "Гладить", "hand.raised.fill")
            button(.play, "Играть", "sparkles")
        }
        .tint(.catAccent)
    }

    @ViewBuilder
    private func button(_ action: PetAction, _ title: String, _ icon: String) -> some View {
        Button(intent: WidgetPetIntent(action: action)) {
            if compact {
                Image(systemName: icon)
                    .font(.caption)
                    .frame(maxWidth: .infinity)
            } else {
                Label(title, systemImage: icon)
                    .font(.caption2.weight(.semibold))
                    .frame(maxWidth: .infinity)
            }
        }
        .buttonStyle(.bordered)
    }
}

// MARK: - Сам виджет

struct PetHomeWidget: Widget {
    let kind = "PetHomeWidget"

    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: PetProvider()) { entry in
            PetWidgetView(entry: entry)
        }
        .configurationDisplayName("Кошечка")
        .description("Живёт своей жизнью: спит, отдыхает, играет и иногда мяукает.")
        .supportedFamilies([.systemSmall, .systemMedium, .systemLarge, .accessoryRectangular, .accessoryCircular])
    }
}
