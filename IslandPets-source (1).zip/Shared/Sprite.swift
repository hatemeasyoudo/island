import CoreGraphics

/// Размеры картинок в общих единицах (сидящая кошка ≈ 273 единицы в высоту).
enum Sprite {
    static let sizes: [String: CGSize] = [
        "cat_back1": CGSize(width: 66, height: 95),
        "cat_back2": CGSize(width: 67, height: 95),
        "cat_back3": CGSize(width: 67, height: 95),
        "cat_belly": CGSize(width: 150, height: 121),
        "cat_sit": CGSize(width: 207, height: 274),
        "cat_sleep": CGSize(width: 161, height: 94),
        "face_angry": CGSize(width: 125, height: 108),
        "face_curious": CGSize(width: 119, height: 116),
        "face_happy": CGSize(width: 126, height: 125),
        "face_neutral": CGSize(width: 132, height: 120),
        "face_sad": CGSize(width: 122, height: 114),
        "face_sleepy": CGSize(width: 122, height: 108),
        "face_surprised": CGSize(width: 121, height: 123),
        "face_wink": CGSize(width: 131, height: 120),
        "fx_anger": CGSize(width: 35, height: 35),
        "fx_heart": CGSize(width: 41, height: 33),
        "fx_paw": CGSize(width: 25, height: 25),
        "fx_sparkle": CGSize(width: 30, height: 34),
        "fx_zzz": CGSize(width: 51, height: 34),
    ]

    /// Рамка, в которую влезает любая поза
    static let box = CGSize(width: 420, height: 320)

    static func size(_ name: String) -> CGSize { sizes[name] ?? CGSize(width: 200, height: 200) }
}
