import AppIntents
import ActivityKit

/// Кнопки в Dynamic Island и на экране блокировки.
/// LiveActivityIntent выполняется в процессе приложения (в фоне),
/// поэтому приложение само меняет состояние и обновляет островок.
struct PetActionIntent: LiveActivityIntent {
    static var title: LocalizedStringResource = "Позаботиться о кошке"
    static var description = IntentDescription("Покормить, погладить или поиграть с кошкой.")

    @Parameter(title: "Действие (feed, pet, play)")
    var action: String

    init() {}

    init(action: PetAction) {
        self.action = action.rawValue
    }

    func perform() async throws -> some IntentResult {
        #if !WIDGET_EXTENSION
        if let a = PetAction(rawValue: action) {
            await PetEngine.shared.perform(a, canStart: false)
        }
        #endif
        return .result()
    }
}
