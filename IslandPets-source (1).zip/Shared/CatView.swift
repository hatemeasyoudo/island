import SwiftUI

/// Одна картинка-спрайт в общем масштабе (scale — пунктов на «пиксель листа»).
struct SpriteImage: View {
    let name: String
    let scale: CGFloat
    var flipped: Bool = false

    var body: some View {
        let s = Sprite.size(name)
        Image(name)
            .resizable()
            .interpolation(.high)
            .frame(width: s.width * scale, height: s.height * scale)
            .scaleEffect(x: flipped ? -1 : 1, y: 1)
    }
}

/// Один масштаб для всех поз: сколько пунктов на единицу Sprite, чтобы любая поза влезла.
func catScale(in size: CGSize) -> CGFloat {
    min(size.height / Sprite.box.height, size.width / Sprite.box.width)
}

extension CatActivity {
    /// Позы, которые можно отражать по направлению взгляда
    var flippable: Bool { self == .play || self == .curious || self == .stretch || self == .sleep || self == .loved }
}

extension PetAttributes.ContentState {
    var spriteName: String { walking ? "walk3" : activity.sprite }
    var flipped: Bool { facingLeft && (walking || activity.flippable) }
}

/// Кошка с тенью, игрушкой, миской и значками — для виджетов и островка.
/// Все позы в одном масштабе. Смена позы и места плавно анимируется.
/// small = true — облегчённые картинки (островок и экран блокировки).
struct CatScene: View {
    let state: PetAttributes.ContentState
    var showEffects: Bool = true
    var small: Bool = false

    var body: some View {
        GeometryReader { g in
            let a = state.activity
            let k = catScale(in: g.size)
            let name = state.spriteName
            let sz = Sprite.size(name)
            let cw = sz.width * k, ch = sz.height * k
            let cx = g.size.width / 2
            let floor = g.size.height
            let top = floor - ch
            let unit = Sprite.box.height * k

            ZStack {
                Ellipse()
                    .fill(Color.black.opacity(0.3))
                    .frame(width: cw * 0.75, height: max(3, unit * 0.05))
                    .blur(radius: 3)
                    .position(x: cx, y: floor - max(2, unit * 0.025))

                Image(small ? "isl_" + name : name)
                    .resizable()
                    .interpolation(.high)
                    .frame(width: cw, height: ch)
                    .scaleEffect(x: state.flipped ? -1 : 1, y: 1)
                    .position(x: cx, y: floor - ch / 2)
                    .id(name + (state.flipped ? "L" : "R"))
                    .transition(.opacity.combined(with: .scale(scale: 0.96, anchor: .bottom)))

                if !state.walking {
                    if a == .eat {
                        BowlView()
                            .frame(width: cw * 0.7, height: cw * 0.3)
                            .position(x: cx, y: floor - cw * 0.12)
                    }

                    if a == .play, let toy = state.toy, !small {
                        let dir: CGFloat = state.facingLeft ? -1 : 1
                        Image(toy.imageName)
                            .resizable()
                            .scaledToFit()
                            .frame(width: unit * 0.22, height: unit * 0.22)
                            .rotationEffect(.degrees(-15))
                            .position(x: cx + dir * cw * 0.55, y: floor - unit * 0.11)
                    }

                    if showEffects {
                        let fx = unit * 0.24
                        switch a {
                        case .sleep:
                            fxImage("fx_zzz", height: fx)
                                .position(x: cx + cw * 0.35, y: top - fx * 0.2)
                        case .loved:
                            fxImage("fx_heart", height: fx * 0.7)
                                .position(x: cx + cw * 0.42, y: top + fx * 0.2)
                        case .meow:
                            if state.angry {
                                fxImage("fx_anger", height: fx * 0.7)
                                    .position(x: cx + cw * 0.42, y: top + fx * 0.3)
                            } else {
                                Text("Мяу!")
                                    .font(.system(size: max(8, unit * 0.11), weight: .heavy, design: .rounded))
                                    .foregroundStyle(Color(hex: 0x3A3634))
                                    .padding(.horizontal, unit * 0.04)
                                    .padding(.vertical, unit * 0.012)
                                    .background(Capsule().fill(Color.white))
                                    .position(x: cx + cw * 0.5, y: top + unit * 0.06)
                            }
                        case .stretch, .curious:
                            fxImage("fx_sparkle", height: fx * 0.55)
                                .position(x: cx - cw * 0.42, y: top + fx * 0.3)
                        default:
                            EmptyView()
                        }
                    }
                }
            }
            .frame(width: g.size.width, height: g.size.height)
        }
    }

    private func fxImage(_ name: String, height: CGFloat) -> some View {
        let s = Sprite.size(name)
        return Image(small ? "isl_" + name : name)
            .resizable()
            .frame(width: s.width / s.height * height, height: height)
    }
}

/// Мордочка — для маленьких мест (компактный островок, экран блокировки).
struct CatHead: View {
    let state: PetAttributes.ContentState

    var body: some View {
        let name = "isl_" + state.activity.face(angry: state.angry)
        Image(name)
            .resizable()
            .interpolation(.high)
            .scaledToFit()
            .id(name)
            .transition(.opacity)
    }
}

/// Металлическая миска с кормом. fill — сколько корма осталось (0…1).
struct BowlView: View {
    var fill: Double = 1

    var body: some View {
        GeometryReader { g in
            let w = g.size.width, h = g.size.height
            let f = max(0, min(1, fill))
            ZStack {
                Ellipse()
                    .fill(Color(hex: 0x8A5A34))
                    .frame(width: w * 0.8, height: h * (0.16 + 0.22 * f))
                    .position(x: w / 2, y: h * 0.32)
                Ellipse()
                    .fill(Color(hex: 0xB07A4A).opacity(0.8))
                    .frame(width: w * 0.5, height: h * 0.1 * max(0.2, f))
                    .position(x: w * 0.45, y: h * 0.27)
                BowlShape()
                    .fill(LinearGradient(colors: [Color(hex: 0xEEF2F7), Color(hex: 0x8794A3)],
                                         startPoint: .top, endPoint: .bottom))
                BowlShape()
                    .stroke(Color(hex: 0x5D6672), lineWidth: max(1, h * 0.03))
                Capsule()
                    .fill(Color.white.opacity(0.55))
                    .frame(width: w * 0.35, height: h * 0.06)
                    .position(x: w * 0.4, y: h * 0.62)
            }
        }
    }
}

struct BowlShape: Shape {
    func path(in r: CGRect) -> Path {
        var p = Path()
        let w = r.width, h = r.height
        p.move(to: CGPoint(x: r.minX, y: r.minY + h * 0.3))
        p.addCurve(to: CGPoint(x: r.minX + w * 0.5, y: r.maxY),
                   control1: CGPoint(x: r.minX + w * 0.02, y: r.minY + h * 0.85),
                   control2: CGPoint(x: r.minX + w * 0.22, y: r.maxY))
        p.addCurve(to: CGPoint(x: r.maxX, y: r.minY + h * 0.3),
                   control1: CGPoint(x: r.minX + w * 0.78, y: r.maxY),
                   control2: CGPoint(x: r.maxX - w * 0.02, y: r.minY + h * 0.85))
        p.addQuadCurve(to: CGPoint(x: r.minX, y: r.minY + h * 0.3),
                       control: CGPoint(x: r.minX + w * 0.5, y: r.minY + h * 0.62))
        p.closeSubpath()
        return p
    }
}
