import CoreGraphics

/// Покадровые анимации. Картинки: f_<источник>_<n> — приложение, w_<источник>_<n> — виджет.
struct Clip {
    let id: String
    let source: String
    let frames: [Int]
    let fps: Double
    let loops: Bool
    /// Скорость перемещения (единиц Sprite в секунду), 0 — на месте
    let travel: Double
    /// Кадры для виджета (по одному на шаг в 3 секунды)
    let widgetFrames: [Int]
    /// Размер холста в единицах Sprite
    let size: CGSize
    /// Где лапы относительно центра картинки (единицы Sprite)
    let anchorX: Double

    var duration: Double { Double(frames.count) / fps }
    func appImage(_ i: Int) -> String { "f_\(source)_\(frames[((i % frames.count) + frames.count) % frames.count])" }
    func widgetImage(_ n: Int) -> String { "w_\(source)_\(n)" }
    var stillImage: String { widgetImage(widgetFrames[0]) }
}

enum Clips {
    static let all: [String: Clip] = [
        "side_idle": Clip(id: "side_idle", source: "side_bc", frames: [0], fps: 1, loops: true, travel: 0, widgetFrames: [0], size: CGSize(width: 283, height: 303), anchorX: -2.5),
        "side_blink": Clip(id: "side_blink", source: "side_bc", frames: [0, 1, 1, 0], fps: 16, loops: false, travel: 0, widgetFrames: [1], size: CGSize(width: 283, height: 303), anchorX: -2.5),
        "front_idle": Clip(id: "front_idle", source: "front_bc", frames: [0], fps: 1, loops: true, travel: 0, widgetFrames: [0], size: CGSize(width: 242, height: 275), anchorX: 23.2),
        "front_blink": Clip(id: "front_blink", source: "front_bc", frames: [0, 1, 2, 2, 1, 0], fps: 18, loops: false, travel: 0, widgetFrames: [2], size: CGSize(width: 242, height: 275), anchorX: 23.2),
        "walk": Clip(id: "walk", source: "walk", frames: [0, 1, 2, 3, 4, 5, 6, 7], fps: 10, loops: true, travel: 75, widgetFrames: [0, 1, 2, 3, 4, 5, 6, 7], size: CGSize(width: 269, height: 221), anchorX: -14.4),
        "stalk": Clip(id: "stalk", source: "stalk", frames: [0, 1, 2, 3, 4, 5, 6, 7], fps: 6, loops: true, travel: 22, widgetFrames: [0, 1, 2, 3, 4, 5, 6, 7], size: CGSize(width: 358, height: 164), anchorX: 14.1),
        "pounce": Clip(id: "pounce", source: "pounce", frames: [0, 1, 2, 3, 4, 5, 6, 7], fps: 11, loops: false, travel: 140, widgetFrames: [0, 2, 4, 6], size: CGSize(width: 304, height: 206), anchorX: 16.3),
        "jump": Clip(id: "jump", source: "jump", frames: [0, 1, 2, 3, 4, 5, 6, 7], fps: 11, loops: false, travel: 140, widgetFrames: [0, 2, 4, 6], size: CGSize(width: 303, height: 201), anchorX: 5.8),
        "sniff": Clip(id: "sniff", source: "sniff", frames: [0, 1, 2, 3, 4, 5, 6, 7], fps: 6, loops: false, travel: 0, widgetFrames: [1, 3, 5], size: CGSize(width: 339, height: 155), anchorX: 8.7),
        "scratch": Clip(id: "scratch", source: "scratch", frames: [0, 1, 2, 3, 4, 5, 6, 7, 0, 1, 2, 3, 4, 5, 6, 7], fps: 8, loops: false, travel: 0, widgetFrames: [1, 3, 5], size: CGSize(width: 270, height: 222), anchorX: 27.0),
        "meow": Clip(id: "meow", source: "meow", frames: [0, 1, 2, 3, 4, 5, 6, 7], fps: 8, loops: true, travel: 0, widgetFrames: [0, 3, 4, 6], size: CGSize(width: 292, height: 307), anchorX: 3.9),
        "sleep": Clip(id: "sleep", source: "sleep", frames: [0, 1, 2, 3, 4, 5, 6, 7], fps: 3, loops: true, travel: 0, widgetFrames: [0, 2, 4, 6], size: CGSize(width: 248, height: 211), anchorX: -21.6),
        "eat": Clip(id: "eat", source: "eat", frames: [0, 1, 2, 3, 4, 5, 6, 7], fps: 7, loops: true, travel: 0, widgetFrames: [0, 2, 4, 6], size: CGSize(width: 271, height: 232), anchorX: 18.2),
        "purr": Clip(id: "purr", source: "purr", frames: [0, 1, 2, 3, 4, 5, 6, 7], fps: 7, loops: true, travel: 0, widgetFrames: [0, 2, 4, 6], size: CGSize(width: 287, height: 246), anchorX: -17.5),
        "window": Clip(id: "window", source: "window", frames: [0, 1, 2, 3, 4, 5, 6, 7], fps: 4, loops: true, travel: 0, widgetFrames: [0, 2, 4, 6], size: CGSize(width: 296, height: 309), anchorX: -22.3),
        "tv": Clip(id: "tv", source: "tv", frames: [0, 1, 2, 3, 4, 5, 6, 7], fps: 4, loops: true, travel: 0, widgetFrames: [0, 2, 4, 6], size: CGSize(width: 285, height: 201), anchorX: -31.1),
        "stretch": Clip(id: "stretch", source: "stretch", frames: [0, 1, 2, 3, 4, 5, 6, 7], fps: 6, loops: false, travel: 0, widgetFrames: [2, 4, 6], size: CGSize(width: 254, height: 214), anchorX: 1.0),
        "wash": Clip(id: "wash", source: "wash", frames: [0, 1, 2, 3, 4, 5, 6, 7, 3, 4, 5, 4, 3], fps: 7, loops: false, travel: 0, widgetFrames: [2, 4, 6], size: CGSize(width: 255, height: 264), anchorX: -6.7),
        "itch": Clip(id: "itch", source: "itch", frames: [0, 1, 2, 3, 4, 5, 6, 7], fps: 8, loops: false, travel: 0, widgetFrames: [1, 3, 5], size: CGSize(width: 308, height: 308), anchorX: 13.4),
    ]

    static func get(_ id: String) -> Clip { all[id] ?? all["side_idle"]! }
}
