import Foundation
import ActivityKit
import SwiftUI

/// Чем кошка сейчас занята.
enum CatActivity: String, Codable, Hashable {
    case look, curious, stretch, play, back, sleep, meow, eat, loved

    /// Картинка позы (из CatAssets)
    var sprite: String {
        switch self {
        case .look: return "cat_sit"
        case .curious: return "cat_curious"
        case .stretch: return "cat_stretch"
        case .play: return "cat_hunt"
        case .back: return "cat_back1"
        case .sleep: return "cat_sleep"
        case .meow: return "face_surprised"
        case .eat: return "face_happy"
        case .loved: return "cat_belly"
        }
    }

    /// Мордочка — для компактного островка и экрана блокировки.
    func face(angry: Bool) -> String {
        switch self {
        case .look, .back: return "face_neutral"
        case .curious, .play: return "face_curious"
        case .stretch, .eat: return "face_happy"
        case .sleep: return "cat_sleep"
        case .meow: return angry ? "face_angry" : "face_surprised"
        case .loved: return "face_wink"
        }
    }

    var emoji: String {
        switch self {
        case .look: return "👀"
        case .curious: return "❓"
        case .stretch: return "🙆"
        case .play: return "🧶"
        case .back: return "🪟"
        case .sleep: return "💤"
        case .meow: return "📢"
        case .eat: return "🐟"
        case .loved: return "💕"
        }
    }

    func status(toy: CatToy?) -> String {
        switch self {
        case .look: return "Смотрит на тебя"
        case .curious: return "Что-то заметила"
        case .stretch: return "Потягивается"
        case .play: return "Охотится \(toy?.withName ?? "")".trimmingCharacters(in: .whitespaces)
        case .back: return "Смотрит в окно"
        case .sleep: return "Спит"
        case .meow: return "Мяукает! Покорми её"
        case .eat: return "Кушает"
        case .loved: return "Мурчит"
        }
    }

    var symbol: String {
        switch self {
        case .look: return "eye.fill"
        case .curious: return "questionmark.circle.fill"
        case .stretch: return "figure.cooldown"
        case .play: return "sparkles"
        case .back: return "window.casement"
        case .sleep: return "moon.zzz.fill"
        case .meow: return "speaker.wave.3.fill"
        case .eat: return "fork.knife"
        case .loved: return "heart.fill"
        }
    }

    /// Может ли в этом занятии ходить по комнате (в приложении)
    var canWalk: Bool { self == .look || self == .curious || self == .play }
}

/// Игрушки, которые появляются рядом с кошкой.
enum CatToy: String, Codable, Hashable, CaseIterable {
    case yarn, mouse, butterfly, feather, ball

    var imageName: String { "toy_" + rawValue }

    var withName: String {
        switch self {
        case .yarn: return "на клубок"
        case .mouse: return "на мышку"
        case .butterfly: return "на бабочку"
        case .feather: return "на пёрышко"
        case .ball: return "на мячик"
        }
    }
}

/// Что может сделать человек.
enum PetAction: String, Codable {
    case feed, pet, play
}

/// Данные Live Activity. ContentState — то, что меняется со временем.
struct PetAttributes: ActivityAttributes {
    public struct ContentState: Codable, Hashable {
        var name: String
        var activity: CatActivity
        var toy: CatToy?
        var phrase: String
        /// Место в виджете: 0 — слева, 1 — по центру, 2 — справа
        var spot: Int
        /// Мяукает уже давно и сердится
        var angry: Bool = false
        /// Сейчас идёт на новое место (в виджете)
        var walking: Bool = false
        /// Смотрит/идёт влево
        var facingLeft: Bool = false
    }

    /// Когда запущена эта Live Activity (iOS держит её ~8 часов).
    var startedAt: Date
}

extension Color {
    init(hex: UInt32) {
        self.init(
            .sRGB,
            red: Double((hex >> 16) & 0xFF) / 255,
            green: Double((hex >> 8) & 0xFF) / 255,
            blue: Double(hex & 0xFF) / 255,
            opacity: 1
        )
    }

    static let catAccent = Color(hex: 0xF4A7B9)   // розовые ушки
}
