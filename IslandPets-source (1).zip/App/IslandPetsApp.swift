import SwiftUI
import BackgroundTasks

let refreshTaskID = "com.islandpets.refresh"

/// Просим iOS иногда будить приложение в фоне, чтобы островок успевал за занятиями кошки.
/// Когда именно — решает система.
func scheduleRefresh() {
    let request = BGAppRefreshTaskRequest(identifier: refreshTaskID)
    request.earliestBeginDate = Date(timeIntervalSinceNow: 15 * 60)
    try? BGTaskScheduler.shared.submit(request)
}

@main
struct IslandPetsApp: App {
    @Environment(\.scenePhase) private var scenePhase
    @StateObject private var engine = PetEngine.shared

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(engine)
                .preferredColorScheme(.dark)
        }
        .onChange(of: scenePhase) { _, phase in
            switch phase {
            case .active:
                engine.requestNotificationPermission()
                Task { await engine.sync(canStart: true) }
            case .background:
                scheduleRefresh()
            default:
                break
            }
        }
        .backgroundTask(.appRefresh(refreshTaskID)) {
            scheduleRefresh()
            await PetEngine.shared.sync(canStart: false)
        }
    }
}
