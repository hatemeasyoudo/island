import CoreHaptics
import UIKit

/// Вибрация «мурчания», пока кошка мурчит и приложение открыто.
/// Мягкая непрерывная вибрация с ритмом вдоха-выдоха, как у настоящей кошки.
final class PurrHaptics {
    static let shared = PurrHaptics()

    private var engine: CHHapticEngine?
    private var player: CHHapticAdvancedPatternPlayer?
    private var running = false

    func set(_ on: Bool) {
        on ? start() : stop()
    }

    private func start() {
        guard !running, CHHapticEngine.capabilitiesForHardware().supportsHaptics else { return }
        do {
            let e = try CHHapticEngine()
            e.isAutoShutdownEnabled = true
            e.resetHandler = { [weak self] in
                guard let self, self.running else { return }
                self.running = false
                self.start()
            }
            try e.start()
            // один цикл «мр-р» ~1.6 с: вдох (тише) + выдох (сильнее), повторяется
            let breath: [(Double, Double, Float)] = [(0.0, 0.75, 0.35), (0.85, 0.7, 0.55)]
            var events: [CHHapticEvent] = []
            for (start, dur, intensity) in breath {
                events.append(CHHapticEvent(
                    eventType: .hapticContinuous,
                    parameters: [
                        CHHapticEventParameter(parameterID: .hapticIntensity, value: intensity),
                        CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.05),
                    ],
                    relativeTime: start,
                    duration: dur))
            }
            let pattern = try CHHapticPattern(events: events, parameters: [])
            let p = try e.makeAdvancedPlayer(with: pattern)
            p.loopEnabled = true
            p.loopEnd = 1.6
            try p.start(atTime: CHHapticTimeImmediate)
            engine = e
            player = p
            running = true
        } catch {
            // на этом iPhone вибрация недоступна — просто без неё
            UIImpactFeedbackGenerator(style: .soft).impactOccurred()
        }
    }

    private func stop() {
        guard running else { return }
        running = false
        try? player?.stop(atTime: CHHapticTimeImmediate)
        engine?.stop(completionHandler: nil)
        player = nil
        engine = nil
    }
}
