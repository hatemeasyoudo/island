import SwiftUI

/// Одна картинка-спрайт в общем масштабе (scale — пунктов на «пиксель листа»).
struct SpriteImage: View {
    let name: String
    let scale: CGFloat
    var flipped: Bool = false

    var body: some View {
        let s = Sprite.size(name)
        Image(name)
            .resizable()
            .interpolation(.high)
            .frame(width: s.width * scale, height: s.height * scale)
            .scaleEffect(x: flipped ? -1 : 1, y: 1)
    }
}

/// Сколько пунктов на «пиксель листа», чтобы кошка влезла в рамку.
func catScale(for activity: CatActivity, in size: CGSize) -> CGFloat {
    let s = Sprite.size(activity.sprite)
    // высота «комнаты» ~300 пикселей листа; мордочки («выглядывает») крупнее
    var k = size.height / (activity.isBust ? 175 : 300)
    k = min(k, size.width * 0.95 / s.width, size.height * 0.98 / s.height)
    return k
}

/// Кошка с тенью, игрушкой, миской и значками — для виджетов и островка.
/// Смена позы плавно растворяется (iOS анимирует переход между кадрами виджета).
struct CatScene: View {
    let state: PetAttributes.ContentState
    var showEffects: Bool = true

    var body: some View {
        GeometryReader { g in
            let a = state.activity
            let k = catScale(for: a, in: g.size)
            let sz = Sprite.size(a.sprite)
            let cw = sz.width * k, ch = sz.height * k
            let cx = g.size.width / 2
            let floor = g.size.height
            let top = floor - ch

            ZStack {
                // мягкая тень
                Ellipse()
                    .fill(Color.black.opacity(0.3))
                    .frame(width: cw * 0.75, height: max(4, ch * 0.06))
                    .blur(radius: 3)
                    .position(x: cx, y: floor - max(2, ch * 0.03))

                SpriteImage(name: a.sprite, scale: k)
                    .position(x: cx, y: floor - ch / 2)
                    .id(a.sprite)
                    .transition(.opacity.combined(with: .scale(scale: 0.94, anchor: .bottom)))

                if a == .eat {
                    BowlView()
                        .frame(width: cw * 0.7, height: cw * 0.3)
                        .position(x: cx, y: floor - cw * 0.12)
                }

                if a == .play, let toy = state.toy {
                    Image(toy.imageName)
                        .resizable()
                        .scaledToFit()
                        .frame(width: ch * 0.3, height: ch * 0.3)
                        .rotationEffect(.degrees(-15))
                        .position(x: min(g.size.width - ch * 0.15, cx + cw * 0.55), y: floor - ch * 0.15)
                }

                if showEffects {
                    let fx = ch * 0.28
                    switch a {
                    case .sleep:
                        SpriteImage(name: "fx_zzz", scale: fx / Sprite.size("fx_zzz").height)
                            .position(x: cx + cw * 0.38, y: top - fx * 0.1)
                    case .loved:
                        SpriteImage(name: "fx_heart", scale: fx * 0.8 / Sprite.size("fx_heart").height)
                            .position(x: cx + cw * 0.42, y: top + fx * 0.3)
                    case .meow:
                        if state.angry {
                            SpriteImage(name: "fx_anger", scale: fx * 0.8 / Sprite.size("fx_anger").height)
                                .position(x: cx + cw * 0.42, y: top + fx * 0.3)
                        } else {
                            Text("Мяу!")
                                .font(.system(size: max(8, ch * 0.13), weight: .heavy, design: .rounded))
                                .foregroundStyle(Color(hex: 0x3A3634))
                                .padding(.horizontal, ch * 0.05)
                                .padding(.vertical, ch * 0.015)
                                .background(Capsule().fill(Color.white))
                                .position(x: cx + cw * 0.5, y: top + ch * 0.08)
                        }
                    case .stretch, .curious:
                        SpriteImage(name: "fx_sparkle", scale: fx * 0.6 / Sprite.size("fx_sparkle").height)
                            .position(x: cx - cw * 0.42, y: top + fx * 0.3)
                    default:
                        EmptyView()
                    }
                }
            }
            .frame(width: g.size.width, height: g.size.height)
        }
    }
}

/// Мордочка — для маленьких мест (компактный островок, экран блокировки).
struct CatHead: View {
    let state: PetAttributes.ContentState

    var body: some View {
        let name = state.activity.face(angry: state.angry)
        Image(name)
            .resizable()
            .interpolation(.high)
            .scaledToFit()
            .id(name)
            .transition(.opacity)
    }
}

/// Металлическая миска с кормом. fill — сколько корма осталось (0…1).
struct BowlView: View {
    var fill: Double = 1

    var body: some View {
        GeometryReader { g in
            let w = g.size.width, h = g.size.height
            let f = max(0, min(1, fill))
            ZStack {
                Ellipse()
                    .fill(Color(hex: 0x8A5A34))
                    .frame(width: w * 0.8, height: h * (0.16 + 0.22 * f))
                    .position(x: w / 2, y: h * 0.32)
                Ellipse()
                    .fill(Color(hex: 0xB07A4A).opacity(0.8))
                    .frame(width: w * 0.5, height: h * 0.1 * max(0.2, f))
                    .position(x: w * 0.45, y: h * 0.27)
                BowlShape()
                    .fill(LinearGradient(colors: [Color(hex: 0xEEF2F7), Color(hex: 0x8794A3)],
                                         startPoint: .top, endPoint: .bottom))
                BowlShape()
                    .stroke(Color(hex: 0x5D6672), lineWidth: max(1, h * 0.03))
                Capsule()
                    .fill(Color.white.opacity(0.55))
                    .frame(width: w * 0.35, height: h * 0.06)
                    .position(x: w * 0.4, y: h * 0.62)
            }
        }
    }
}

struct BowlShape: Shape {
    func path(in r: CGRect) -> Path {
        var p = Path()
        let w = r.width, h = r.height
        p.move(to: CGPoint(x: r.minX, y: r.minY + h * 0.3))
        p.addCurve(to: CGPoint(x: r.minX + w * 0.5, y: r.maxY),
                   control1: CGPoint(x: r.minX + w * 0.02, y: r.minY + h * 0.85),
                   control2: CGPoint(x: r.minX + w * 0.22, y: r.maxY))
        p.addCurve(to: CGPoint(x: r.maxX, y: r.minY + h * 0.3),
                   control1: CGPoint(x: r.minX + w * 0.78, y: r.maxY),
                   control2: CGPoint(x: r.maxX - w * 0.02, y: r.minY + h * 0.85))
        p.addQuadCurve(to: CGPoint(x: r.minX, y: r.minY + h * 0.3),
                       control: CGPoint(x: r.minX + w * 0.5, y: r.minY + h * 0.62))
        p.closeSubpath()
        return p
    }
}
