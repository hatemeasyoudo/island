import CoreGraphics

/// Размеры картинок в «пикселях листа» — чтобы все позы были в одном масштабе.
enum Sprite {
    static let sizes: [String: CGSize] = [
        "cat_back1": CGSize(width: 178, height: 240),
        "cat_back2": CGSize(width: 178, height: 240),
        "cat_back3": CGSize(width: 178, height: 240),
        "cat_belly": CGSize(width: 150, height: 127),
        "cat_curious": CGSize(width: 171, height: 271),
        "cat_hunt": CGSize(width: 256, height: 228),
        "cat_sit": CGSize(width: 201, height: 273),
        "cat_sleep": CGSize(width: 168, height: 99),
        "cat_stretch": CGSize(width: 268, height: 269),
        "face_angry": CGSize(width: 110, height: 111),
        "face_curious": CGSize(width: 113, height: 127),
        "face_grumpy": CGSize(width: 107, height: 113),
        "face_happy": CGSize(width: 110, height: 125),
        "face_neutral": CGSize(width: 113, height: 124),
        "face_sad": CGSize(width: 109, height: 112),
        "face_surprised": CGSize(width: 112, height: 127),
        "face_wink": CGSize(width: 115, height: 119),
        "fx_anger": CGSize(width: 36, height: 38),
        "fx_heart": CGSize(width: 43, height: 37),
        "fx_paw": CGSize(width: 36, height: 40),
        "fx_sparkle": CGSize(width: 35, height: 37),
        "fx_zzz": CGSize(width: 51, height: 43),
        "walk1": CGSize(width: 294, height: 203),
        "walk2": CGSize(width: 294, height: 203),
        "walk3": CGSize(width: 294, height: 203),
        "walk4": CGSize(width: 294, height: 203),
        "walk5": CGSize(width: 294, height: 203),
    ]

    static func size(_ name: String) -> CGSize { sizes[name] ?? CGSize(width: 200, height: 200) }
}
