import Foundation

/// Характер и распорядок дня кошки. Используется приложением, островком и виджетом.
///
/// Распорядок не хранится, а вычисляется из даты и личного «зерна» кошки:
/// поэтому виджет заранее знает, когда она уснёт или пойдёт играть, без участия приложения.
final class CatBrain {
    static let baseGroupID = "group.com.islandpets.app"

    // MARK: Характер — можно менять под себя
    static let slotMinutes = 15                          // как часто меняет занятие
    static let napsPerDay = 3...4                        // сколько раз в день спит
    static let napMinutes = 40...150                     // длина сна (в случайное время суток)
    static let meowWindow = (from: 9 * 60, to: 22 * 60)  // мяукает в случайное время с 9:00 до 22:00
    static let meowSkipIfFedWithin: TimeInterval = 2 * 3600  // не мяукает, если поели за 2 часа до этого
    static let eatDuration: TimeInterval = 120
    static let lovedDuration: TimeInterval = 60
    static let playDuration: TimeInterval = 600
    static let angryAfter: TimeInterval = 90 * 60            // через сколько мяуканья начинает сердиться

    /// Общая память App Group (nil — если установщик её не выдал).
    static let groupID: String? = {
        var candidates = (Bundle.main.object(forInfoDictionaryKey: "ALTAppGroups") as? [String]) ?? []
        candidates.append(baseGroupID)
        return candidates.first {
            FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: $0) != nil
        }
    }()

    static var isShared: Bool { groupID != nil }

    private enum Key {
        static let name = "cat.name", island = "cat.island", meowEnabled = "cat.meowEnabled"
        static let seed = "cat.seed", installedAt = "cat.installedAt", lastFed = "cat.lastFed"
        static let reaction = "cat.reaction", reactionAt = "cat.reactionAt", reactionToy = "cat.reactionToy"
        static let awakeUntil = "cat.awakeUntil"
    }

    let d: UserDefaults
    private let cal = Calendar.current

    init() {
        if let g = Self.groupID, let shared = UserDefaults(suiteName: g) {
            d = shared
        } else {
            d = .standard
        }
        let now = Date()
        if d.object(forKey: Key.seed) == nil {
            d.set(Int.random(in: 1...Int(Int32.max)), forKey: Key.seed)
        }
        if d.object(forKey: Key.installedAt) == nil { d.set(now, forKey: Key.installedAt) }
        if d.object(forKey: Key.lastFed) == nil { d.set(now, forKey: Key.lastFed) }
    }

    // MARK: - Настройки

    var name: String {
        get {
            let n = d.string(forKey: Key.name)?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
            return n.isEmpty ? "Кошечка" : n
        }
        set { d.set(newValue, forKey: Key.name) }
    }

    var islandEnabled: Bool {
        get { d.object(forKey: Key.island) as? Bool ?? true }
        set { d.set(newValue, forKey: Key.island) }
    }

    var meowEnabled: Bool {
        get { d.object(forKey: Key.meowEnabled) as? Bool ?? true }
        set { d.set(newValue, forKey: Key.meowEnabled) }
    }

    var lastFed: Date {
        get { d.object(forKey: Key.lastFed) as? Date ?? Date() }
        set { d.set(newValue, forKey: Key.lastFed) }
    }

    private var seed: UInt64 { UInt64(d.integer(forKey: Key.seed)) }
    private var installedAt: Date { d.object(forKey: Key.installedAt) as? Date ?? Date() }

    // MARK: - Детерминированный «случай»

    private static func mix(_ x: UInt64) -> UInt64 {
        var z = x &+ 0x9E3779B97F4A7C15
        z = (z ^ (z >> 30)) &* 0xBF58476D1CE4E5B9
        z = (z ^ (z >> 27)) &* 0x94D049BB133111EB
        return z ^ (z >> 31)
    }

    private func rnd(_ a: Int, _ b: Int) -> UInt64 {
        Self.mix(seed &+ Self.mix(UInt64(bitPattern: Int64(a)) &+ Self.mix(UInt64(bitPattern: Int64(b)))))
    }

    private func rnd(_ a: Int, _ b: Int, in range: ClosedRange<Int>) -> Int {
        range.lowerBound + Int(rnd(a, b) % UInt64(range.count))
    }

    // MARK: - Распорядок дня

    private func dayStart(_ date: Date, offset: Int = 0) -> Date {
        let s = cal.startOfDay(for: date)
        return cal.date(byAdding: .day, value: offset, to: s) ?? s
    }

    private func dayKey(_ dayStart: Date) -> Int {
        cal.ordinality(of: .day, in: .era, for: dayStart) ?? 0
    }

    /// Случайные промежутки в течение суток (сон, лоток).
    private func intervals(day: Date, kind: Int, count: Int, minutes: ClosedRange<Int>) -> [ClosedRange<Date>] {
        let key = dayKey(day)
        return (0..<count).map { i in
            let startMin = rnd(key, kind * 100 + i, in: 0...1439)
            let len = rnd(key, kind * 100 + 50 + i, in: minutes)
            let start = day.addingTimeInterval(Double(startMin) * 60)
            return start...start.addingTimeInterval(Double(len) * 60)
        }
    }

    private func naps(day: Date) -> [ClosedRange<Date>] {
        let key = dayKey(day)
        let count = rnd(key, 1, in: Self.napsPerDay)
        return intervals(day: day, kind: 2, count: count, minutes: Self.napMinutes)
    }

    /// Текущий сон (если спит). Сон, прерванный человеком, не считается.
    private func currentNap(_ now: Date) -> ClosedRange<Date>? {
        if let awake = d.object(forKey: Key.awakeUntil) as? Date, now < awake { return nil }
        for off in [0, -1] {
            if let n = naps(day: dayStart(now, offset: off)).first(where: { $0.contains(now) }) { return n }
        }
        return nil
    }

    /// Во сколько кошка мяукнет в этот день.
    func meowTime(day: Date) -> Date {
        let m = rnd(dayKey(day), 4, in: Self.meowWindow.from...Self.meowWindow.to)
        return day.addingTimeInterval(Double(m) * 60)
    }

    /// С какого момента мяукает (nil — не мяукает): время мяуканья наступило,
    /// а покормили до этого давно (или не кормили вовсе).
    func meowStart(_ now: Date) -> Date? {
        guard meowEnabled else { return nil }
        for off in [0, -1] {
            let t = meowTime(day: dayStart(now, offset: off))
            if t <= now, t >= installedAt, lastFed < t.addingTimeInterval(-Self.meowSkipIfFedWithin) {
                return t
            }
        }
        return nil
    }

    func isMeowing(_ now: Date) -> Bool { meowStart(now) != nil }

    /// Когда кошка будет мяукать в ближайшие дни (для уведомлений).
    func upcomingMeows(from now: Date, days: Int) -> [Date] {
        guard meowEnabled else { return [] }
        return (0..<days).compactMap { off in
            let t = meowTime(day: dayStart(now, offset: off))
            guard t > now, t >= installedAt else { return nil }
            if lastFed >= t.addingTimeInterval(-Self.meowSkipIfFedWithin) { return nil }
            return t
        }
    }

    // MARK: - Реакции на человека

    private func reaction(at now: Date) -> (CatActivity, CatToy?, Date)? {
        guard let raw = d.string(forKey: Key.reaction),
              let a = CatActivity(rawValue: raw),
              let at = d.object(forKey: Key.reactionAt) as? Date else { return nil }
        let dur: TimeInterval
        switch a {
        case .eat: dur = Self.eatDuration
        case .loved: dur = Self.lovedDuration
        default: dur = Self.playDuration
        }
        guard now >= at, now < at.addingTimeInterval(dur) else { return nil }
        let toy = d.string(forKey: Key.reactionToy).flatMap { CatToy(rawValue: $0) }
        return (a, toy, at)
    }

    /// Когда закончится текущая реакция (для расписания виджета).
    func reactionEnd(after now: Date) -> Date? {
        guard let r = reaction(at: now) else { return nil }
        let a = r.0, at = r.2
        let dur: TimeInterval = a == .eat ? Self.eatDuration : (a == .loved ? Self.lovedDuration : Self.playDuration)
        return at.addingTimeInterval(dur)
    }

    func apply(_ action: PetAction, at now: Date) {
        // если спала — просыпается до конца этого сна
        if let nap = currentNap(now) {
            d.set(nap.upperBound, forKey: Key.awakeUntil)
        }
        switch action {
        case .feed:
            lastFed = now
            setReaction(.eat, toy: nil, at: now)
        case .pet:
            setReaction(.loved, toy: nil, at: now)
        case .play:
            let toy = CatToy.allCases[Int(rnd(Int(now.timeIntervalSince1970), 9) % UInt64(CatToy.allCases.count))]
            setReaction(.play, toy: toy, at: now)
        }
    }

    private func setReaction(_ a: CatActivity, toy: CatToy?, at: Date) {
        d.set(a.rawValue, forKey: Key.reaction)
        d.set(at, forKey: Key.reactionAt)
        if let t = toy { d.set(t.rawValue, forKey: Key.reactionToy) } else { d.removeObject(forKey: Key.reactionToy) }
    }

    // MARK: - Состояние

    func state(at now: Date) -> PetAttributes.ContentState {
        let slot = Int(now.timeIntervalSince1970) / (Self.slotMinutes * 60)
        var activity: CatActivity
        var toy: CatToy? = nil
        var phraseSeed = UInt64(slot)
        var spot = rnd(slot, 5, in: 0...2)
        var angry = false

        if let r = reaction(at: now) {
            activity = r.0
            toy = r.1
            phraseSeed = UInt64(Int(r.2.timeIntervalSince1970))
        } else if let m = meowStart(now) {
            activity = .meow
            angry = now.timeIntervalSince(m) > Self.angryAfter
        } else if let nap = currentNap(now) {
            activity = .sleep
            let k = Int(nap.lowerBound.timeIntervalSince1970)
            phraseSeed = UInt64(k / 60)
            spot = rnd(k, 6, in: 0...2)       // спит на одном месте
        } else {
            let r = rnd(slot, 3) % 100
            switch r {
            case 0..<25: activity = .look
            case 25..<40: activity = .curious
            case 40..<52: activity = .back
            case 52..<62: activity = .stretch
            default: activity = .play
            }
            if activity == .play {
                toy = CatToy.allCases[Int(rnd(slot, 4) % UInt64(CatToy.allCases.count))]
            }
        }

        return PetAttributes.ContentState(
            name: name,
            activity: activity,
            toy: toy,
            phrase: Phrases.pick(for: activity, seed: rnd(Int(phraseSeed), 8)),
            spot: spot,
            angry: angry
        )
    }

    /// Ближайшие моменты, когда состояние меняется (для расписания виджета).
    func timeline(from now: Date, hours: Double) -> [(Date, PetAttributes.ContentState)] {
        var result: [(Date, PetAttributes.ContentState)] = [(now, state(at: now))]
        var points: [Date] = []
        if let end = reactionEnd(after: now) { points.append(end.addingTimeInterval(1)) }
        // проверяем каждые 5 минут и оставляем только моменты, когда что-то поменялось
        var t = now
        let step: TimeInterval = 5 * 60
        let aligned = (now.timeIntervalSince1970 / step).rounded(.down) * step
        t = Date(timeIntervalSince1970: aligned)
        while t < now.addingTimeInterval(hours * 3600) {
            t = t.addingTimeInterval(step)
            points.append(t)
        }
        for p in points.sorted() where p > now {
            let s = state(at: p)
            if s != result.last?.1 { result.append((p, s)) }
        }
        return result
    }
}

extension PetAttributes.ContentState {
    static var preview: PetAttributes.ContentState {
        PetAttributes.ContentState(name: "Кошечка", activity: .look, toy: nil, phrase: "*смотрит на тебя*", spot: 1)
    }
}
