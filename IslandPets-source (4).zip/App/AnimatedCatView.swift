import SwiftUI
import Combine

/// Живая кошка в приложении. Всё считается покадрово (60 кадров/с):
/// ходит по комнате (5 кадров шага) и оставляет следы лапок, дышит,
/// виляет хвостом, охотится на игрушку, мурчит, мяукает, сопит во сне.
struct AnimatedCatView: View {
    let state: PetAttributes.ContentState

    // ходьба
    @State private var fromX: CGFloat = 0
    @State private var toX: CGFloat = 0
    @State private var moveStart: Date = .distantPast
    @State private var moveDuration: Double = 2
    @State private var facingLeft = false
    @State private var prints: [PawPrint] = []
    // когда началось текущее занятие (для миски с кормом)
    @State private var activityStart = Date()

    private let wanderTimer = Timer.publish(every: 4.2, on: .main, in: .common).autoconnect()

    struct PawPrint: Identifiable {
        let id = UUID()
        let x: CGFloat
        let up: Bool
        let at: Date
        let left: Bool
    }

    var body: some View {
        TimelineView(.animation) { tl in
            GeometryReader { g in
                scene(now: tl.date, size: g.size)
            }
        }
        .animation(.easeInOut(duration: 0.6), value: state.activity)
        .onReceive(wanderTimer) { _ in wander() }
        .onChange(of: state.activity) { _, _ in activityStart = Date() }
    }

    // MARK: - Кадр

    @ViewBuilder
    private func scene(now: Date, size: CGSize) -> some View {
        let t: Double = now.timeIntervalSinceReferenceDate
        let a = state.activity
        let k: CGFloat = min(0.62, size.width / 520)           // пунктов на пиксель листа
        let floorY: CGFloat = size.height - 14

        // ходьба: плавный разгон и торможение
        let mp: Double = min(1, max(0, now.timeIntervalSince(moveStart) / moveDuration))
        let ease = CGFloat(mp * mp * (3 - 2 * mp))
        let walking: Bool = mp > 0 && mp < 1 && a.canWalk
        let x: CGFloat = size.width / 2 + fromX + (toX - fromX) * ease

        // какая картинка сейчас
        let sprite: String = currentSprite(a, walking: walking, t: t)
        let bust: Bool = !walking && a.isBust
        let kk: CGFloat = bust ? k * 1.7 : k
        let sz = Sprite.size(sprite)
        let cw: CGFloat = sz.width * kk
        let ch: CGFloat = sz.height * kk
        let flip: Bool = facingLeft && (walking || a == .play || a == .curious)

        // дыхание, покачивания, прыжки
        let period: Double = a == .sleep ? 4.4 : 3.0
        let depth: Double = a == .sleep ? 0.03 : (a == .stretch ? 0.025 : 0.012)
        let breath = CGFloat(1 + depth * sin(t * 2 * .pi / period))
        let step: CGFloat = walking ? CGFloat(abs(sin(t * .pi * 5)) * 3) : 0
        let wiggle: Double = a == .loved ? 3 * sin(t * 2 * .pi / 1.4) : 0
        let meowJump: CGFloat = a == .meow ? CGFloat(pow(max(0, sin(t * 2 * .pi / 1.4)), 3) * 10) : 0
        let eatNod: CGFloat = a == .eat ? CGFloat(abs(sin(t * 2 * .pi / 1.0)) * 4) : 0
        let lift: CGFloat = step + meowJump - eatNod
        let shadowW: CGFloat = cw * 0.7 * (1 - lift / 70)
        let top: CGFloat = floorY - ch

        ZStack {
            // следы лапок тают за 3 секунды
            ForEach(prints) { p in
                let age: Double = now.timeIntervalSince(p.at)
                if age >= 0 && age < 3 {
                    SpriteImage(name: "fx_paw", scale: 0.35)
                        .rotationEffect(.degrees(p.left ? -90 : 90))
                        .opacity(0.55 * (1 - age / 3))
                        .position(x: size.width / 2 + p.x, y: floorY - (p.up ? 6 : -2))
                }
            }

            // тень
            Ellipse()
                .fill(Color.black.opacity(0.35))
                .frame(width: shadowW, height: 12)
                .blur(radius: 5)
                .position(x: x, y: floorY - 2)

            if a == .eat && !walking {
                let left: Double = max(0.08, 1 - now.timeIntervalSince(activityStart) / CatBrain.eatDuration)
                BowlView(fill: left)
                    .frame(width: cw * 0.75, height: cw * 0.32)
                    .position(x: x, y: floorY - cw * 0.12)
                    .zIndex(2)
                    .transition(.scale.combined(with: .opacity))
            }

            SpriteImage(name: sprite, scale: kk, flipped: flip)
                .scaleEffect(x: 1, y: breath, anchor: .bottom)
                .rotationEffect(.degrees(wiggle), anchor: .bottom)
                .offset(y: -lift)
                .position(x: x, y: floorY - ch / 2)
                .zIndex(1)
                .id(a.sprite + (walking ? "-walk" : ""))
                .transition(.opacity)

            if a == .play, let toy = state.toy {
                toyView(toy, t: t, x: x, ch: ch, floorY: floorY, roomWidth: size.width)
                    .zIndex(3)
            }

            effects(a, t: t, x: x, cw: cw, top: top)
                .zIndex(4)
        }
    }

    private func currentSprite(_ a: CatActivity, walking: Bool, t: Double) -> String {
        if walking {
            let f = Int(t * 10) % 5           // 10 кадров в секунду
            return "walk\(f + 1)"
        }
        if a == .back {
            let seq = [1, 2, 3, 2]            // хвост виляет туда-сюда
            return "cat_back\(seq[Int(t / 0.35) % seq.count])"
        }
        return a.sprite
    }

    // MARK: - Игрушка: каждая двигается по-своему

    @ViewBuilder
    private func toyView(_ toy: CatToy, t: Double, x: CGFloat, ch: CGFloat, floorY: CGFloat, roomWidth: CGFloat) -> some View {
        let dir: CGFloat = facingLeft ? -1 : 1
        let ahead: CGFloat = x + dir * ch * 0.75
        switch toy {
        case .butterfly:
            let bx: CGFloat = ahead + CGFloat(40 * sin(t * 0.9))
            let by: CGFloat = floorY - ch * 1.05 + CGFloat(20 * sin(t * 1.8))
            let flap = CGFloat(0.5 + 0.5 * abs(sin(t * 14)))
            Image(toy.imageName).resizable().scaledToFit()
                .frame(width: 36, height: 36)
                .scaleEffect(x: flap, y: 1)
                .rotationEffect(.degrees(10 * sin(t * 1.8)))
                .position(x: bx, y: by)
        case .feather:
            let fx: CGFloat = ahead + CGFloat(18 * sin(t * 0.7))
            let fy: CGFloat = floorY - ch * 0.9 + CGFloat(16 * sin(t * 1.3))
            Image(toy.imageName).resizable().scaledToFit()
                .frame(width: 42, height: 42)
                .rotationEffect(.degrees(25 * sin(t * 1.3)))
                .position(x: fx, y: fy)
        default:
            let px: CGFloat = ahead + CGFloat(22 * sin(t * 1.6))
            let bounce = CGFloat(abs(sin(t * 3)) * 30)
            let spin: Double = t * 160 * (cos(t * 1.6) >= 0 ? 1 : -1)
            Image(toy.imageName).resizable().scaledToFit()
                .frame(width: 34, height: 34)
                .rotationEffect(.degrees(spin))
                .position(x: px, y: floorY - 17 - bounce)
        }
    }

    // MARK: - Значки над кошкой

    @ViewBuilder
    private func effects(_ a: CatActivity, t: Double, x: CGFloat, cw: CGFloat, top: CGFloat) -> some View {
        switch a {
        case .sleep:
            let p: Double = (t / 3.0).truncatingRemainder(dividingBy: 1)
            SpriteImage(name: "fx_zzz", scale: CGFloat(0.5 + 0.4 * p))
                .opacity(sin(p * .pi))
                .position(x: x + cw * 0.35 + CGFloat(20 * p), y: top - CGFloat(40 * p))
        case .loved:
            ForEach(0..<3, id: \.self) { i in
                let p: Double = (t / 2.4 + Double(i) / 3).truncatingRemainder(dividingBy: 1)
                let side: CGFloat = i == 1 ? -1 : 1
                SpriteImage(name: "fx_heart", scale: CGFloat(0.35 + 0.35 * p))
                    .opacity(sin(p * .pi))
                    .position(x: x + side * (cw * 0.3 + CGFloat(10 * sin(p * 7))), y: top + 20 - CGFloat(80 * p))
            }
        case .meow:
            if state.angry {
                SpriteImage(name: "fx_anger", scale: CGFloat(0.6 + 0.12 * abs(sin(t * 4))))
                    .position(x: x + cw * 0.42, y: top + 18)
            } else {
                Text("Мяу!")
                    .font(.system(size: 20, weight: .heavy, design: .rounded))
                    .foregroundStyle(Color(hex: 0x3A3634))
                    .padding(.horizontal, 12)
                    .padding(.vertical, 5)
                    .background(Capsule().fill(Color.white))
                    .scaleEffect(CGFloat(1 + 0.1 * pow(max(0, sin(t * 2 * .pi / 1.4)), 3)))
                    .position(x: x + cw * 0.5, y: top + 4)
            }
        case .stretch, .curious, .play:
            let p: Double = (t / 1.8).truncatingRemainder(dividingBy: 1)
            SpriteImage(name: "fx_sparkle", scale: CGFloat(0.35 + 0.25 * sin(p * .pi)))
                .opacity(sin(p * .pi))
                .rotationEffect(.degrees(p * 90))
                .position(x: x - cw * 0.45, y: top + 10)
        default:
            EmptyView()
        }
    }

    // MARK: - Прогулки

    private func wander() {
        guard state.activity.canWalk else { return }
        let now = Date()
        if now.timeIntervalSince(moveStart) < moveDuration { return }   // ещё идёт
        if Double.random(in: 0...1) < 0.3 { return }                     // иногда просто сидит
        let current = toX
        var target = CGFloat.random(in: -100...100)
        if abs(target - current) < 50 { target = current > 0 ? current - 90 : current + 90 }
        fromX = current
        toX = target
        facingLeft = target < current
        moveDuration = Double(abs(target - current)) / 60 + 0.6
        moveStart = now

        // следы: по одному каждые ~0.3 с пути
        let n = max(2, Int(moveDuration / 0.3))
        prints = (1...n).map { j in
            let f = Double(j) / Double(n + 1)
            let e = CGFloat(f * f * (3 - 2 * f))
            return PawPrint(x: current + (target - current) * e,
                            up: j % 2 == 0,
                            at: now.addingTimeInterval(moveDuration * f),
                            left: target < current)
        }
    }
}
