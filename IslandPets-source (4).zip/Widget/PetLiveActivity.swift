import WidgetKit
import SwiftUI
import ActivityKit

@main
struct IslandPetsWidgetBundle: WidgetBundle {
    var body: some Widget {
        PetLiveActivity()
        PetHomeWidget()
    }
}

struct PetLiveActivity: Widget {
    var body: some WidgetConfiguration {
        ActivityConfiguration(for: PetAttributes.self) { context in
            // Экран блокировки и баннер
            LockScreenCatView(state: context.state)
                .activityBackgroundTint(Color(hex: 0x1E1830))
                .activitySystemActionForegroundColor(.white)
        } dynamicIsland: { context in
            let s = context.state
            return DynamicIsland {
                DynamicIslandExpandedRegion(.leading) {
                    CatScene(state: s, showEffects: false)
                        .frame(width: 64, height: 64)
                }
                DynamicIslandExpandedRegion(.trailing) {
                    Text(s.activity.emoji)
                        .font(.title2)
                        .padding(.trailing, 4)
                }
                DynamicIslandExpandedRegion(.center) {
                    VStack(spacing: 2) {
                        Text(s.name).font(.headline)
                        Text(s.phrase)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                            .lineLimit(2)
                            .multilineTextAlignment(.center)
                    }
                }
                DynamicIslandExpandedRegion(.bottom) {
                    VStack(spacing: 8) {
                        StatusLine(state: s)
                        ActionRow(state: s)
                    }
                    .padding(.horizontal, 4)
                }
            } compactLeading: {
                CatHead(state: s)
                    .frame(width: 26, height: 24)
            } compactTrailing: {
                Text(s.activity.emoji)
                    .font(.caption)
            } minimal: {
                CatHead(state: s)
                    .frame(width: 22, height: 21)
            }
            .keylineTint(.catAccent)
        }
    }
}

struct LockScreenCatView: View {
    let state: PetAttributes.ContentState

    var body: some View {
        HStack(alignment: .center, spacing: 12) {
            CatScene(state: state, showEffects: false)
                .frame(width: 76, height: 76)
            VStack(alignment: .leading, spacing: 6) {
                HStack {
                    Text(state.name).font(.headline)
                    Text(state.activity.emoji)
                    Spacer()
                }
                Text(state.phrase)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
                StatusLine(state: state)
                ActionRow(state: state)
            }
        }
        .padding(14)
        .foregroundStyle(.white)
    }
}
