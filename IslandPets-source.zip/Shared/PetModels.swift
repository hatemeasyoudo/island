import Foundation
import ActivityKit
import SwiftUI

/// Чем кошка сейчас занята (крупное занятие, меняется раз в несколько минут).
enum CatActivity: String, Codable, Hashable {
    case look, sit, loaf, lounge, hide, explore, play, scratch, groom, stretch, window, tv, drink, sleep, meow, eat, loved, offended, scared

    /// Старые позы без анимации больше не используются
    var isLegacy: Bool { false }
    var sprite: String { "cat_sit" }

    /// События (не обычное занятие): кошка не уходит с места
    var isEvent: Bool { self == .meow || self == .eat || self == .loved || self == .sleep || self == .offended || self == .scared }

    /// Основное состояние занятия
    var idleClip: String {
        switch self {
        case .look: return "front_idle"
        case .window: return "window"
        case .loaf: return "loaf"
        case .lounge: return "dangle"
        case .hide: return "blanket_idle"
        case .tv: return "tv"
        case .drink: return "drink"
        case .sleep: return "sleep"
        case .meow: return "meow"
        case .eat: return "eat"
        case .loved: return "purr"
        case .offended: return "offended"
        case .scared: return "scared"
        default: return "side_idle"
        }
    }

    /// Самый узнаваемый кадр занятия — для островка и экрана блокировки: (клип, кадр)
    var heroFrame: (String, Int) {
        switch self {
        case .look: return ("front_idle", 0)
        case .sit: return ("side_idle", 0)
        case .loaf: return ("loaf", 0)
        case .lounge: return ("dangle", 3)
        case .hide: return ("blanket_idle", 4)
        case .explore: return ("sniff", 3)
        case .play: return ("stalk", 2)
        case .scratch: return ("scratch", 3)
        case .groom: return ("wash", 3)
        case .stretch: return ("stretch", 4)
        case .window: return ("window", 0)
        case .tv: return ("tv", 0)
        case .drink: return ("drink", 2)
        case .sleep: return ("sleep", 0)
        case .meow: return ("meow", 4)
        case .eat: return ("eat", 3)
        case .loved: return ("purr", 3)
        case .offended: return ("offended", 0)
        case .scared: return ("scared", 4)
        }
    }

    /// Маленькие действия и дела: (клип, вес)
    var pool: [(String, Int)] {
        switch self {
        case .look: return [("front_idle", 4), ("front_blink", 3)]
        case .sit: return [("side_idle", 4), ("side_blink", 3), ("yawn", 1), ("standup", 1), ("headturn", 2), ("sneeze", 1), ("belly", 1)]
        case .explore: return [("walk", 4), ("sniff", 3), ("side_idle", 2), ("side_blink", 3)]
        case .play: return [("laser", 3), ("stalk", 2), ("pounce", 2), ("jump", 2), ("standup", 1), ("side_idle", 1), ("side_blink", 3)]
        case .scratch: return [("scratch", 5), ("walk", 1), ("side_idle", 1), ("side_blink", 3)]
        case .groom: return [("wash", 4), ("itch", 3), ("side_idle", 1), ("side_blink", 3)]
        case .stretch: return [("stretch", 4), ("yawn", 2), ("walk", 1), ("side_idle", 2), ("side_blink", 3)]
        case .window, .tv, .drink, .loaf, .lounge, .hide, .sleep, .meow, .eat, .offended, .scared: return [(idleClip, 1)]
        case .loved: return [("rub", 1), ("purr", 2), ("knead", 2)]
        }
    }

    /// Мордочка — для компактного островка и экрана блокировки.
    func face(angry: Bool) -> String {
        switch self {
        case .look, .sit, .explore, .window, .drink: return "face_neutral"
        case .loaf, .lounge, .hide: return "face_sleepy"
        case .play, .tv: return "face_curious"
        case .stretch, .eat, .groom: return "face_happy"
        case .scratch, .loved: return "face_wink"
        case .sleep: return "face_sleepy"
        case .offended: return "face_sad"
        case .scared: return "face_surprised"
        case .meow: return angry ? "face_angry" : "face_surprised"
        }
    }

    var emoji: String {
        switch self {
        case .look: return "👀"
        case .sit: return "😌"
        case .loaf: return "🍞"
        case .lounge: return "🛋️"
        case .hide: return "🧣"
        case .explore: return "🐾"
        case .play: return "🧶"
        case .scratch: return "🪵"
        case .groom: return "🧼"
        case .stretch: return "🙆"
        case .window: return "🪟"
        case .tv: return "📺"
        case .drink: return "💧"
        case .sleep: return "💤"
        case .meow: return "📢"
        case .eat: return "🐟"
        case .loved: return "💕"
        case .offended: return "😾"
        case .scared: return "🙀"
        }
    }

    func status(toy: CatToy?) -> String {
        switch self {
        case .look: return "Смотрит на тебя"
        case .sit: return "Просто сидит"
        case .loaf: return "Лежит буханкой"
        case .lounge: return "Свесила лапку"
        case .hide: return "Прячется под пледом"
        case .explore: return "Гуляет и всё нюхает"
        case .play: return "Охотится"
        case .scratch: return "Точит когти"
        case .groom: return "Умывается"
        case .stretch: return "Потягивается"
        case .window: return "Смотрит в окно"
        case .tv: return "Смотрит телевизор"
        case .drink: return "Пьёт водичку"
        case .sleep: return "Спит"
        case .meow: return "Мяукает! Покорми её"
        case .eat: return "Кушает"
        case .loved: return "Мурчит"
        case .offended: return "Обиделась. Разбудили!"
        case .scared: return "Испугалась!"
        }
    }

    var symbol: String {
        switch self {
        case .look: return "eye.fill"
        case .sit: return "leaf.fill"
        case .loaf: return "square.fill"
        case .lounge: return "sofa.fill"
        case .hide: return "eye.slash.fill"
        case .explore: return "pawprint.fill"
        case .play: return "sparkles"
        case .scratch: return "scribble"
        case .groom: return "drop.fill"
        case .stretch: return "figure.cooldown"
        case .window: return "window.casement"
        case .tv: return "tv.fill"
        case .drink: return "drop.fill"
        case .sleep: return "moon.zzz.fill"
        case .meow: return "speaker.wave.3.fill"
        case .eat: return "fork.knife"
        case .loved: return "heart.fill"
        case .offended: return "cloud.rain.fill"
        case .scared: return "bolt.fill"
        }
    }
}

/// Игрушки, которые появляются рядом с кошкой.
enum CatToy: String, Codable, Hashable, CaseIterable {
    case yarn, mouse, butterfly, feather, ball

    var imageName: String { "toy_" + rawValue }

    var withName: String {
        switch self {
        case .yarn: return "на клубок"
        case .mouse: return "на мышку"
        case .butterfly: return "на бабочку"
        case .feather: return "на пёрышко"
        case .ball: return "на мячик"
        }
    }
}

/// Что может сделать человек.
enum PetAction: String, Codable {
    case feed, pet, play
}

/// Данные Live Activity. ContentState — то, что меняется со временем.
struct PetAttributes: ActivityAttributes {
    public struct ContentState: Codable, Hashable {
        var name: String
        var activity: CatActivity
        var toy: CatToy?
        var phrase: String
        /// Место в виджете: 0 — левый край, 1 — правый
        var pos: Double
        /// Мяукает уже давно и сердится
        var angry: Bool = false
        /// Смотрит/идёт влево
        var facingLeft: Bool = false
        /// Маленькое действие прямо сейчас (клип из Clips), меняется каждые несколько секунд
        var clip: String = "front_idle"
        /// Какой кадр клипа показать в виджете (индекс в widgetFrames)
        var frameIndex: Int = 0
        /// Вариант картинки в свёрнутом островке (меняется раз в 3 минуты)
        var islandVariant: Int = 0
        /// Погода за окном — приложение передаёт её островку и экрану блокировки
        var weather: WeatherNow? = nil
    }

    /// Когда запущена эта Live Activity (iOS держит её ~8 часов).
    var startedAt: Date
}

extension Color {
    init(hex: UInt32) {
        self.init(
            .sRGB,
            red: Double((hex >> 16) & 0xFF) / 255,
            green: Double((hex >> 8) & 0xFF) / 255,
            blue: Double(hex & 0xFF) / 255,
            opacity: 1
        )
    }

    static let catAccent = Color(hex: 0xF4A7B9)   // розовые ушки
}
