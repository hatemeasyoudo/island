import Foundation
import ActivityKit
import SwiftUI

/// Чем кошка сейчас занята (крупное занятие, меняется раз в несколько минут).
enum CatActivity: String, Codable, Hashable {
    case look, curious, explore, play, scratch, groom, stretch, back, sleep, meow, eat, loved

    /// Позы из старого листа (без покадровой анимации)
    var isLegacy: Bool { self == .meow || self == .eat || self == .loved }

    /// Картинка для старых поз
    var sprite: String {
        switch self {
        case .meow: return "face_surprised"
        case .eat: return "face_happy"
        case .loved: return "cat_belly"
        case .back: return "cat_back1"
        default: return "cat_sit"
        }
    }

    /// Чем она занимается в спокойные моменты (и с чего начинает)
    var idleClip: String {
        switch self {
        case .look: return "front_idle"
        case .curious: return "up_idle"
        case .sleep: return "sleep"
        case .back: return "back"
        default: return "side_idle"
        }
    }

    /// Набор маленьких действий: (клип, вес). Выбираются случайно каждые несколько секунд.
    var pool: [(String, Int)] {
        switch self {
        case .look: return [("front_idle", 4), ("front_blink", 3), ("front_tail", 3), ("front_ear", 2)]
        case .curious: return [("up_idle", 4), ("up_blink", 3), ("up_ear", 3)]
        case .explore: return [("walk", 5), ("sniff", 3), ("side_idle", 2), ("side_blink", 2), ("side_tail", 2), ("side_ear", 1)]
        case .play: return [("stalk", 3), ("pounce", 2), ("jump", 2), ("playpaw", 3), ("side_tail", 1)]
        case .scratch: return [("walk", 2), ("scratch", 5), ("side_idle", 1), ("side_blink", 1)]
        case .groom: return [("wash", 5), ("itch", 3), ("side_idle", 1), ("side_blink", 2)]
        case .stretch: return [("stretch", 4), ("side_idle", 2), ("side_tail", 2), ("walk", 1)]
        case .back: return [("back", 1)]
        case .sleep: return [("sleep", 1)]
        case .meow, .eat, .loved: return [("front_idle", 1)]
        }
    }

    /// Мордочка — для компактного островка и экрана блокировки.
    func face(angry: Bool) -> String {
        switch self {
        case .look, .back, .explore: return "face_neutral"
        case .curious, .play: return "face_curious"
        case .stretch, .eat, .groom: return "face_happy"
        case .scratch: return "face_wink"
        case .sleep: return "cat_sleep"
        case .meow: return angry ? "face_angry" : "face_surprised"
        case .loved: return "face_wink"
        }
    }

    var emoji: String {
        switch self {
        case .look: return "👀"
        case .curious: return "❓"
        case .explore: return "🐾"
        case .play: return "🧶"
        case .scratch: return "🪵"
        case .groom: return "🧼"
        case .stretch: return "🙆"
        case .back: return "🪟"
        case .sleep: return "💤"
        case .meow: return "📢"
        case .eat: return "🐟"
        case .loved: return "💕"
        }
    }

    func status(toy: CatToy?) -> String {
        switch self {
        case .look: return "Смотрит на тебя"
        case .curious: return "Что-то заметила"
        case .explore: return "Гуляет и всё нюхает"
        case .play: return "Охотится \(toy?.withName ?? "")".trimmingCharacters(in: .whitespaces)
        case .scratch: return "Точит когти"
        case .groom: return "Умывается"
        case .stretch: return "Потягивается"
        case .back: return "Смотрит в окно"
        case .sleep: return "Спит"
        case .meow: return "Мяукает! Покорми её"
        case .eat: return "Кушает"
        case .loved: return "Мурчит"
        }
    }

    var symbol: String {
        switch self {
        case .look: return "eye.fill"
        case .curious: return "questionmark.circle.fill"
        case .explore: return "pawprint.fill"
        case .play: return "sparkles"
        case .scratch: return "scribble"
        case .groom: return "drop.fill"
        case .stretch: return "figure.cooldown"
        case .back: return "window.casement"
        case .sleep: return "moon.zzz.fill"
        case .meow: return "speaker.wave.3.fill"
        case .eat: return "fork.knife"
        case .loved: return "heart.fill"
        }
    }
}

/// Игрушки, которые появляются рядом с кошкой.
enum CatToy: String, Codable, Hashable, CaseIterable {
    case yarn, mouse, butterfly, feather, ball

    var imageName: String { "toy_" + rawValue }

    var withName: String {
        switch self {
        case .yarn: return "на клубок"
        case .mouse: return "на мышку"
        case .butterfly: return "на бабочку"
        case .feather: return "на пёрышко"
        case .ball: return "на мячик"
        }
    }
}

/// Что может сделать человек.
enum PetAction: String, Codable {
    case feed, pet, play
}

/// Данные Live Activity. ContentState — то, что меняется со временем.
struct PetAttributes: ActivityAttributes {
    public struct ContentState: Codable, Hashable {
        var name: String
        var activity: CatActivity
        var toy: CatToy?
        var phrase: String
        /// Место в виджете: 0 — левый край, 1 — правый
        var pos: Double
        /// Мяукает уже давно и сердится
        var angry: Bool = false
        /// Смотрит/идёт влево
        var facingLeft: Bool = false
        /// Маленькое действие прямо сейчас (клип из Clips), меняется каждые несколько секунд
        var clip: String = "front_idle"
        /// Какой кадр клипа показать в виджете (индекс в widgetFrames)
        var frameIndex: Int = 0
    }

    /// Когда запущена эта Live Activity (iOS держит её ~8 часов).
    var startedAt: Date
}

extension Color {
    init(hex: UInt32) {
        self.init(
            .sRGB,
            red: Double((hex >> 16) & 0xFF) / 255,
            green: Double((hex >> 8) & 0xFF) / 255,
            blue: Double(hex & 0xFF) / 255,
            opacity: 1
        )
    }

    static let catAccent = Color(hex: 0xF4A7B9)   // розовые ушки
}
