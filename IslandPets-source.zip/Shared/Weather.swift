import Foundation
import SwiftUI

/// Погода за окном. Источник — бесплатный Open-Meteo (без ключей и регистрации).
/// Город задаётся в настройках приложения; данные лежат в общей памяти, их видит и виджет.
enum WeatherKind: String, Codable {
    case clear, clouds, rain, snow, storm, fog
}

struct WeatherNow: Codable, Hashable {
    var kind: WeatherKind
    var isDay: Bool
    var temperature: Double
    var updated: Date
}

enum WeatherStore {
    private static var d: UserDefaults {
        CatBrain.groupID.flatMap { UserDefaults(suiteName: $0) } ?? .standard
    }

    static var city: String {
        get { d.string(forKey: "weather.city") ?? "" }
        set { d.set(newValue, forKey: "weather.city") }
    }

    static var coords: (Double, Double)? {
        guard d.object(forKey: "weather.lat") != nil else { return nil }
        return (d.double(forKey: "weather.lat"), d.double(forKey: "weather.lon"))
    }

    static var current: WeatherNow? {
        get {
            guard let data = d.data(forKey: "weather.now") else { return nil }
            return try? JSONDecoder().decode(WeatherNow.self, from: data)
        }
        set { d.set(try? JSONEncoder().encode(newValue), forKey: "weather.now") }
    }

    /// Что показать прямо сейчас: свежая погода или просто день/ночь по часам
    static func now(_ date: Date = Date()) -> WeatherNow {
        if let w = current, date.timeIntervalSince(w.updated) < 3 * 3600 { return w }
        let h = Calendar.current.component(.hour, from: date)
        return WeatherNow(kind: .clear, isDay: (7..<20).contains(h), temperature: 0, updated: date)
    }

    /// Найти город (Open-Meteo geocoding) и сохранить координаты. Возвращает найденное название.
    static func setCity(_ name: String) async -> String? {
        let trimmed = name.trimmingCharacters(in: .whitespaces)
        guard !trimmed.isEmpty,
              let q = trimmed.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed),
              let url = URL(string: "https://geocoding-api.open-meteo.com/v1/search?name=\(q)&count=1&language=ru") else { return nil }
        struct R: Decodable { struct P: Decodable { let name: String; let latitude: Double; let longitude: Double; let country: String? }; let results: [P]? }
        guard let (data, _) = try? await URLSession.shared.data(from: url),
              let r = try? JSONDecoder().decode(R.self, from: data),
              let p = r.results?.first else { return nil }
        d.set(p.latitude, forKey: "weather.lat")
        d.set(p.longitude, forKey: "weather.lon")
        let full = [p.name, p.country].compactMap { $0 }.joined(separator: ", ")
        city = full
        current = nil
        _ = await refresh(force: true)
        return full
    }

    /// Обновить погоду (не чаще раза в 30 минут)
    @discardableResult
    static func refresh(force: Bool = false, timeout: TimeInterval = 15) async -> WeatherNow? {
        guard let (lat, lon) = coords else { return nil }
        if !force, let w = current, Date().timeIntervalSince(w.updated) < 30 * 60 { return w }
        guard let url = URL(string: "https://api.open-meteo.com/v1/forecast?latitude=\(lat)&longitude=\(lon)&current=weather_code,is_day,temperature_2m") else { return nil }
        struct R: Decodable { struct C: Decodable { let weather_code: Int; let is_day: Int; let temperature_2m: Double }; let current: C }
        var req = URLRequest(url: url); req.timeoutInterval = timeout
        guard let (data, _) = try? await URLSession.shared.data(for: req),
              let r = try? JSONDecoder().decode(R.self, from: data) else { return nil }
        let w = WeatherNow(kind: kind(code: r.current.weather_code), isDay: r.current.is_day == 1,
                           temperature: r.current.temperature_2m, updated: Date())
        current = w
        NotificationCenter.default.post(name: .weatherChanged, object: nil)
        return w
    }

    /// Коды погоды WMO → наши виды
    static func kind(code: Int) -> WeatherKind {
        switch code {
        case 0, 1: return .clear
        case 2, 3: return .clouds
        case 45, 48: return .fog
        case 51...67, 80...82: return .rain
        case 71...77, 85, 86: return .snow
        case 95...99: return .storm
        default: return .clouds
        }
    }
}

/// Небо за стеклом. animated = true — капли и снег падают (в приложении), иначе застывший кадр (виджет).
struct WeatherWindowView: View {
    let weather: WeatherNow
    var animated: Bool = true

    var body: some View {
        if animated {
            TimelineView(.animation) { tl in
                Canvas { ctx, size in draw(&ctx, size, t: tl.date.timeIntervalSinceReferenceDate) }
            }
        } else {
            Canvas { ctx, size in draw(&ctx, size, t: 1.3) }
        }
    }

    private var skyColors: [Color] {
        switch (weather.kind, weather.isDay) {
        case (.clear, true): return [Color(hex: 0x7EC8F5), Color(hex: 0xCDEBFF)]
        case (.clear, false): return [Color(hex: 0x0E1435), Color(hex: 0x2A2F66)]
        case (.storm, _): return [Color(hex: 0x2B2F3E), Color(hex: 0x4A5066)]
        case (_, true): return [Color(hex: 0x9AA8B8), Color(hex: 0xD3DAE2)]
        case (_, false): return [Color(hex: 0x1A1F33), Color(hex: 0x353B55)]
        }
    }

    private func draw(_ ctx: inout GraphicsContext, _ size: CGSize, t: Double) {
        let r = CGRect(origin: .zero, size: size)
        ctx.fill(Path(r), with: .linearGradient(Gradient(colors: skyColors),
                                               startPoint: .zero, endPoint: CGPoint(x: 0, y: size.height)))
        let w = size.width, h = size.height
        // солнце или луна
        if weather.kind == .clear || weather.kind == .clouds {
            let c = CGPoint(x: w * 0.68, y: h * 0.2)
            let rad = w * 0.18
            if weather.isDay {
                ctx.fill(Path(ellipseIn: CGRect(x: c.x - rad * 1.6, y: c.y - rad * 1.6, width: rad * 3.2, height: rad * 3.2)),
                         with: .color(Color(hex: 0xFFF3B0).opacity(0.35)))
                ctx.fill(Path(ellipseIn: CGRect(x: c.x - rad, y: c.y - rad, width: rad * 2, height: rad * 2)), with: .color(Color(hex: 0xFFE27A)))
            } else {
                ctx.fill(Path(ellipseIn: CGRect(x: c.x - rad, y: c.y - rad, width: rad * 2, height: rad * 2)), with: .color(Color(hex: 0xF4F1DE)))
                ctx.fill(Path(ellipseIn: CGRect(x: c.x - rad * 0.45, y: c.y - rad * 1.15, width: rad * 2, height: rad * 2)), with: .color(skyColors[0]))
                for i in 0..<9 {
                    let x = Double((i * 37) % 100) / 100 * w, y = Double((i * 53) % 60) / 100 * h
                    let tw = 0.5 + 0.5 * sin(t * 2 + Double(i))
                    ctx.fill(Path(ellipseIn: CGRect(x: x, y: y, width: 2, height: 2)), with: .color(.white.opacity(0.4 + 0.5 * tw)))
                }
            }
        }
        // облака
        if weather.kind != .clear {
            let n = weather.kind == .clouds ? 2 : 3
            for i in 0..<n {
                let speed = 4.0 + Double(i) * 2
                let x = (t * speed + Double(i) * w * 0.6).truncatingRemainder(dividingBy: w * 1.6) - w * 0.4
                let y = h * (0.12 + 0.13 * Double(i))
                let cw = w * 0.7, chh = h * 0.08
                let col = weather.isDay && weather.kind != .storm ? Color.white.opacity(0.85) : Color(hex: 0x8A90A8).opacity(0.7)
                for (dx, dy, s) in [(0.0, 0.0, 1.0), (0.25, -0.5, 0.8), (0.5, 0.0, 0.9)] {
                    ctx.fill(Path(ellipseIn: CGRect(x: x + cw * dx, y: y + chh * dy, width: cw * 0.5 * s, height: chh * 2 * s)), with: .color(col))
                }
            }
        }
        // дождь
        if weather.kind == .rain || weather.kind == .storm {
            for i in 0..<40 {
                let seed = Double(i)
                let x = (seed * 37.3).truncatingRemainder(dividingBy: 1000) / 1000 * w
                let y = ((t * 1.4 + seed * 0.137).truncatingRemainder(dividingBy: 1)) * (h + 20) - 10
                var p = Path(); p.move(to: CGPoint(x: x, y: y)); p.addLine(to: CGPoint(x: x - 2, y: y + 9))
                ctx.stroke(p, with: .color(Color(hex: 0xDCEBFF).opacity(0.75)), lineWidth: 1.3)
            }
        }
        // гроза: вспышка
        if weather.kind == .storm, sin(t * 0.9) > 0.985 {
            ctx.fill(Path(r), with: .color(.white.opacity(0.5)))
        }
        // снег
        if weather.kind == .snow {
            for i in 0..<30 {
                let seed = Double(i)
                let x0 = (seed * 41.7).truncatingRemainder(dividingBy: 1000) / 1000 * w
                let y = ((t * 0.25 + seed * 0.173).truncatingRemainder(dividingBy: 1)) * (h + 10) - 5
                let x = x0 + 4 * sin(t + seed)
                let s = 2.0 + (seed.truncatingRemainder(dividingBy: 3))
                ctx.fill(Path(ellipseIn: CGRect(x: x, y: y, width: s, height: s)), with: .color(.white.opacity(0.9)))
            }
        }
        // туман
        if weather.kind == .fog {
            ctx.fill(Path(r), with: .color(.white.opacity(0.35)))
        }
        // блик на стекле
        var g = Path()
        g.move(to: CGPoint(x: w * 0.15, y: h)); g.addLine(to: CGPoint(x: w * 0.55, y: 0))
        g.addLine(to: CGPoint(x: w * 0.75, y: 0)); g.addLine(to: CGPoint(x: w * 0.35, y: h)); g.closeSubpath()
        ctx.fill(g, with: .color(.white.opacity(0.12)))
    }
}

extension Notification.Name {
    static let weatherChanged = Notification.Name("cat.weatherChanged")
}
