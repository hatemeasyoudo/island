import CoreGraphics

/// Размеры спрайтов в общих единицах: все позы в одном масштабе
/// (сидящая кошка ≈ 273 единицы в высоту). Поправлены позы, которые на листе нарисованы мельче.
enum Sprite {
    static let sizes: [String: CGSize] = [
        "cat_back1": CGSize(width: 178, height: 240),
        "cat_back2": CGSize(width: 178, height: 240),
        "cat_back3": CGSize(width: 178, height: 240),
        "cat_belly": CGSize(width: 241, height: 205),
        "cat_curious": CGSize(width: 171, height: 271),
        "cat_hunt": CGSize(width: 256, height: 228),
        "cat_sit": CGSize(width: 201, height: 273),
        "cat_sleep": CGSize(width: 227, height: 134),
        "cat_stretch": CGSize(width: 268, height: 269),
        "face_angry": CGSize(width: 143, height: 144),
        "face_curious": CGSize(width: 147, height: 165),
        "face_grumpy": CGSize(width: 139, height: 147),
        "face_happy": CGSize(width: 143, height: 163),
        "face_neutral": CGSize(width: 147, height: 161),
        "face_sad": CGSize(width: 142, height: 146),
        "face_surprised": CGSize(width: 146, height: 165),
        "face_wink": CGSize(width: 149, height: 154),
        "fx_anger": CGSize(width: 36, height: 38),
        "fx_heart": CGSize(width: 43, height: 37),
        "fx_paw": CGSize(width: 36, height: 40),
        "fx_sparkle": CGSize(width: 35, height: 37),
        "fx_zzz": CGSize(width: 51, height: 43),
        "walk1": CGSize(width: 353, height: 244),
        "walk2": CGSize(width: 353, height: 244),
        "walk3": CGSize(width: 353, height: 244),
        "walk4": CGSize(width: 353, height: 244),
        "walk5": CGSize(width: 353, height: 244),
    ]

    /// Рамка, в которую влезает любая поза (самая высокая и самая широкая).
    static let box = CGSize(width: 420, height: 300)

    static func size(_ name: String) -> CGSize { sizes[name] ?? CGSize(width: 200, height: 200) }
}
