import SwiftUI
import AppIntents

/// Строка «что она сейчас делает».
struct StatusLine: View {
    let state: PetAttributes.ContentState

    var body: some View {
        Label(state.activity.status(toy: state.toy), systemImage: state.activity.symbol)
            .font(.caption.weight(state.activity == .meow ? .bold : .regular))
            .foregroundStyle(state.activity == .meow ? Color.orange : Color.secondary)
            .lineLimit(1)
    }
}

/// Кнопки для островка и экрана блокировки (выполняются в приложении в фоне).
struct ActionRow: View {
    let state: PetAttributes.ContentState

    var body: some View {
        HStack(spacing: 6) {
            Button(intent: PetActionIntent(action: .feed)) {
                Label("Еда", systemImage: "fork.knife").frame(maxWidth: .infinity)
            }
            Button(intent: PetActionIntent(action: .pet)) {
                Label("Ласка", systemImage: "hand.raised.fill").frame(maxWidth: .infinity)
            }
            Button(intent: PetActionIntent(action: .play)) {
                Label("Игра", systemImage: "sparkles").frame(maxWidth: .infinity)
            }
        }
        .lineLimit(1)
        .minimumScaleFactor(0.7)
        .font(.caption2.weight(.semibold))
        .buttonStyle(.bordered)
        .tint(.catAccent)
    }
}
