import Foundation

/// Характер и распорядок дня кошки. Используется приложением, островком и виджетом.
///
/// Распорядок не хранится, а вычисляется из даты и личного «зерна» кошки:
/// поэтому виджет заранее знает, когда она уснёт или пойдёт играть, без участия приложения.
final class CatBrain {
    static let baseGroupID = "group.com.islandpets.app"

    // MARK: Характер — можно менять под себя
    static let slotMinutes = 4                           // как часто меняет занятие (минуты)
    /// Сколько кадров отдавать виджету за раз: iOS заранее «пропекает» каждый кадр,
    /// и чем их больше, тем дольше виджет реагирует на кнопки
    static let maxEntries = 120
    static let tickSeconds = 3                            // как часто делает маленькое действие (шаг, поворот)
    static let napsPerDay = 3...4                        // сколько раз в день спит
    static let napMinutes = 40...150                     // длина сна (в случайное время суток)
    static let meowWindow = (from: 9 * 60, to: 22 * 60)  // мяукает в случайное время с 9:00 до 22:00
    static let meowSkipIfFedWithin: TimeInterval = 2 * 3600  // не мяукает, если поели за 2 часа до этого
    static let eatDuration: TimeInterval = 5           // по кнопке ест 5 секунд
    static let lovedDuration: TimeInterval = 8         // ласка: потёрлась, помурчала, помяла лапками — 8 секунд
    static let fullFor: TimeInterval = 60 * 60          // после еды час сыта: на «Еду» только нюхает миску
    static let fullDuration: TimeInterval = 8
    static let purrSeconds: TimeInterval = 3             // мурчит вслух только столько за одну ласку
    static let playDuration: TimeInterval = 600
    static let widgetPlayActive: TimeInterval = 120     // в виджете после «Играть» 2 минуты активно охотится
    static let offendedDuration: TimeInterval = 60    // дуется после того, как разбудили
    static let scaredDuration: TimeInterval = 8
    static let startleAfter: TimeInterval = 6 * 3600   // пугается, если долго не открывали приложение
    static let angryAfter: TimeInterval = 90 * 60            // через сколько мяуканья начинает сердиться

    /// Общая память App Group (nil — если установщик её не выдал).
    static let groupID: String? = {
        var candidates = (Bundle.main.object(forInfoDictionaryKey: "ALTAppGroups") as? [String]) ?? []
        // Установщики (iloader, SideStore) переименовывают группу: group.<bundle id>.<team id>.
        // Настоящее имя лежит в профиле подписи внутри приложения — читаем его оттуда.
        candidates += profileAppGroups()
        if var bid = Bundle.main.bundleIdentifier {
            if bid.hasSuffix(".widget") { bid = String(bid.dropLast(".widget".count)) }
            candidates.append("group." + bid)
        }
        candidates.append(baseGroupID)
        return candidates.first {
            FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: $0) != nil
        }
    }()

    /// Группы из embedded.mobileprovision (профиль подписи, который кладёт установщик)
    private static func profileAppGroups() -> [String] {
        guard let url = Bundle.main.url(forResource: "embedded", withExtension: "mobileprovision"),
              let data = try? Data(contentsOf: url),
              let text = String(data: data, encoding: .isoLatin1),
              let start = text.range(of: "<?xml"),
              let end = text.range(of: "</plist>") else { return [] }
        let xml = String(text[start.lowerBound..<end.upperBound])
        guard let plistData = xml.data(using: .isoLatin1),
              let plist = try? PropertyListSerialization.propertyList(from: plistData, format: nil) as? [String: Any],
              let ent = plist["Entitlements"] as? [String: Any],
              let groups = ent["com.apple.security.application-groups"] as? [String] else { return [] }
        return groups
    }

    static var isShared: Bool { groupID != nil }

    private enum Key {
        static let name = "cat.name", island = "cat.island", meowEnabled = "cat.meowEnabled"
        static let seed = "cat.seed", installedAt = "cat.installedAt", lastFed = "cat.lastFed"
        static let reaction = "cat.reaction", reactionAt = "cat.reactionAt", reactionToy = "cat.reactionToy"
        static let awakeUntil = "cat.awakeUntil"
    }

    let d: UserDefaults
    private let cal = Calendar.current

    init() {
        if let g = Self.groupID, let shared = UserDefaults(suiteName: g) {
            d = shared
        } else {
            d = .standard
        }
        let now = Date()
        if d.object(forKey: Key.installedAt) == nil { d.set(now, forKey: Key.installedAt) }
        if d.object(forKey: Key.lastFed) == nil { d.set(now, forKey: Key.lastFed) }
    }

    // MARK: - Настройки

    var name: String {
        get {
            let n = d.string(forKey: Key.name)?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
            return n.isEmpty ? "Кошечка" : n
        }
        set { d.set(newValue, forKey: Key.name) }
    }

    var islandEnabled: Bool {
        get { d.object(forKey: Key.island) as? Bool ?? true }
        set { d.set(newValue, forKey: Key.island) }
    }

    var meowEnabled: Bool {
        get { d.object(forKey: Key.meowEnabled) as? Bool ?? true }
        set { d.set(newValue, forKey: Key.meowEnabled) }
    }

    var lastFed: Date {
        get { d.object(forKey: Key.lastFed) as? Date ?? Date() }
        set { d.set(newValue, forKey: Key.lastFed) }
    }

    /// Постоянное «зерно» характера: приложение и виджет считают один и тот же распорядок,
    /// даже если у них нет общей памяти.
    private var seed: UInt64 { 0x5EB_C47_2026 }
    private var installedAt: Date { d.object(forKey: Key.installedAt) as? Date ?? Date() }

    // MARK: - Детерминированный «случай»

    private static func mix(_ x: UInt64) -> UInt64 {
        var z = x &+ 0x9E3779B97F4A7C15
        z = (z ^ (z >> 30)) &* 0xBF58476D1CE4E5B9
        z = (z ^ (z >> 27)) &* 0x94D049BB133111EB
        return z ^ (z >> 31)
    }

    private func rnd(_ a: Int, _ b: Int) -> UInt64 {
        Self.mix(seed &+ Self.mix(UInt64(bitPattern: Int64(a)) &+ Self.mix(UInt64(bitPattern: Int64(b)))))
    }

    private func rnd(_ a: Int, _ b: Int, in range: ClosedRange<Int>) -> Int {
        range.lowerBound + Int(rnd(a, b) % UInt64(range.count))
    }

    // MARK: - Распорядок дня

    private func dayStart(_ date: Date, offset: Int = 0) -> Date {
        let s = cal.startOfDay(for: date)
        return cal.date(byAdding: .day, value: offset, to: s) ?? s
    }

    private func dayKey(_ dayStart: Date) -> Int {
        cal.ordinality(of: .day, in: .era, for: dayStart) ?? 0
    }

    /// Случайные промежутки в течение суток (сон, лоток).
    private func intervals(day: Date, kind: Int, count: Int, minutes: ClosedRange<Int>) -> [ClosedRange<Date>] {
        let key = dayKey(day)
        return (0..<count).map { i in
            let startMin = rnd(key, kind * 100 + i, in: 0...1439)
            let len = rnd(key, kind * 100 + 50 + i, in: minutes)
            let start = day.addingTimeInterval(Double(startMin) * 60)
            return start...start.addingTimeInterval(Double(len) * 60)
        }
    }

    private func naps(day: Date) -> [ClosedRange<Date>] {
        let key = dayKey(day)
        let count = rnd(key, 1, in: Self.napsPerDay)
        return intervals(day: day, kind: 2, count: count, minutes: Self.napMinutes)
    }

    /// Текущий сон (если спит). Сон, прерванный человеком, не считается.
    private func currentNap(_ now: Date) -> ClosedRange<Date>? {
        if let awake = d.object(forKey: Key.awakeUntil) as? Date, now < awake { return nil }
        for off in [0, -1] {
            if let n = naps(day: dayStart(now, offset: off)).first(where: { $0.contains(now) }) { return n }
        }
        return nil
    }

    /// Во сколько кошка мяукнет в этот день.
    func meowTime(day: Date) -> Date {
        let m = rnd(dayKey(day), 4, in: Self.meowWindow.from...Self.meowWindow.to)
        return day.addingTimeInterval(Double(m) * 60)
    }

    /// С какого момента мяукает (nil — не мяукает): время мяуканья наступило,
    /// а покормили до этого давно (или не кормили вовсе).
    func meowStart(_ now: Date) -> Date? {
        guard meowEnabled else { return nil }
        for off in [0, -1] {
            let t = meowTime(day: dayStart(now, offset: off))
            if t <= now, t >= installedAt, lastFed < t.addingTimeInterval(-Self.meowSkipIfFedWithin) {
                return t
            }
        }
        return nil
    }

    func isMeowing(_ now: Date) -> Bool { meowStart(now) != nil }

    /// Когда кошка будет мяукать в ближайшие дни (для уведомлений).
    func upcomingMeows(from now: Date, days: Int) -> [Date] {
        guard meowEnabled else { return [] }
        return (0..<days).compactMap { off in
            let t = meowTime(day: dayStart(now, offset: off))
            guard t > now, t >= installedAt else { return nil }
            if lastFed >= t.addingTimeInterval(-Self.meowSkipIfFedWithin) { return nil }
            return t
        }
    }

    // MARK: - Реакции на человека

    private func reaction(at now: Date) -> (CatActivity, CatToy?, Date)? {
        guard let raw = d.string(forKey: Key.reaction),
              let a = CatActivity(rawValue: raw),
              let at = d.object(forKey: Key.reactionAt) as? Date else { return nil }
        let dur = Self.duration(of: a)
        guard now >= at, now < at.addingTimeInterval(dur) else { return nil }
        let toy = d.string(forKey: Key.reactionToy).flatMap { CatToy(rawValue: $0) }
        return (a, toy, at)
    }

    /// Когда закончится текущая реакция (для расписания виджета).
    func reactionEnd(after now: Date) -> Date? {
        guard let r = reaction(at: now) else { return nil }
        let a = r.0, at = r.2
        let dur = Self.duration(of: a)
        return at.addingTimeInterval(dur)
    }

    static func duration(of a: CatActivity) -> TimeInterval {
        switch a {
        case .eat: return eatDuration
        case .loved: return lovedDuration
        case .groom: return fullDuration
        case .offended: return offendedDuration
        case .scared: return scaredDuration
        default: return playDuration
        }
    }

    /// Испугалась (например, когда долго не открывали приложение)
    func startle(at now: Date) {
        if currentNap(now) == nil { setReaction(.scared, toy: nil, at: now) }
    }

    /// Когда последний раз уделяли внимание (кормили, гладили, играли)
    var lastAttention: Date {
        get { d.object(forKey: "cat.lastAttention") as? Date ?? lastFed }
        set { d.set(newValue, forKey: "cat.lastAttention") }
    }

    /// Давно без внимания — мяукает зло
    static let ignoredAfter: TimeInterval = 7 * 3600
    /// Для тестов: включить занятие на 2 минуты
    func forceActivity(_ a: CatActivity, at now: Date) {
        d.set(a.rawValue, forKey: "cat.forced")
        d.set(now.addingTimeInterval(120), forKey: "cat.forcedUntil")
    }

    private func forced(_ now: Date) -> CatActivity? {
        guard let raw = d.string(forKey: "cat.forced"), let a = CatActivity(rawValue: raw),
              let until = d.object(forKey: "cat.forcedUntil") as? Date, now < until else { return nil }
        return a
    }

    /// Только что нажали «Поиграть»
    func justPlayed(_ now: Date) -> Bool {
        guard d.string(forKey: Key.reaction) == CatActivity.play.rawValue,
              let at = d.object(forKey: Key.reactionAt) as? Date else { return false }
        return now.timeIntervalSince(at) < 5
    }

    func feelsIgnored(_ now: Date) -> Bool { now.timeIntervalSince(lastAttention) > Self.ignoredAfter }

    func apply(_ action: PetAction, at now: Date) {
        lastAttention = now
        // если спала — просыпается до конца этого сна
        if let nap = currentNap(now) {
            d.set(nap.upperBound, forKey: Key.awakeUntil)
            // разбудили лаской или игрой — обиделась (еда всё прощает)
            if action != .feed {
                setReaction(.offended, toy: nil, at: now)
                return
            }
        }
        switch action {
        case .feed:
            let lastMeal = d.object(forKey: "cat.lastMeal") as? Date ?? .distantPast
            if now.timeIntervalSince(lastMeal) < Self.fullFor {
                // сыта: не ест, а облизывается и умывается
                if reaction(at: now)?.0 != .eat { setReaction(.groom, toy: nil, at: now) }
            } else {
                lastFed = now
                d.set(now, forKey: "cat.lastMeal")
                setReaction(.eat, toy: nil, at: now)
            }
        case .pet:
            setReaction(.loved, toy: nil, at: now)
        case .play:
            let toy = CatToy.allCases[Int(rnd(Int(now.timeIntervalSince1970), 9) % UInt64(CatToy.allCases.count))]
            setReaction(.play, toy: toy, at: now)
        }
    }

    private func setReaction(_ a: CatActivity, toy: CatToy?, at: Date) {
        d.set(a.rawValue, forKey: Key.reaction)
        d.set(at, forKey: Key.reactionAt)
        if let t = toy { d.set(t.rawValue, forKey: Key.reactionToy) } else { d.removeObject(forKey: Key.reactionToy) }
    }

    // MARK: - Состояние

    private func unit(_ a: Int, _ b: Int) -> Double {
        Double(rnd(a, b) % 10_000) / 10_000
    }

    /// Самый «выразительный» кадр маленького действия (глаза закрыты, ухо повёрнуто…)
    static func keyFrame(_ c: Clip) -> Int { c.frames[c.frames.count / 2] }

    static func isMicro(_ id: String) -> Bool {
        id.hasSuffix("_blink") || id.hasSuffix("_ear") || id.hasSuffix("_tail")
    }

    /// Выбрать клип из набора с весами (детерминированно)
    private func pick(_ pool: [(String, Int)], _ key: Int, _ salt: Int) -> String {
        let total = pool.reduce(0) { $0 + $1.1 }
        var r = Int(rnd(key, salt) % UInt64(max(1, total)))
        for (c, w) in pool {
            if r < w { return c }
            r -= w
        }
        return pool[0].0
    }

    // MARK: - Где она находится (виджет)

    /// Случайное «любимое место» на это занятие
    private func spotFor(_ slot: Int) -> Double { 0.15 + 0.7 * unit(slot, 20) }

    private func slotOf(_ d: Date) -> Int { Int(d.timeIntervalSince1970) / (Self.slotMinutes * 60) }

    /// Где она в начале занятия: если в этот момент спала — там, где легла.
    private func basePos(_ slot: Int, depth: Int = 0) -> Double {
        let start = Date(timeIntervalSince1970: Double(slot * Self.slotMinutes * 60))
        if depth < 3, let nap = currentNap(start) {
            return basePos(slotOf(nap.lowerBound), depth: depth + 1)
        }
        return spotFor(slot)
    }

    func state(at now: Date) -> PetAttributes.ContentState {
        let slotLen = Self.slotMinutes * 60
        let slot = Int(now.timeIntervalSince1970) / slotLen
        let slotStart = slot * slotLen
        var activity: CatActivity
        var toy: CatToy? = nil
        var phraseSeed = UInt64(slot)
        var pos = basePos(slot)
        let prevPos = basePos(slot - 1)
        // смотрит туда, откуда пришла
        var facingLeft = abs(pos - prevPos) > 0.02 ? pos < prevPos : rnd(slot, 10) % 2 == 0
        var angry = false
        var startKey = slot

        if let f = forced(now) {
            activity = f
            if f == .play { toy = .yarn }
        } else if let r = reaction(at: now) {
            activity = r.0
            toy = r.1
            phraseSeed = UInt64(Int(r.2.timeIntervalSince1970))
            startKey = Int(r.2.timeIntervalSince1970)
        } else if let m = meowStart(now) {
            activity = .meow
            angry = now.timeIntervalSince(m) > Self.angryAfter
        } else if let nap = currentNap(now) {
            activity = .sleep
            let k = Int(nap.lowerBound.timeIntervalSince1970)
            phraseSeed = UInt64(k / 60)
            pos = basePos(slotOf(nap.lowerBound))   // спит там, где легла
            facingLeft = rnd(k, 11) % 2 == 0
        } else {
            let r = rnd(slot, 3) % 100
            switch r {
            case 0..<9: activity = .look
            case 9..<16: activity = .sit
            case 16..<20: activity = .loaf
            case 20..<23: activity = .lounge
            case 23..<26: activity = .hide
            case 24..<40: activity = .explore
            case 40..<54: activity = .play
            case 54..<62: activity = .scratch
            case 62..<72: activity = .groom
            case 72..<78: activity = .stretch
            case 78..<87: activity = .window
            case 87..<94: activity = .tv
            default: activity = .drink
            }
            if activity == .play {
                toy = CatToy.allCases[Int(rnd(slot, 4) % UInt64(CatToy.allCases.count))]
            }
        }

        // Маленькие действия каждые несколько секунд
        var clip = activity.idleClip
        var frameIndex = -1
        let since = Int(now.timeIntervalSince1970) - max(slotStart, startKey > slotStart ? startKey : slotStart)
        let tick = max(0, since / Self.tickSeconds)
        if activity == .sleep, let nap = currentNap(now), now.timeIntervalSince(nap.lowerBound) < 6 {
            clip = "yawn"; frameIndex = 4
        } else if activity == .play, let r = reaction(at: now), now.timeIntervalSince(r.2) < Self.widgetPlayActive {
            // нажали «Играть»: сразу охотится, каждый кадр — новое движение охоты, без пауз и прогулок
            let seq: [(String, Int)] = [("laser", 1), ("laser", 3), ("laser", 5), ("stalk", 2), ("stalk", 5),
                                        ("pounce", 2), ("pounce", 4), ("laser", 7), ("jump", 2), ("jump", 4),
                                        ("stalk", 1), ("pounce", 6)]
            let step = seq[tick % seq.count]
            clip = step.0
            frameIndex = step.1
            if tick > 0, tick % 4 == 0 { facingLeft.toggle() }
        } else if activity.isEvent {
            // мяукает, ест, мурчит, спит — кадры по кругу
            if activity == .loved { clip = ["rub", "purr", "knead"][min(2, tick)] }
            let c = Clips.get(clip)
            frameIndex = c.widgetFrames[tick % c.widgetFrames.count]
        } else {
            // Спокойный ритм: в основном сидит, иногда моргает/шевелит ухом,
            // изредка делает что-то (идёт, нюхает, умывается…) и потом отдыхает.
            let pool = activity.pool
            // ходьба/прыжки на месте выглядят странно — в виджете она ходит только к новому месту
            let actions = pool.filter { !$0.0.hasSuffix("_idle") && !Self.isMicro($0.0)
                && (Clips.get($0.0).travel == 0 || $0.0 == "stalk" || $0.0 == "laser") }
            let micro = pool.filter { Self.isMicro($0.0) }
            var rest = 2
            for i in 0...tick {
                let key = slot &* 1000 &+ i
                let r = Int(rnd(key, 24) % 100)
                clip = activity.idleClip
                let idle = Clips.get(clip)
                frameIndex = (i % 2 == 0) ? idle.frames[0] : idle.frames[idle.frames.count / 2]   // дышит
                if i == 0 { continue }
                if rest > 0 {
                    rest -= 1
                    if r < 12, !micro.isEmpty {
                        clip = pick(micro, key, 25)
                        frameIndex = Self.keyFrame(Clips.get(clip))
                    }
                    continue
                }
                if r < 25, !actions.isEmpty {
                    clip = pick(actions, key, 21)
                    let c = Clips.get(clip)
                    if c.travel > 0 {
                        // в виджете рывки и подкрадывание — на месте, ходит она только к новому месту
                        frameIndex = c.frames[i % c.frames.count]
                        rest = 3
                    } else {
                        frameIndex = c.widgetFrames[c.widgetFrames.count / 2]
                        rest = 4
                    }
                } else if r < 35, !micro.isEmpty {
                    clip = pick(micro, key, 25)
                    frameIndex = Self.keyFrame(Clips.get(clip))
                }
            }
        }

        // Раз в 4 минуты (смена занятия) плавно переезжает на новое место — одним скольжением, без шагов
        let slotEnd = Date(timeIntervalSince1970: Double((slot + 1) * slotLen))
        let left = slotEnd.timeIntervalSince(now)
        if left <= Double(Self.tickSeconds), !activity.isEvent, currentNap(slotEnd) == nil {
            let target = basePos(slot + 1)
            if abs(target - pos) > 0.02 {
                facingLeft = target < pos
                pos = target
                clip = "walk"
                frameIndex = Clips.get("walk").frames[2]
            }
        }

        if frameIndex < 0 { frameIndex = Clips.get(clip).frames[0] }

        if activity == .hide, tick == 0 { clip = "blanket"; frameIndex = 3 }
        // еда и вода — иногда другим способом
        if clip == "drink", slot % 2 == 1 { clip = "drink_glass"; frameIndex = Clips.get(clip).widgetFrames[tick % 4] }
        if clip == "eat", Int(lastFed.timeIntervalSince1970) % 2 == 1 { clip = "eat_chip"; frameIndex = Clips.get(clip).widgetFrames[tick % 4] }
        if ["window", "tv", "drink", "drink_glass", "eat", "scratch", "knead", "dangle"].contains(clip) { facingLeft = false }
        let islandVariant = Int(now.timeIntervalSince1970 / 180) % 4

        return PetAttributes.ContentState(
            name: name,
            activity: activity,
            toy: toy,
            phrase: activity == .groom && reaction(at: now)?.0 == .groom
                ? ["Я сыта, спасибо 😌", "*облизывается* Уже поела", "Больше не влезет"][Int(rnd(Int(phraseSeed), 8) % 3)]
                : Phrases.pick(for: activity, seed: rnd(Int(phraseSeed), 8)),
            pos: pos,
            angry: angry,
            facingLeft: facingLeft,
            clip: clip,
            frameIndex: frameIndex,
            islandVariant: islandVariant
        )
    }

    /// Ближайшие моменты, когда состояние меняется (для расписания виджета):
    /// первые `liveMinutes` — каждые несколько секунд, дальше — раз в минуту.
    func timeline(from now: Date, liveMinutes: Double, hours: Double) -> [(Date, PetAttributes.ContentState)] {
        var result: [(Date, PetAttributes.ContentState)] = [(now, state(at: now))]
        var points: [Date] = []
        if let end = reactionEnd(after: now) { points.append(end.addingTimeInterval(1)) }
        let tick = Double(Self.tickSeconds)
        var t = (now.timeIntervalSince1970 / tick).rounded(.up) * tick
        let liveEnd = now.timeIntervalSince1970 + liveMinutes * 60
        while t < liveEnd {
            points.append(Date(timeIntervalSince1970: t))
            t += tick
        }
        let end = now.timeIntervalSince1970 + hours * 3600
        let slotLen = Double(Self.slotMinutes * 60)
        var se = (now.timeIntervalSince1970 / slotLen).rounded(.up) * slotLen
        while se < end {
            for back in [6.0, 3.0, 0.0] {
                points.append(Date(timeIntervalSince1970: se - back))
            }
            se += slotLen
        }
        // после «живых» минут — кадр раз в 30 секунд (редкие кадры = виджет быстро перестраивается)
        var m = (liveEnd / 30).rounded(.up) * 30
        while m < end {
            points.append(Date(timeIntervalSince1970: m))
            m += 30
        }
        for p in Array(Set(points)).sorted() where p > now {
            let s = state(at: p)
            if s != result.last?.1 { result.append((p, s)) }
            if result.count >= Self.maxEntries { break }
        }
        return result
    }

    /// Состояние без мелких движений — для островка (его нельзя обновлять каждые 3 секунды).
    func calmState(at now: Date) -> PetAttributes.ContentState {
        var s = state(at: now)
        s.pos = 0.5
        if s.activity.isEvent {
            // события (спит, ест, мурчит, мяукает…) показываем как есть
            let hero = s.activity.heroFrame
            s.clip = hero.0
            s.frameIndex = hero.1
            s.facingLeft = false
            return s
        }
        // экран блокировки и островок: случайная поза из текущего занятия,
        // меняется раз в 5 минут (если iOS даст приложению обновить островок)
        let bucket = Int(now.timeIntervalSince1970 / 300)
        let pool = s.activity.pool.filter { !Self.isMicro($0.0) && $0.0 != "walk" }
        let clip = pool.isEmpty ? s.activity.idleClip : pick(pool, bucket, 31)
        let c = Clips.get(clip)
        s.clip = clip
        s.frameIndex = c.widgetFrames[Int(rnd(bucket, 32) % UInt64(c.widgetFrames.count))]
        s.facingLeft = ["window", "tv", "drink", "drink_glass", "eat", "scratch", "knead", "dangle"].contains(clip)
            ? false : rnd(bucket, 33) % 2 == 0
        return s
    }
}

extension PetAttributes.ContentState {
    static var preview: PetAttributes.ContentState {
        PetAttributes.ContentState(name: "Кошечка", activity: .look, toy: nil, phrase: "*смотрит на тебя*", pos: 0.5)
    }
}
