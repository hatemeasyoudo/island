import CoreGraphics

/// Покадровые анимации (сгенерировано из раскадровок).
/// Картинки: f_<источник>_<n> — для приложения, w_<источник>_<n> — облегчённые для виджета.
struct Clip {
    let id: String
    let source: String
    let frames: [Int]
    let fps: Double
    let loops: Bool
    /// Скорость перемещения во время клипа (единиц Sprite в секунду), 0 — на месте
    let travel: Double
    let widgetFrames: [Int]
    let widgetFPS: Double
    /// Размер холста в единицах Sprite (все клипы в одном масштабе)
    let size: CGSize
    /// Готовые имена картинок (для старых поз), вместо f_/w_
    var custom: [String]? = nil

    var duration: Double { Double(frames.count) / fps }
    var widgetPeriod: Double { Double(widgetFrames.count) / widgetFPS }
    func appImage(_ i: Int) -> String {
        let n = frames[i % frames.count]
        if let c = custom { return c[n] }
        return "f_\(source)_\(n)"
    }
    func widgetImage(_ n: Int) -> String { custom.map { $0[n] } ?? "w_\(source)_\(n)" }
    var stillImage: String { widgetImage(widgetFrames[0]) }
}

enum Clips {
    static let all: [String: Clip] = [
        "front_idle": Clip(id: "front_idle", source: "front_breath", frames: [0, 1, 2, 3, 4, 3, 2, 1], fps: 5, loops: true, travel: 0, widgetFrames: [0, 1, 2, 3, 4, 3, 2, 1], widgetFPS: 4, size: CGSize(width: 208, height: 274)),
        "front_blink": Clip(id: "front_blink", source: "front_blink", frames: [0, 1, 2, 3, 4, 5, 6], fps: 14, loops: false, travel: 0, widgetFrames: [0, 1, 2, 3, 4, 5, 6, 0, 0, 0, 0, 0, 0, 0], widgetFPS: 7, size: CGSize(width: 204, height: 286)),
        "front_tail": Clip(id: "front_tail", source: "front_tail", frames: [0, 1, 2, 3, 4, 5, 6, 5, 4, 3, 2, 1], fps: 8, loops: false, travel: 0, widgetFrames: [0, 1, 2, 3, 4, 5, 6, 5, 4, 3, 2, 1], widgetFPS: 6, size: CGSize(width: 196, height: 294)),
        "front_ear": Clip(id: "front_ear", source: "front_ear", frames: [0, 1, 2, 3, 4, 3, 2, 1, 0], fps: 10, loops: false, travel: 0, widgetFrames: [0, 1, 2, 3, 4, 0, 0, 0], widgetFPS: 6, size: CGSize(width: 205, height: 278)),
        "up_idle": Clip(id: "up_idle", source: "side1_breath", frames: [0, 1, 2, 3, 4, 3, 2, 1], fps: 5, loops: true, travel: 0, widgetFrames: [0, 1, 2, 3, 4, 3, 2, 1], widgetFPS: 4, size: CGSize(width: 203, height: 287)),
        "up_blink": Clip(id: "up_blink", source: "side1_blink", frames: [0, 1, 2, 3, 4, 5], fps: 12, loops: false, travel: 0, widgetFrames: [0, 1, 2, 3, 4, 5, 0, 0, 0, 0, 0, 0], widgetFPS: 6, size: CGSize(width: 196, height: 296)),
        "up_ear": Clip(id: "up_ear", source: "side1_ear", frames: [0, 1, 2, 3, 4, 3, 2, 1, 0], fps: 10, loops: false, travel: 0, widgetFrames: [0, 1, 2, 3, 4, 0, 0, 0], widgetFPS: 6, size: CGSize(width: 205, height: 286)),
        "side_idle": Clip(id: "side_idle", source: "side_breath", frames: [0, 1, 2, 3, 2, 1], fps: 4, loops: true, travel: 0, widgetFrames: [0, 1, 2, 3, 2, 1], widgetFPS: 4, size: CGSize(width: 276, height: 218)),
        "side_blink": Clip(id: "side_blink", source: "side_blink", frames: [0, 1, 2, 3, 4, 5, 6, 7], fps: 12, loops: false, travel: 0, widgetFrames: [0, 1, 2, 3, 4, 5, 6, 7, 0, 0, 0, 0, 0, 0], widgetFPS: 7, size: CGSize(width: 241, height: 235)),
        "side_tail": Clip(id: "side_tail", source: "side_tail", frames: [0, 1, 2, 3, 4, 5, 6, 5, 4, 3, 2, 1], fps: 8, loops: false, travel: 0, widgetFrames: [0, 1, 2, 3, 4, 5, 6, 5, 4, 3, 2, 1], widgetFPS: 6, size: CGSize(width: 368, height: 284)),
        "side_ear": Clip(id: "side_ear", source: "side_ear", frames: [0, 1, 2, 3, 2, 1, 0], fps: 8, loops: false, travel: 0, widgetFrames: [0, 1, 2, 3, 0, 0], widgetFPS: 5, size: CGSize(width: 276, height: 217)),
        "walk": Clip(id: "walk", source: "walk", frames: [0, 1, 2, 3, 4], fps: 10, loops: true, travel: 75, widgetFrames: [0, 1, 2, 3, 4], widgetFPS: 10, size: CGSize(width: 297, height: 234)),
        "stalk": Clip(id: "stalk", source: "stalk", frames: [0, 1, 2, 3, 4, 5], fps: 6, loops: true, travel: 22, widgetFrames: [0, 1, 2, 3, 4, 5], widgetFPS: 6, size: CGSize(width: 415, height: 189)),
        "pounce": Clip(id: "pounce", source: "pounce", frames: [0, 1, 2, 3, 4, 5, 6], fps: 12, loops: false, travel: 230, widgetFrames: [2, 3, 4, 5, 6], widgetFPS: 10, size: CGSize(width: 365, height: 233)),
        "jump": Clip(id: "jump", source: "jump", frames: [0, 1, 2, 3, 4, 5, 6, 7], fps: 11, loops: false, travel: 200, widgetFrames: [0, 1, 2, 3, 4, 5, 6, 7], widgetFPS: 9, size: CGSize(width: 418, height: 331)),
        "sniff": Clip(id: "sniff", source: "sniff", frames: [0, 1, 2, 3, 4, 5, 6, 7, 8], fps: 7, loops: false, travel: 12, widgetFrames: [2, 3, 4, 5, 6, 7, 6, 5, 4, 3], widgetFPS: 6, size: CGSize(width: 448, height: 274)),
        "scratch": Clip(id: "scratch", source: "scratch", frames: [0, 1, 2, 3, 4, 5, 4, 5, 4, 5, 4, 3, 6], fps: 7, loops: false, travel: 0, widgetFrames: [3, 4, 5, 4], widgetFPS: 7, size: CGSize(width: 416, height: 294)),
        "wash": Clip(id: "wash", source: "wash", frames: [0, 1, 2, 3, 4, 5, 6, 7, 8, 7, 6, 5, 4, 5, 6, 7, 8], fps: 7, loops: false, travel: 0, widgetFrames: [2, 3, 4, 5, 6, 7, 8, 7, 6, 5, 4, 3], widgetFPS: 6, size: CGSize(width: 258, height: 293)),
        "itch": Clip(id: "itch", source: "itch", frames: [0, 1, 2, 3, 4, 3, 4, 3, 4, 3, 2, 5], fps: 7, loops: false, travel: 0, widgetFrames: [2, 3, 4, 3], widgetFPS: 7, size: CGSize(width: 448, height: 271)),
        "stretch": Clip(id: "stretch", source: "stretch", frames: [0, 1, 2, 3, 4, 5, 6, 7, 8], fps: 6, loops: false, travel: 0, widgetFrames: [2, 3, 4, 5, 6, 7, 6, 5, 4, 3], widgetFPS: 5, size: CGSize(width: 342, height: 290)),
        "playpaw": Clip(id: "playpaw", source: "playpaw", frames: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9], fps: 9, loops: false, travel: 0, widgetFrames: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 8, 7, 6, 5, 4, 3, 2, 1], widgetFPS: 8, size: CGSize(width: 303, height: 275)),
        "liedown": Clip(id: "liedown", source: "liedown", frames: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10], fps: 7, loops: false, travel: 0, widgetFrames: [10], widgetFPS: 1, size: CGSize(width: 462, height: 270)),
        "sleep": Clip(id: "sleep", source: "liedown", frames: [10], fps: 1, loops: true, travel: 0, widgetFrames: [10], widgetFPS: 1, size: CGSize(width: 462, height: 270)),
        "back": Clip(id: "back", source: "back", frames: [0, 1, 2, 1], fps: 3, loops: true, travel: 0, widgetFrames: [0, 1, 2, 1], widgetFPS: 3, size: CGSize(width: 178, height: 240), custom: ["cat_back1", "cat_back2", "cat_back3"]),
    ]

    static func get(_ id: String) -> Clip { all[id] ?? all["front_idle"]! }
}
