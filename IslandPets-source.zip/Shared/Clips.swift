import CoreGraphics

/// Покадровые анимации. Картинки: f_<источник>_<n> — приложение, w_<источник>_<n> — виджет.
struct Clip {
    let id: String
    let source: String
    let frames: [Int]
    let fps: Double
    let loops: Bool
    /// Скорость перемещения (единиц Sprite в секунду), 0 — на месте
    let travel: Double
    /// Кадры для виджета (по одному на шаг в 3 секунды)
    let widgetFrames: [Int]
    /// Размер холста в единицах Sprite
    let size: CGSize
    /// Где лапы относительно центра картинки (единицы Sprite)
    let anchorX: Double
    /// Где стекло окна в каждом кадре (единицы Sprite, от левого верхнего угла)
    var glass: [CGRect]? = nil
    /// На сколько опустить картинку ниже пола (единицы Sprite): лежит на полу, лапка свисает за нижний край
    var sink: Double = 0

    var duration: Double { Double(frames.count) / fps }
    func frameNumber(_ i: Int) -> Int { frames[((i % frames.count) + frames.count) % frames.count] }
    func appImage(_ i: Int) -> String { "f_\(source)_\(frameNumber(i))" }
    func widgetImage(_ n: Int) -> String { "w_\(source)_\(n)" }
    var stillImage: String { widgetImage(widgetFrames[0]) }
}

enum Clips {
    static let all: [String: Clip] = [
        "side_idle": Clip(id: "side_idle", source: "side_bc", frames: [0], fps: 1, loops: true, travel: 0, widgetFrames: [0], size: CGSize(width: 283, height: 303), anchorX: -2.5),
        "side_blink": Clip(id: "side_blink", source: "side_bc", frames: [0, 1, 1, 0], fps: 16, loops: false, travel: 0, widgetFrames: [1], size: CGSize(width: 283, height: 303), anchorX: -2.5),
        "front_idle": Clip(id: "front_idle", source: "front_bc", frames: [0], fps: 1, loops: true, travel: 0, widgetFrames: [0], size: CGSize(width: 242, height: 275), anchorX: 23.2),
        "front_blink": Clip(id: "front_blink", source: "front_bc", frames: [0, 1, 2, 2, 1, 0], fps: 18, loops: false, travel: 0, widgetFrames: [2], size: CGSize(width: 242, height: 275), anchorX: 23.2),
        "walk": Clip(id: "walk", source: "walk", frames: [0, 1, 2, 3, 4, 5, 6, 7], fps: 10, loops: true, travel: 75, widgetFrames: [0, 1, 2, 3, 4, 5, 6, 7], size: CGSize(width: 269, height: 221), anchorX: -14.4),
        "stalk": Clip(id: "stalk", source: "stalk", frames: [0, 1, 2, 3, 4, 5, 6, 7], fps: 6, loops: true, travel: 22, widgetFrames: [0, 1, 2, 3, 4, 5, 6, 7], size: CGSize(width: 358, height: 164), anchorX: 14.1),
        "pounce": Clip(id: "pounce", source: "pounce", frames: [0, 1, 2, 3, 4, 5, 6, 7], fps: 11, loops: false, travel: 140, widgetFrames: [0, 2, 4, 6], size: CGSize(width: 304, height: 206), anchorX: 16.3),
        "jump": Clip(id: "jump", source: "jump", frames: [0, 1, 2, 3, 4, 5, 6, 7], fps: 11, loops: false, travel: 140, widgetFrames: [0, 2, 4, 6], size: CGSize(width: 303, height: 201), anchorX: 5.8),
        "sniff": Clip(id: "sniff", source: "sniff", frames: [0, 1, 2, 3, 4, 5, 6, 7], fps: 6, loops: false, travel: 0, widgetFrames: [1, 3, 5], size: CGSize(width: 339, height: 155), anchorX: 8.7),
        "scratch": Clip(id: "scratch", source: "scratch", frames: [0, 1, 2, 3, 4, 5, 6, 7, 0, 1, 2, 3, 4, 5, 6, 7], fps: 8, loops: false, travel: 0, widgetFrames: [1, 3, 5], size: CGSize(width: 270, height: 222), anchorX: 27.0),
        "meow": Clip(id: "meow", source: "meow", frames: [0, 1, 2, 3, 4, 5, 6, 7], fps: 8, loops: true, travel: 0, widgetFrames: [0, 3, 4, 6], size: CGSize(width: 292, height: 307), anchorX: 3.9),
        "sleep": Clip(id: "sleep", source: "sleep", frames: [0, 1, 2, 3, 4, 5, 6, 7], fps: 3, loops: true, travel: 0, widgetFrames: [0, 2, 4, 6], size: CGSize(width: 248, height: 211), anchorX: -21.6),
        "eat": Clip(id: "eat", source: "eat", frames: [0, 1, 2, 3, 4, 5, 6, 7], fps: 7, loops: true, travel: 0, widgetFrames: [0, 2, 4, 6], size: CGSize(width: 271, height: 232), anchorX: 18.2),
        "purr": Clip(id: "purr", source: "purr", frames: [0, 1, 2, 3, 4, 5, 6, 7], fps: 7, loops: true, travel: 0, widgetFrames: [0, 2, 4, 6], size: CGSize(width: 287, height: 246), anchorX: -17.5),
        "window": Clip(id: "window", source: "window", frames: [0, 1, 2, 3, 4, 5, 6, 7], fps: 4, loops: true, travel: 0, widgetFrames: [0, 2, 4, 6], size: CGSize(width: 296, height: 309), anchorX: -22.5, glass: [CGRect(x: 229.3, y: 23.5, width: 47.8, height: 160.4), CGRect(x: 228.4, y: 23.5, width: 48.7, height: 160.4), CGRect(x: 230.1, y: 23.5, width: 47.8, height: 160.4), CGRect(x: 229.3, y: 21.9, width: 48.6, height: 161.2), CGRect(x: 230.1, y: 23.5, width: 47.8, height: 161.2), CGRect(x: 229.3, y: 22.7, width: 48.6, height: 161.2), CGRect(x: 230.1, y: 23.5, width: 48.6, height: 161.2), CGRect(x: 230.1, y: 22.7, width: 47.8, height: 161.2)]),
        "tv": Clip(id: "tv", source: "tv", frames: [0, 1, 2, 3, 4, 5, 6, 7], fps: 4, loops: true, travel: 0, widgetFrames: [0, 2, 4, 6], size: CGSize(width: 285, height: 201), anchorX: -31.1),
        "stretch": Clip(id: "stretch", source: "stretch", frames: [0, 1, 2, 3, 4, 5, 6, 7], fps: 6, loops: false, travel: 0, widgetFrames: [2, 4, 6], size: CGSize(width: 254, height: 214), anchorX: 1.0),
        "wash": Clip(id: "wash", source: "wash", frames: [0, 1, 2, 3, 4, 5, 6, 7, 3, 4, 5, 4, 3], fps: 7, loops: false, travel: 0, widgetFrames: [2, 4, 6], size: CGSize(width: 255, height: 264), anchorX: -6.7),
        "itch": Clip(id: "itch", source: "itch", frames: [0, 1, 2, 3, 4, 5, 6, 7], fps: 8, loops: false, travel: 0, widgetFrames: [1, 3, 5], size: CGSize(width: 308, height: 308), anchorX: 13.4),
        "standup": Clip(id: "standup", source: "standup", frames: [0, 1, 2, 3, 4, 5, 6, 7], fps: 7, loops: false, travel: 0, widgetFrames: [2, 4, 5], size: CGSize(width: 240, height: 331), anchorX: -8.9),
        "yawn": Clip(id: "yawn", source: "yawn", frames: [0, 1, 2, 3, 4, 5, 6, 7], fps: 6, loops: false, travel: 0, widgetFrames: [3, 4], size: CGSize(width: 215, height: 271), anchorX: -7.0),
        "drink": Clip(id: "drink", source: "drink", frames: [0, 1, 2, 3, 4, 5, 6, 7], fps: 6, loops: true, travel: 0, widgetFrames: [0, 2, 4, 6], size: CGSize(width: 348, height: 165), anchorX: 71.3),
        "offended": Clip(id: "offended", source: "offended", frames: [0, 1, 2, 3, 4, 5, 6, 7], fps: 5, loops: true, travel: 0, widgetFrames: [0, 2, 4, 6], size: CGSize(width: 326, height: 284), anchorX: 28.5),
        "scared": Clip(id: "scared", source: "scared", frames: [0, 1, 2, 3, 4, 4, 4, 5, 6, 7], fps: 8, loops: false, travel: 0, widgetFrames: [3, 4], size: CGSize(width: 278, height: 267), anchorX: -8.3),
        "loaf": Clip(id: "loaf", source: "loaf", frames: [0, 0, 0, 1, 2, 3, 4, 4, 3, 2, 1, 0, 0, 0, 5, 6, 7], fps: 3, loops: true, travel: 0, widgetFrames: [0, 4, 0, 6], size: CGSize(width: 217, height: 179), anchorX: -21.4),
        "laser": Clip(id: "laser", source: "laser", frames: [0, 1, 2, 1, 2, 3, 3, 4, 5, 6, 7], fps: 7, loops: false, travel: 90, widgetFrames: [1, 3, 5, 7], size: CGSize(width: 297, height: 202), anchorX: -4.0),
        "rub": Clip(id: "rub", source: "rub", frames: [0, 1, 2, 3, 4, 5, 6, 7], fps: 5, loops: true, travel: 0, widgetFrames: [0, 2, 4, 6], size: CGSize(width: 380, height: 335), anchorX: 8.7),
        "headturn": Clip(id: "headturn", source: "headturn", frames: [0, 1, 2, 3, 4, 5, 5, 5, 4, 3, 2, 1, 0], fps: 7, loops: false, travel: 0, widgetFrames: [3, 5], size: CGSize(width: 244, height: 294), anchorX: -16.4),
        "knead": Clip(id: "knead", source: "knead", frames: [0, 1, 2, 3, 4, 5, 6, 7], fps: 6, loops: true, travel: 0, widgetFrames: [0, 2, 4, 6], size: CGSize(width: 294, height: 266), anchorX: 38.4),
        "sneeze": Clip(id: "sneeze", source: "sneeze", frames: [0, 1, 2, 3, 4, 5, 6, 7], fps: 7, loops: false, travel: 0, widgetFrames: [3, 4], size: CGSize(width: 309, height: 300), anchorX: 23.5),
        "dangle": Clip(id: "dangle", source: "dangle", frames: [0, 1, 2, 3, 2, 1], fps: 4, loops: true, travel: 0, widgetFrames: [0, 2, 3, 2], size: CGSize(width: 267, height: 301), anchorX: 33.5, sink: 51.2),
        "belly": Clip(id: "belly", source: "belly", frames: [0, 1, 2, 3, 4, 5, 6, 7], fps: 5, loops: false, travel: 0, widgetFrames: [2, 3, 4, 5], size: CGSize(width: 359, height: 249), anchorX: -53.4),
        "blanket": Clip(id: "blanket", source: "blanket", frames: [0, 1, 2, 3, 4, 5, 6], fps: 5, loops: false, travel: 0, widgetFrames: [1, 3, 5, 6], size: CGSize(width: 423, height: 216), anchorX: 25.6),
        "blanket_idle": Clip(id: "blanket_idle", source: "blanket", frames: [4, 5, 6, 5, 4, 4], fps: 3, loops: true, travel: 0, widgetFrames: [4, 5, 6, 5], size: CGSize(width: 423, height: 216), anchorX: 25.6),
        "drink_glass": Clip(id: "drink_glass", source: "drink_glass", frames: [0, 1, 2, 3, 4, 5, 6, 7], fps: 6, loops: true, travel: 0, widgetFrames: [0, 3, 5, 7], size: CGSize(width: 285, height: 277), anchorX: 11.6),
        "eat_chip": Clip(id: "eat_chip", source: "eat_chip", frames: [0, 1, 2, 3, 4, 5, 6, 7], fps: 6, loops: true, travel: 0, widgetFrames: [1, 2, 4, 6], size: CGSize(width: 271, height: 306), anchorX: 14.2),
    ]

    static func get(_ id: String) -> Clip { all[id] ?? all["side_idle"]! }
}
