import AVFoundation

/// Звуки кошки: мяуканье и мурчание.
/// Категория .ambient — звук не играет, если включён беззвучный режим, и не прерывает музыку.
final class CatSounds {
    static let shared = CatSounds()

    var enabled: Bool {
        get { UserDefaults.standard.object(forKey: "cat.sounds") as? Bool ?? true }
        set {
            UserDefaults.standard.set(newValue, forKey: "cat.sounds")
            if !newValue { stopPurr() }
        }
    }

    private var players: [String: AVAudioPlayer] = [:]
    private var purrPlayer: AVAudioPlayer?

    private init() {
        try? AVAudioSession.sharedInstance().setCategory(.ambient, options: [.mixWithOthers])
        try? AVAudioSession.sharedInstance().setActive(true)
    }

    private func player(_ name: String) -> AVAudioPlayer? {
        if let p = players[name] { return p }
        guard let url = Bundle.main.url(forResource: name, withExtension: "m4a"),
              let p = try? AVAudioPlayer(contentsOf: url) else { return nil }
        p.prepareToPlay()
        players[name] = p
        return p
    }

    /// Обычное короткое «мяу»
    func meow() {
        play(["m_soft1", "m_soft2", "m_soft3", "m_soft4"].randomElement()!, volume: 0.7)
    }

    /// Злое протяжное «мяу» — когда к ней давно не подходили
    func angryMeow() {
        play(["m_angry1", "m_angry2", "m_angry3", "m_angry4"].randomElement()!, volume: 0.9)
    }

    private func play(_ name: String, volume: Float) {
        guard enabled, let p = player(name) else { return }
        p.volume = volume
        p.currentTime = 0
        p.play()
    }

    func setPurr(_ on: Bool) {
        on ? startPurr() : stopPurr()
    }

    private func startPurr() {
        guard enabled, purrPlayer == nil,
              let url = Bundle.main.url(forResource: "purr", withExtension: "m4a"),
              let p = try? AVAudioPlayer(contentsOf: url) else { return }
        p.numberOfLoops = -1
        p.volume = 0
        p.play()
        p.setVolume(0.7, fadeDuration: 0.6)
        purrPlayer = p
    }

    private func stopPurr() {
        guard let p = purrPlayer else { return }
        purrPlayer = nil
        p.setVolume(0, fadeDuration: 0.5)
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) { p.stop() }
    }
}
