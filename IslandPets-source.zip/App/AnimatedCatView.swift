import SwiftUI
import Combine

/// Живая кошка в приложении: проигрывает покадровые клипы (ходьба, нюхает, точит когти,
/// умывается, охотится, прыгает, моргает, виляет хвостом…) и сама решает, что делать дальше.
struct AnimatedCatView: View {
    let state: PetAttributes.ContentState

    @State private var clipID: String = "front_idle"
    @State private var clipStart = Date()
    @State private var clipLength: Double = 3        // сколько длится текущий клип
    @State private var startX: CGFloat = 0           // в пунктах от центра
    @State private var facingLeft = false
    @State private var roomHalf: CGFloat = 120       // половина ширины, по которой можно ходить
    @State private var activityStart = Date()

    private let brainTimer = Timer.publish(every: 0.1, on: .main, in: .common).autoconnect()

    var body: some View {
        TimelineView(.animation) { tl in
            GeometryReader { g in
                scene(now: tl.date, size: g.size)
                    .onAppear { roomHalf = max(40, g.size.width / 2 - 70); lastScale = scale(g.size) }
                    .onChange(of: g.size) { _, s in roomHalf = max(40, s.width / 2 - 70); lastScale = scale(s) }
            }
        }
        .onAppear { restart(for: state.activity) }
        .onChange(of: state.activity) { _, a in restart(for: a) }
        .onReceive(brainTimer) { now in
            if now.timeIntervalSince(clipStart) >= clipLength { nextClip(now) }
        }
    }

    // MARK: - Кадр

    private func scale(_ size: CGSize) -> CGFloat {
        min(size.height * 0.82 / Sprite.box.height, size.width / (Sprite.box.width * 1.25))
    }

    @ViewBuilder
    private func scene(now: Date, size: CGSize) -> some View {
        let t = now.timeIntervalSinceReferenceDate
        let k = scale(size)
        let floorY: CGFloat = size.height - 12
        let a = state.activity

        if a.isLegacy {
            legacy(a, t: t, k: k, size: size, floorY: floorY, now: now)
        } else {
            let clip = Clips.get(clipID)
            let elapsed = now.timeIntervalSince(clipStart)
            let x = size.width / 2 + currentX(elapsed: elapsed, clip: clip, k: k)
            let fi = clip.loops ? max(0, Int(elapsed * clip.fps)) : max(0, min(clip.frames.count - 1, Int(elapsed * clip.fps)))
            let cw = clip.size.width * k, ch = clip.size.height * k
            // прыжок/рывок: тень сжимается
            let shadow: CGFloat = (clipID == "jump" || clipID == "pounce") ? 0.75 : 1

            ZStack {
                Ellipse()
                    .fill(Color.black.opacity(0.33))
                    .frame(width: min(cw, 200 * k) * 0.75 * shadow, height: 11)
                    .blur(radius: 5)
                    .position(x: x, y: floorY - 2)

                Image(clip.appImage(fi))
                    .resizable()
                    .interpolation(.high)
                    .frame(width: cw, height: ch)
                    .scaleEffect(x: facingLeft ? -1 : 1, y: 1)
                    .position(x: x, y: floorY - ch / 2)
                    .id(clipID)
                    .transition(.opacity.animation(.easeInOut(duration: 0.15)))

                if a == .play, let toy = state.toy {
                    toyView(toy, t: t, x: x, k: k, floorY: floorY)
                }
                if a == .sleep {
                    let p = (t / 3.0).truncatingRemainder(dividingBy: 1)
                    SpriteImage(name: "fx_zzz", scale: CGFloat(0.45 + 0.35 * p))
                        .opacity(sin(p * .pi))
                        .position(x: x + cw * 0.3 + CGFloat(18 * p), y: floorY - ch - CGFloat(30 * p))
                }
                if a == .scratch && clipID == "scratch" && fi >= 3 && fi <= 9 {
                    let p = (t / 0.6).truncatingRemainder(dividingBy: 1)
                    SpriteImage(name: "fx_sparkle", scale: 0.3)
                        .opacity(sin(p * .pi))
                        .position(x: x + (facingLeft ? -1 : 1) * cw * 0.35, y: floorY - ch * 0.75)
                }
            }
        }
    }

    /// Положение по горизонтали: клипы с перемещением двигают кошку с постоянной скоростью
    private func currentX(elapsed: Double, clip: Clip, k: CGFloat) -> CGFloat {
        guard clip.travel > 0 else { return startX }
        let dir: CGFloat = facingLeft ? -1 : 1
        let moving = min(elapsed, clipLength)
        let x = startX + dir * CGFloat(clip.travel * moving) * k
        return max(-roomHalf, min(roomHalf, x))
    }

    // MARK: - Что делать дальше

    private func restart(for a: CatActivity) {
        activityStart = Date()
        if a == .sleep {
            start("liedown", at: Date())
        } else if !a.isLegacy {
            start(a.idleClip, at: Date())
        }
    }

    private func nextClip(_ now: Date) {
        let a = state.activity
        guard !a.isLegacy else { clipLength = 1e9; return }
        // зафиксировать, где она остановилась
        let k = lastScale
        startX = currentX(elapsed: now.timeIntervalSince(clipStart), clip: Clips.get(clipID), k: k)
        if a == .sleep { start("sleep", at: now); return }
        start(weightedPick(a.pool), at: now)
    }

    @State private var lastScale: CGFloat = 0.6

    private func start(_ id: String, at now: Date) {
        let clip = Clips.get(id)
        if clip.travel > 0 {
            // у стены — разворот, иногда разворачивается и сама
            if startX > roomHalf * 0.7 { facingLeft = true }
            else if startX < -roomHalf * 0.7 { facingLeft = false }
            else if Double.random(in: 0...1) < 0.3 { facingLeft.toggle() }
        } else if Double.random(in: 0...1) < 0.12 {
            facingLeft.toggle()
        }
        clipID = id
        clipStart = now
        if clip.loops {
            switch id {
            case "walk": clipLength = Double.random(in: 1.6...3.4)
            case "stalk": clipLength = Double.random(in: 2...4)
            case "sleep": clipLength = 1e9
            default: clipLength = Double.random(in: 2.5...5)
            }
        } else {
            clipLength = clip.duration + 0.05
        }
    }

    private func weightedPick(_ pool: [(String, Int)]) -> String {
        let total = pool.reduce(0) { $0 + $1.1 }
        var r = Int.random(in: 0..<max(1, total))
        for (c, w) in pool {
            if r < w { return c }
            r -= w
        }
        return pool[0].0
    }

    // MARK: - Игрушка

    @ViewBuilder
    private func toyView(_ toy: CatToy, t: Double, x: CGFloat, k: CGFloat, floorY: CGFloat) -> some View {
        let dir: CGFloat = facingLeft ? -1 : 1
        let ahead: CGFloat = x + dir * 170 * k
        switch toy {
        case .butterfly:
            let flap = CGFloat(0.5 + 0.5 * abs(sin(t * 14)))
            Image(toy.imageName).resizable().scaledToFit()
                .frame(width: 34, height: 34)
                .scaleEffect(x: flap, y: 1)
                .position(x: ahead + CGFloat(30 * sin(t * 0.9)), y: floorY - 230 * k + CGFloat(18 * sin(t * 1.8)))
        case .feather:
            Image(toy.imageName).resizable().scaledToFit()
                .frame(width: 40, height: 40)
                .rotationEffect(.degrees(25 * sin(t * 1.3)))
                .position(x: ahead + CGFloat(14 * sin(t * 0.7)), y: floorY - 190 * k + CGFloat(14 * sin(t * 1.3)))
        default:
            let bounce = CGFloat(abs(sin(t * 3)) * 26)
            Image(toy.imageName).resizable().scaledToFit()
                .frame(width: 30, height: 30)
                .rotationEffect(.degrees(t * 160))
                .position(x: ahead + CGFloat(16 * sin(t * 1.6)), y: floorY - 15 - bounce)
        }
    }

    // MARK: - Старые позы: мяукает, ест, на спинке

    @ViewBuilder
    private func legacy(_ a: CatActivity, t: Double, k: CGFloat, size: CGSize, floorY: CGFloat, now: Date) -> some View {
        let x = size.width / 2 + startX
        let name = a.sprite
        let sz = Sprite.size(name)
        let cw = sz.width * k, ch = sz.height * k
        let breath = CGFloat(1 + 0.015 * sin(t * 2 * .pi / 3))
        let meowJump: CGFloat = a == .meow ? CGFloat(pow(max(0, sin(t * 2 * .pi / 1.4)), 3) * 10) : 0
        let eatNod: CGFloat = a == .eat ? CGFloat(abs(sin(t * 2 * .pi / 1.0)) * 4) : 0
        let wiggle: Double = a == .loved ? 3 * sin(t * 2 * .pi / 1.4) : 0
        let top = floorY - ch

        ZStack {
            Ellipse()
                .fill(Color.black.opacity(0.33))
                .frame(width: cw * 0.7, height: 11)
                .blur(radius: 5)
                .position(x: x, y: floorY - 2)
            if a == .eat {
                let left = max(0.08, 1 - now.timeIntervalSince(activityStart) / CatBrain.eatDuration)
                BowlView(fill: left)
                    .frame(width: cw * 0.75, height: cw * 0.32)
                    .position(x: x, y: floorY - cw * 0.12)
                    .zIndex(2)
            }
            SpriteImage(name: name, scale: k)
                .scaleEffect(x: 1, y: breath, anchor: .bottom)
                .rotationEffect(.degrees(wiggle), anchor: .bottom)
                .offset(y: -meowJump + eatNod)
                .position(x: x, y: floorY - ch / 2)
                .zIndex(1)
            switch a {
            case .loved:
                ForEach(0..<3, id: \.self) { i in
                    let p: Double = (t / 2.4 + Double(i) / 3).truncatingRemainder(dividingBy: 1)
                    let side: CGFloat = i == 1 ? -1 : 1
                    SpriteImage(name: "fx_heart", scale: CGFloat(0.35 + 0.35 * p))
                        .opacity(sin(p * .pi))
                        .position(x: x + side * (cw * 0.3 + CGFloat(10 * sin(p * 7))), y: top + 20 - CGFloat(80 * p))
                }
                .zIndex(3)
            case .meow:
                Group {
                    if state.angry {
                        SpriteImage(name: "fx_anger", scale: CGFloat(0.6 + 0.12 * abs(sin(t * 4))))
                            .position(x: x + cw * 0.42, y: top + 18)
                    } else {
                        Text("Мяу!")
                            .font(.system(size: 20, weight: .heavy, design: .rounded))
                            .foregroundStyle(Color(hex: 0x3A3634))
                            .padding(.horizontal, 12)
                            .padding(.vertical, 5)
                            .background(Capsule().fill(Color.white))
                            .scaleEffect(CGFloat(1 + 0.1 * pow(max(0, sin(t * 2 * .pi / 1.4)), 3)))
                            .position(x: x + cw * 0.5, y: top + 4)
                    }
                }
                .zIndex(3)
            default:
                EmptyView()
            }
        }
    }
}
