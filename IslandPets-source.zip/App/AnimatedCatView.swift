import SwiftUI
import Combine

/// Живая кошка в приложении.
///
/// Ведёт себя как настоящая: бо́льшую часть времени спокойно сидит (дышит), иногда моргает,
/// шевелит ухом или хвостом, и лишь изредка что-то делает — идёт в другое место,
/// нюхает, умывается, точит когти, охотится. После каждого дела отдыхает.
struct AnimatedCatView: View {
    let state: PetAttributes.ContentState

    // текущий клип
    @State private var clipID: String = "front_idle"
    @State private var clipStart = Date()
    @State private var clipLength: Double = 1e9
    // положение: x — от центра комнаты, в пунктах
    @State private var x: CGFloat = 0
    @State private var walkFrom: CGFloat = 0
    @State private var walkTo: CGFloat = 0
    @State private var facingLeft = false
    // расписание
    @State private var nextMicro = Date().addingTimeInterval(3)     // моргнуть/ухо/хвост
    @State private var nextAction = Date().addingTimeInterval(8)    // настоящее дело
    @State private var activityStart = Date()
    @State private var room = CGSize(width: 340, height: 300)
    @State private var weather = WeatherStore.now()
    // плавная смена позы: предыдущий кадр растворяется
    @State private var prevImage: String? = nil
    @State private var prevSize: CGSize = .zero
    @State private var prevPos: CGPoint = .zero
    @State private var prevFlip = false
    @State private var switchAt = Date.distantPast
    private let fade: Double = 0.22

    private let brainTimer = Timer.publish(every: 0.1, on: .main, in: .common).autoconnect()

    var body: some View {
        TimelineView(.animation) { tl in
            GeometryReader { g in
                scene(now: tl.date, size: g.size)
                    .contentShape(Rectangle())
                    .gesture(SpatialTapGesture().onEnded { v in tapped(at: v.location.x - g.size.width / 2) })
                    .onAppear { room = g.size }
                    .onChange(of: g.size) { _, s in room = s }
            }
        }
        .onAppear { restart(for: state.activity); react(to: state.activity) }
        .onChange(of: state.activity) { _, a in restart(for: a); react(to: a) }
        .onDisappear { PurrHaptics.shared.set(false); CatSounds.shared.setPurr(false) }
        .onReceive(brainTimer) { now in think(now) }
        .onReceive(PetEngine.shared.$debugClip) { id in
            guard let id else { return }
            debugUntil = Date().addingTimeInterval(max(3, Clips.get(id).loops ? 5 : Clips.get(id).duration + 0.5))
            play(id, length: Clips.get(id).loops ? 5 : nil)
            PetEngine.shared.debugClip = nil
        }
        .task {
            await WeatherStore.refresh()
            weather = WeatherStore.now()
        }
    }

    // MARK: - Масштаб и границы

    private var k: CGFloat {
        min(room.height * 0.8 / Sprite.box.height, room.width / (Sprite.box.width * 1.45))
    }

    /// Насколько далеко от центра можно отойти, чтобы кошка целиком оставалась в комнате
    private func limit(for clipID: String) -> CGFloat {
        // самая широкая поза текущего занятия — чтобы после остановки ничего не обрезалось
        let widest = state.activity.pool.map { Clips.get($0.0).size.width }.max() ?? 0
        let w = min(300, max(Clips.get(clipID).size.width, widest)) * k
        return max(0, room.width / 2 - w / 2 - 6)
    }

    private func clampX(_ v: CGFloat, _ id: String) -> CGFloat {
        let l = limit(for: id)
        return max(-l, min(l, v))
    }

    // MARK: - Кадр

    @ViewBuilder
    private func scene(now: Date, size: CGSize) -> some View {
        let t = now.timeIntervalSinceReferenceDate
        let floorY: CGFloat = size.height - 12
        let a = state.activity

        if a.isLegacy {
            legacy(a, t: t, size: size, floorY: floorY, now: now)
        } else {
            let clip = Clips.get(clipID)
            let elapsed = max(0, now.timeIntervalSince(clipStart))
            let px = size.width / 2 + currentX(now)
            let fi = frameIndex(clip, elapsed)
            let cw = clip.size.width * k, ch = clip.size.height * k
            // картинку сдвигаем так, чтобы лапы стояли ровно в точке px
            let ix = px - CGFloat(clip.anchorX) * k * (facingLeft ? -1 : 1)
            let fadeP = min(1, now.timeIntervalSince(switchAt) / fade)
            let airborne = (clipID == "jump" || clipID == "pounce")

            ZStack {
                Ellipse()
                    .fill(Color.black.opacity(0.33))
                    .frame(width: min(cw, 200 * k) * (airborne ? 0.55 : 0.75), height: 11)
                    .blur(radius: 5)
                    .position(x: px, y: floorY - 2)

                if let prev = prevImage, fadeP < 1 {
                    Image(prev)
                        .resizable()
                        .interpolation(.high)
                        .frame(width: prevSize.width, height: prevSize.height)
                        .scaleEffect(x: prevFlip ? -1 : 1, y: 1)
                        .position(prevPos)
                        .opacity(1 - fadeP)
                }

                if let glass = clip.glass {
                    let gr = glass[clip.frameNumber(fi) % glass.count]
                    let left = ix - cw / 2
                    let gx = facingLeft ? left + (clip.size.width - gr.maxX) * k + gr.width * k / 2 : left + gr.midX * k
                    WeatherWindowView(weather: weather, animated: true)
                        .frame(width: gr.width * k, height: gr.height * k)
                        .position(x: gx, y: floorY - ch + gr.midY * k)
                }

                Image(clip.appImage(fi))
                    .resizable()
                    .interpolation(.high)
                    .frame(width: cw, height: ch)
                    .scaleEffect(x: facingLeft ? -1 : 1, y: 1)
                    // мягкое дыхание, пока сидит или спит
                    .scaleEffect(x: 1, y: breathing(t), anchor: .bottom)
                    .position(x: ix, y: floorY - ch / 2 + CGFloat(clip.sink) * k)
                    .opacity(prevImage == nil ? 1 : max(0.0, min(1.0, fadeP * 1.4)))

                if clipID == "laser" {
                    // красная точка лазера бегает по полу перед ней
                    let n = clip.frameNumber(fi)
                    let dir: CGFloat = facingLeft ? -1 : 1
                    let jitter = CGFloat(sin(t * 7) * 6 + sin(t * 13) * 3)
                    let ahead: CGFloat = n < 4 ? cw * 0.55 + jitter : (n < 7 ? cw * 0.5 : cw * 0.75 + jitter)
                    Circle()
                        .fill(Color.red)
                        .frame(width: 7, height: 7)
                        .shadow(color: .red, radius: 5)
                        .position(x: px + dir * ahead, y: floorY - 3)
                }
                if a == .meow && state.angry {
                    SpriteImage(name: "fx_anger", scale: CGFloat(0.9 + 0.15 * abs(sin(t * 4))))
                        .position(x: px + cw * 0.3, y: floorY - ch + 20)
                }
                if a == .loved {
                    ForEach(0..<2, id: \.self) { i in
                        let p: Double = (t / 2.8 + Double(i) / 2).truncatingRemainder(dividingBy: 1)
                        SpriteImage(name: "fx_heart", scale: CGFloat(0.5 + 0.5 * p))
                            .opacity(sin(p * .pi))
                            .position(x: px + (i == 0 ? 1 : -1) * cw * 0.3, y: floorY - ch + 30 - CGFloat(70 * p))
                    }
                }
            }
        }
    }

    /// Дыхание: едва заметно, во сне медленнее и глубже
    private func breathing(_ t: Double) -> CGFloat {
        if clipID == "sleep" { return CGFloat(1 + 0.018 * sin(t * 2 * .pi / 4.5)) }
        if isIdle(clipID) || isMicro(clipID) { return CGFloat(1 + 0.008 * sin(t * 2 * .pi / 3.6)) }
        return 1
    }

    /// Во время ходьбы — плавно от точки к точке с постоянной скоростью
    private func currentX(_ now: Date) -> CGFloat {
        let clip = Clips.get(clipID)
        guard clip.travel > 0, clipLength > 0 else { return x }
        let p = CGFloat(min(1, max(0, now.timeIntervalSince(clipStart) / clipLength)))
        return walkFrom + (walkTo - walkFrom) * p
    }

    // MARK: - Поведение

    private func restart(for a: CatActivity) {
        activityStart = Date()
        guard !a.isLegacy else { return }
        if ["window", "tv", "drink", "eat", "knead", "dangle"].contains(a.idleClip) { facingLeft = false }

        if a == .sleep {
            play("yawn")      // сначала зевает, потом засыпает
        } else if a == .loved {
            play("rub", length: 3)   // сначала трётся о экран
        } else if a == .hide {
            play("blanket")          // заползает под плед
        } else if a == .eat || a == .drink {
            // иногда другим способом: из стакана, с вкусняшкой
            play(Bool.random() ? a.idleClip : (a == .eat ? "eat_chip" : "drink_glass"), length: 1e9)
        } else {
            play(a.idleClip, length: 1e9)
        }
        nextMicro = Date().addingTimeInterval(.random(in: 2...4))
        nextAction = Date().addingTimeInterval(.random(in: 10...20))
        if a == .play && CatBrain().justPlayed(Date()) {
            // нажали «Поиграть» — сразу охотится
            nextAction = Date()
        }
    }

    /// Звуки и вибрация под настроение
    private func react(to a: CatActivity) {
        PurrHaptics.shared.set(a == .loved)
        CatSounds.shared.setPurr(a == .loved)
        switch a {
        case .meow: meowNow(); lastMeow = Date()
        default: break
        }
    }

    @State private var lastMeow = Date.distantPast
    @State private var debugUntil = Date.distantPast

    /// Злое «мяу», если давно не уделяли внимания, иначе обычное
    private func meowNow() {
        // мяукает вслух только если к ней не подходили 7+ часов
        if CatBrain().feelsIgnored(Date()) { CatSounds.shared.angryMeow() }
    }

    private func think(_ now: Date) {
        // пока мяукает — «мяу» каждые 4–7 секунд
        if state.activity == .meow, now.timeIntervalSince(lastMeow) > Double.random(in: 4...7) {
            meowNow()
            lastMeow = now
        }
        let a = state.activity
        guard !a.isLegacy else { return }
        let elapsed = now.timeIntervalSince(clipStart)
        if now < debugUntil {
            if elapsed >= clipLength { play(a.idleClip, length: 1e9); debugUntil = .distantPast }
            return
        }

        // ласка: трётся, мурчит, мнёт лапками — по очереди
        if a == .loved {
            if elapsed >= clipLength {
                let order = ["rub", "purr", "knead", "purr"]
                let next = order[((order.firstIndex(of: clipID) ?? 0) + 1) % order.count]
                play(next, length: next == "rub" ? 3 : 4.5)
            }
            return
        }

        // моргнула — снова просто сидит (дыхание идёт непрерывно)
        if elapsed >= clipLength && isMicro(clipID) {
            play(a.idleClip, length: 1e9)
            return
        }
        // клип закончился — вернуться к спокойному сидению
        if elapsed >= clipLength {
            x = currentX(now)
            if a == .sleep {
                play("sleep", length: 1e9)
            } else if a == .hide {
                play("blanket_idle", length: 1e9)
            } else {
                play(a.idleClip, length: 1e9)
                // после дела — отдых
                nextAction = max(nextAction, now.addingTimeInterval(a == .play ? .random(in: 2...5) : .random(in: 15...30)))
                nextMicro = now.addingTimeInterval(.random(in: 1...3))
            }
            return
        }

        // во время дела ничего не перебиваем
        guard isIdle(clipID), a != .sleep else { return }

        if now >= nextAction {
            startAction(a, now)
        } else if now >= nextMicro {
            let micro = a.pool.filter { isMicro($0.0) }
            if !micro.isEmpty {
                play(weightedPick(micro))
            }
            // моргает постоянно, как живая: раз в 2–6 секунд, иногда дважды подряд
            nextMicro = now.addingTimeInterval(Double.random(in: 0...1) < 0.25 ? 0.45 : .random(in: 2...6))
        }
    }

    /// Тап по комнате: далеко — идёт туда, близко — поворачивает голову
    private func tapped(at tx: CGFloat) {
        let a = state.activity
        guard !a.isEvent, isIdle(clipID) || isMicro(clipID) else { return }
        let now = Date()
        if abs(tx - x) > 70, Clips.get(a.idleClip).id == "side_idle" || a == .look || a == .loaf {
            let target = clampX(tx, "walk")
            snapshot()
            facingLeft = target < x
            walkFrom = x
            walkTo = target
            play("walk", length: Double(abs(target - x)) / (Clips.get("walk").travel * k), snapped: true)
        } else {
            play("headturn")
        }
        nextAction = now.addingTimeInterval(.random(in: 12...20))
    }

    private func startAction(_ a: CatActivity, _ now: Date) {
        let actions = a.pool.filter { !isMicro($0.0) && !isIdle($0.0) }
        guard !actions.isEmpty else {
            nextAction = now.addingTimeInterval(20)
            return
        }
        let id = weightedPick(actions)
        let clip = Clips.get(id)

        if id == "walk" || id == "stalk" {
            // пойти в другое место комнаты
            let l = limit(for: id)
            var target = CGFloat.random(in: -l...l)
            if abs(target - x) < 70 { target = x > 0 ? x - CGFloat.random(in: 80...160) : x + CGFloat.random(in: 80...160) }
            target = clampX(target, id)
            let dist = abs(target - x)
            guard dist > 30 else { nextAction = now.addingTimeInterval(4); return }
            snapshot()
            facingLeft = target < x
            walkFrom = x
            walkTo = target
            play(id, length: Double(dist) / (clip.travel * k), snapped: true)
        } else if clip.travel > 0 {
            // рывок/прыжок — только если впереди есть место
            snapshot()
            let dist = CGFloat(clip.travel * clip.duration) * k
            let ahead = x + (facingLeft ? -dist : dist)
            if abs(ahead) > limit(for: id) { facingLeft.toggle() }
            let to = clampX(x + (facingLeft ? -dist : dist), id)
            walkFrom = x
            walkTo = to
            play(id, snapped: true)
        } else {
            play(id)
        }
        nextAction = now.addingTimeInterval(a == .play ? .random(in: 3...6) : .random(in: 25...45))
    }

    private func frameIndex(_ clip: Clip, _ elapsed: Double) -> Int {
        clip.loops ? Int(elapsed * clip.fps) : min(clip.frames.count - 1, Int(elapsed * clip.fps))
    }

    /// Запомнить текущий кадр — он плавно растворится при смене позы
    private func snapshot() {
        let old = Clips.get(clipID)
        let now = Date()
        let oldFi = frameIndex(old, max(0, now.timeIntervalSince(clipStart)))
        let ow = old.size.width * k, oh = old.size.height * k
        let ox = room.width / 2 + currentX(now) - CGFloat(old.anchorX) * k * (facingLeft ? -1 : 1)
        prevImage = state.activity.isLegacy ? nil : old.appImage(oldFi)
        prevSize = CGSize(width: ow, height: oh)
        prevPos = CGPoint(x: ox, y: room.height - 12 - oh / 2)
        prevFlip = facingLeft
        switchAt = now
    }

    private func play(_ id: String, length: Double? = nil, snapped: Bool = false) {
        let sameBase = Clips.get(clipID).source == Clips.get(id).source
        if !snapped { snapshot() }
        // моргание поверх той же позы — без растворения, чтобы было чётко
        if sameBase { prevImage = nil }
        let clip = Clips.get(id)
        clipID = id
        clipStart = Date()
        clipLength = length ?? (clip.loops ? 1e9 : clip.duration)
    }

    private func isIdle(_ id: String) -> Bool { id.hasSuffix("_idle") || id == state.activity.idleClip }
    private func isMicro(_ id: String) -> Bool { id.hasSuffix("_blink") || id.hasSuffix("_ear") || id.hasSuffix("_tail") }

    private func weightedPick(_ pool: [(String, Int)]) -> String {
        let total = pool.reduce(0) { $0 + $1.1 }
        var r = Int.random(in: 0..<max(1, total))
        for (c, w) in pool {
            if r < w { return c }
            r -= w
        }
        return pool[0].0
    }

    // MARK: - Игрушка

    @ViewBuilder
    private func toyView(_ toy: CatToy, t: Double, x: CGFloat, floorY: CGFloat) -> some View {
        let dir: CGFloat = facingLeft ? -1 : 1
        let ahead: CGFloat = x + dir * 150 * k
        switch toy {
        case .butterfly:
            let flap = CGFloat(0.5 + 0.5 * abs(sin(t * 12)))
            Image(toy.imageName).resizable().scaledToFit()
                .frame(width: 30, height: 30)
                .scaleEffect(x: flap, y: 1)
                .position(x: ahead + CGFloat(22 * sin(t * 0.7)), y: floorY - 220 * k + CGFloat(14 * sin(t * 1.4)))
        case .feather:
            Image(toy.imageName).resizable().scaledToFit()
                .frame(width: 36, height: 36)
                .rotationEffect(.degrees(20 * sin(t * 1.1)))
                .position(x: ahead + CGFloat(10 * sin(t * 0.6)), y: floorY - 180 * k + CGFloat(10 * sin(t * 1.1)))
        default:
            Image(toy.imageName).resizable().scaledToFit()
                .frame(width: 28, height: 28)
                .rotationEffect(.degrees(10 * sin(t * 0.8)))
                .position(x: ahead + CGFloat(6 * sin(t * 0.8)), y: floorY - 14)
        }
    }

    // MARK: - Старые позы: мяукает, ест, на спинке

    @ViewBuilder
    private func legacy(_ a: CatActivity, t: Double, size: CGSize, floorY: CGFloat, now: Date) -> some View {
        let name = a.sprite
        let sz = Sprite.size(name)
        let cw = sz.width * k, ch = sz.height * k
        let px = size.width / 2 + max(-(size.width / 2 - cw / 2 - 6), min(size.width / 2 - cw / 2 - 6, x))
        let breath = CGFloat(1 + 0.012 * sin(t * 2 * .pi / 3.2))
        let meowJump: CGFloat = a == .meow ? CGFloat(pow(max(0, sin(t * 2 * .pi / 1.6)), 4) * 6) : 0
        let eatNod: CGFloat = a == .eat ? CGFloat(abs(sin(t * 2 * .pi / 1.2)) * 3) : 0
        let wiggle: Double = a == .loved ? 2 * sin(t * 2 * .pi / 1.8) : 0
        let top = floorY - ch

        ZStack {
            Ellipse()
                .fill(Color.black.opacity(0.33))
                .frame(width: cw * 0.7, height: 11)
                .blur(radius: 5)
                .position(x: px, y: floorY - 2)
            if a == .eat {
                let left = max(0.08, 1 - now.timeIntervalSince(activityStart) / CatBrain.eatDuration)
                BowlView(fill: left)
                    .frame(width: cw * 0.75, height: cw * 0.32)
                    .position(x: px, y: floorY - cw * 0.12)
                    .zIndex(2)
            }
            SpriteImage(name: name, scale: k)
                .scaleEffect(x: 1, y: breath, anchor: .bottom)
                .rotationEffect(.degrees(wiggle), anchor: .bottom)
                .offset(y: -meowJump + eatNod)
                .position(x: px, y: floorY - ch / 2)
                .zIndex(1)
            switch a {
            case .loved:
                ForEach(0..<2, id: \.self) { i in
                    let p: Double = (t / 2.8 + Double(i) / 2).truncatingRemainder(dividingBy: 1)
                    let side: CGFloat = i == 1 ? -1 : 1
                    SpriteImage(name: "fx_heart", scale: CGFloat(0.3 + 0.3 * p))
                        .opacity(sin(p * .pi))
                        .position(x: px + side * cw * 0.3, y: top + 20 - CGFloat(70 * p))
                }
                .zIndex(3)
            case .meow:
                Group {
                    if state.angry {
                        SpriteImage(name: "fx_anger", scale: 0.6)
                            .position(x: px + cw * 0.42, y: top + 18)
                    } else {
                        Text("Мяу!")
                            .font(.system(size: 20, weight: .heavy, design: .rounded))
                            .foregroundStyle(Color(hex: 0x3A3634))
                            .padding(.horizontal, 12)
                            .padding(.vertical, 5)
                            .background(Capsule().fill(Color.white))
                            .position(x: px + cw * 0.5, y: top + 4)
                    }
                }
                .zIndex(3)
            default:
                EmptyView()
            }
        }
    }
}
