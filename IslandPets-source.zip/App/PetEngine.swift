import Foundation
import ActivityKit
import SwiftUI
import WidgetKit
import UserNotifications

/// Кошка в приложении: состояние (через CatBrain), островок, виджеты и уведомления о мяуканье.
@MainActor
final class PetEngine: ObservableObject {
    static let shared = PetEngine()

    static let restartAfter: TimeInterval = 7 * 3600     // перезапуск островка при открытии приложения
    static let islandLifetime: TimeInterval = 8 * 3600   // примерный лимит iOS для Live Activity

    private let brain: CatBrain

    @Published private(set) var state: PetAttributes.ContentState
    @Published private(set) var activityStartedAt: Date? = nil
    @Published private(set) var lastError: String? = nil
    @Published var islandEnabled: Bool {
        didSet {
            brain.islandEnabled = islandEnabled
            Task { await self.sync(canStart: true) }
        }
    }
    @Published var widgetAnimation: Bool {
        didSet {
            brain.widgetAnimation = widgetAnimation
            WidgetCenter.shared.reloadAllTimelines()
        }
    }
    @Published var meowEnabled: Bool {
        didSet {
            brain.meowEnabled = meowEnabled
            Task { await self.sync(canStart: true) }
        }
    }

    private init() {
        let b = CatBrain()
        brain = b
        islandEnabled = b.islandEnabled
        meowEnabled = b.meowEnabled
        widgetAnimation = b.widgetAnimation
        state = b.calmState(at: Date())
    }

    var name: String { brain.name }

    func setName(_ n: String) {
        brain.name = n
        Task { await sync(canStart: true) }
    }

    // MARK: - Действия

    func perform(_ action: PetAction, canStart: Bool) async {
        brain.apply(action, at: Date())
        await sync(canStart: canStart)
    }

    // MARK: - Островок, виджеты, уведомления

    /// Пересчитать состояние и обновить всё.
    /// canStart = true только когда приложение открыто: iOS разрешает запускать Live Activity лишь из активного приложения.
    func sync(canStart: Bool) async {
        let st = brain.calmState(at: Date())
        state = st
        WidgetCenter.shared.reloadAllTimelines()
        scheduleMeowNotifications()

        let content = ActivityContent(state: st, staleDate: nil)
        let all = Activity<PetAttributes>.activities

        guard islandEnabled else {
            for a in all { await a.end(content, dismissalPolicy: .immediate) }
            activityStartedAt = nil
            return
        }

        var current = all.first { $0.activityState == .active || $0.activityState == .stale }

        for a in all where a.id != current?.id {
            await a.end(nil, dismissalPolicy: .immediate)
        }

        if let c = current, canStart,
           Date().timeIntervalSince(c.attributes.startedAt) > Self.restartAfter {
            await c.end(nil, dismissalPolicy: .immediate)
            current = nil
        }

        if let c = current {
            if c.content.state != st { await c.update(content) }
            activityStartedAt = c.attributes.startedAt
        } else if canStart {
            start(st)
        } else {
            activityStartedAt = nil
        }
    }

    /// Лёгкое обновление, пока приложение открыто (занятия меняются со временем).
    func tick() async {
        let st = brain.calmState(at: Date())
        guard st != state else { return }
        await sync(canStart: false)
    }

    func restartIsland() async {
        for a in Activity<PetAttributes>.activities {
            await a.end(nil, dismissalPolicy: .immediate)
        }
        let st = brain.calmState(at: Date())
        state = st
        start(st)
    }

    private func start(_ st: PetAttributes.ContentState) {
        guard ActivityAuthorizationInfo().areActivitiesEnabled else {
            lastError = "Live Activities выключены в настройках"
            return
        }
        let attrs = PetAttributes(startedAt: Date())
        do {
            _ = try Activity.request(attributes: attrs,
                                     content: ActivityContent(state: st, staleDate: nil),
                                     pushType: nil)
            activityStartedAt = attrs.startedAt
            lastError = nil
        } catch {
            lastError = "Не удалось поселить в островок: \(error.localizedDescription)"
        }
    }

    // MARK: - Уведомления «Мяу!»

    func requestNotificationPermission() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound]) { _, _ in }
    }

    private func scheduleMeowNotifications() {
        let center = UNUserNotificationCenter.current()
        let ids = (0..<7).map { "meow-\($0)" }
        center.removePendingNotificationRequests(withIdentifiers: ids)
        for (i, t) in brain.upcomingMeows(from: Date(), days: 7).enumerated() {
            let content = UNMutableNotificationContent()
            content.title = brain.name
            content.body = "Мяу! Мяу! Покорми меня 🐟"
            content.sound = .default
            let trigger = UNTimeIntervalNotificationTrigger(timeInterval: max(5, t.timeIntervalSinceNow), repeats: false)
            center.add(UNNotificationRequest(identifier: ids[i], content: content, trigger: trigger))
        }
    }
}
