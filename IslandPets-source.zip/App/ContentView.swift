import SwiftUI
import WidgetKit
import ActivityKit

struct ContentView: View {
    @EnvironmentObject private var engine: PetEngine
    @State private var nameDraft = ""
    @State private var cityDraft = WeatherStore.city
    @State private var cityStatus = ""
    @FocusState private var nameFocused: Bool

    // Пока приложение открыто занятия кошки обновляются
    private let tickTimer = Timer.publish(every: 5, on: .main, in: .common).autoconnect()

    var body: some View {
        let s = engine.state
        ZStack {
            LinearGradient(colors: [Color(hex: 0x2B2140), Color(hex: 0x120E1C)],
                           startPoint: .top, endPoint: .bottom)
                .ignoresSafeArea()

            ScrollView {
                VStack(spacing: 16) {
                    room(s)
                    actions
                    settings
                    debugCard
                    islandCard
                    widgetCard
                }
                .padding(16)
            }
            .scrollDismissesKeyboard(.interactively)
        }
        .onAppear {
            nameDraft = engine.name
        }
        .onReceive(tickTimer) { _ in Task { await engine.tick() } }
    }

    // MARK: - Комната, где кошка гуляет

    private func room(_ s: PetAttributes.ContentState) -> some View {
        VStack(spacing: 10) {
            AnimatedCatView(state: s)
                .frame(height: 300)
                .background(
                    // «пол» комнаты
                    VStack {
                        Spacer()
                        LinearGradient(colors: [Color.white.opacity(0.0), Color.white.opacity(0.06)],
                                       startPoint: .top, endPoint: .bottom)
                            .frame(height: 60)
                    }
                )
                .clipShape(RoundedRectangle(cornerRadius: 22))

            Text(s.name)
                .font(.system(.largeTitle, design: .rounded).weight(.bold))

            Label(s.activity.status(toy: s.toy), systemImage: s.activity.symbol)
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(s.activity == .meow ? Color.orange : Color.catAccent)

            Text("«\(s.phrase)»")
                .foregroundStyle(.white.opacity(0.75))
                .multilineTextAlignment(.center)
        }
        .padding(18)
        .frame(maxWidth: .infinity)
        .background(RoundedRectangle(cornerRadius: 28).fill(.white.opacity(0.06)))
    }

    // MARK: - Кнопки

    private var actions: some View {
        HStack(spacing: 10) {
            bigButton("Покормить", "fork.knife", .feed)
            bigButton("Погладить", "hand.raised.fill", .pet)
            bigButton("Поиграть", "sparkles", .play)
        }
    }

    private func bigButton(_ title: String, _ icon: String, _ action: PetAction) -> some View {
        Button {
            Task { await engine.perform(action, canStart: true) }
        } label: {
            VStack(spacing: 6) {
                Image(systemName: icon).font(.title2)
                Text(title).font(.caption.weight(.semibold))
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 14)
            .background(RoundedRectangle(cornerRadius: 20).fill(.white.opacity(0.08)))
        }
        .buttonStyle(.plain)
    }

    // MARK: - Настройки

    private var settings: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("Кошечка").font(.headline)

            HStack {
                TextField("Имя", text: $nameDraft)
                    .focused($nameFocused)
                    .submitLabel(.done)
                    .onSubmit { engine.setName(nameDraft) }
                    .padding(12)
                    .background(RoundedRectangle(cornerRadius: 14).fill(.white.opacity(0.08)))
                if nameFocused {
                    Button("Готово") {
                        nameFocused = false
                        engine.setName(nameDraft)
                    }
                }
            }

            VStack(alignment: .leading, spacing: 6) {
                Text("Погода за окном").font(.subheadline.weight(.semibold))
                HStack {
                    TextField("Город, например Минск", text: $cityDraft)
                        .submitLabel(.search)
                        .onSubmit { findCity() }
                        .padding(10)
                        .background(RoundedRectangle(cornerRadius: 12).fill(.white.opacity(0.08)))
                    Button("Найти") { findCity() }
                }
                Text(cityStatus.isEmpty ? weatherLine : cityStatus)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Toggle(isOn: $engine.soundsEnabled) {
                VStack(alignment: .leading, spacing: 2) {
                    Text("Звуки").font(.subheadline.weight(.semibold))
                    Text("Мяуканье и мурчание. Злое «мяу» — если долго к ней не подходить. В беззвучном режиме не слышно.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            .tint(.catAccent)

            Toggle(isOn: $engine.meowEnabled) {
                VStack(alignment: .leading, spacing: 2) {
                    Text("Мяукать").font(.subheadline.weight(.semibold))
                    Text("Не чаще раза в день, в случайное время. Перестанет, когда покормишь. Придёт уведомление.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            .tint(.catAccent)
        }
        .padding(18)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(RoundedRectangle(cornerRadius: 28).fill(.white.opacity(0.06)))
    }

    private var weatherLine: String {
        guard !WeatherStore.city.isEmpty else { return "Когда кошка смотрит в окно, там будет погода этого города." }
        guard let w = WeatherStore.current else { return WeatherStore.city }
        let names: [WeatherKind: String] = [.clear: "ясно", .clouds: "облачно", .rain: "дождь", .snow: "снег", .storm: "гроза", .fog: "туман"]
        return "\(WeatherStore.city): \(names[w.kind] ?? ""), \(Int(w.temperature.rounded()))°"
    }

    private func findCity() {
        cityStatus = "Ищу…"
        Task {
            if let found = await WeatherStore.setCity(cityDraft) {
                cityDraft = found
                cityStatus = ""
                WidgetCenter.shared.reloadAllTimelines()
            } else {
                cityStatus = "Не нашла такой город"
            }
        }
    }

    // MARK: - Тест: все действия (временно)

    private var debugCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Тест: все действия").font(.headline)
            Text("Нажми — кошка сразу покажет действие. Ниже — занятия на 2 минуты (видно и в виджете, и в островке).")
                .font(.caption)
                .foregroundStyle(.secondary)
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 100), spacing: 6)], spacing: 6) {
                ForEach(Self.debugClips, id: \.0) { item in
                    Button(item.1) { engine.debugClip = item.0 }
                        .font(.caption2.weight(.semibold))
                        .lineLimit(1)
                        .minimumScaleFactor(0.7)
                        .frame(maxWidth: .infinity)
                        .buttonStyle(.bordered)
                        .tint(.catAccent)
                }
            }
            Text("Занятия").font(.subheadline.weight(.semibold)).padding(.top, 4)
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 100), spacing: 6)], spacing: 6) {
                ForEach(Self.debugActivities, id: \.self) { a in
                    Button("\(a.emoji) \(a.status(toy: nil))") { engine.debugActivity(a) }
                        .font(.caption2.weight(.semibold))
                        .lineLimit(1)
                        .minimumScaleFactor(0.6)
                        .frame(maxWidth: .infinity)
                        .buttonStyle(.bordered)
                }
            }
        }
        .padding(18)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(RoundedRectangle(cornerRadius: 28).fill(.white.opacity(0.06)))
    }

    static let debugClips: [(String, String)] = [
        ("side_blink", "Моргает сбоку"), ("front_blink", "Моргает спереди"), ("walk", "Идёт"), ("stalk", "Крадётся"),
        ("pounce", "Рывок"), ("jump", "Прыжок"), ("laser", "Лазер"), ("sniff", "Нюхает"), ("scratch", "Когти"),
        ("wash", "Умывается"), ("itch", "Чешется"), ("stretch", "Потягивается"), ("yawn", "Зевает"),
        ("sneeze", "Чихает"), ("standup", "На задних лапках"), ("headturn", "Поворот головы"), ("belly", "На спинку"),
        ("loaf", "Буханка"), ("dangle", "Свесила лапку"), ("blanket", "Под плед"), ("blanket_idle", "Под пледом"),
        ("window", "Окно"), ("tv", "Телевизор"), ("drink", "Пьёт из миски"), ("drink_glass", "Пьёт из стакана"),
        ("eat", "Ест из миски"), ("eat_chip", "Ест вкусняшку"), ("rub", "Трётся"), ("purr", "Мурчит"),
        ("knead", "Мнёт лапками"), ("meow", "Мяукает"), ("sleep", "Спит"), ("offended", "Обиделась"), ("scared", "Испугалась"),
    ]

    static let debugActivities: [CatActivity] = [
        .look, .sit, .loaf, .lounge, .hide, .explore, .play, .scratch, .groom, .stretch,
        .window, .tv, .drink, .sleep, .meow, .eat, .loved, .offended, .scared,
    ]

    // MARK: - Островок

    private var islandCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Toggle(isOn: $engine.islandEnabled) {
                VStack(alignment: .leading, spacing: 2) {
                    Text("Жить в Dynamic Island").font(.headline)
                    Text("Сверни приложение, и кошечка появится у камеры")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            .tint(.catAccent)

            if !ActivityAuthorizationInfo().areActivitiesEnabled {
                Label("Live Activities выключены. Включи: Настройки → Островок → Live Activities",
                      systemImage: "exclamationmark.triangle.fill")
                    .font(.caption)
                    .foregroundStyle(.orange)
            } else if engine.islandEnabled {
                if let started = engine.activityStartedAt {
                    Text("iOS держит кошечку в островке до \(started.addingTimeInterval(PetEngine.islandLifetime), style: .time). Открывай приложение хотя бы раз в 7 часов, и она будет жить дальше.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    Button("Перезапустить островок") {
                        Task { await engine.restartIsland() }
                    }
                    .font(.caption.weight(.semibold))
                } else {
                    Button("Поселить в островок") {
                        Task { await engine.restartIsland() }
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.catAccent)
                }
            }

            if let e = engine.lastError {
                Text(e).font(.caption2).foregroundStyle(.red)
            }
        }
        .padding(18)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(RoundedRectangle(cornerRadius: 28).fill(.white.opacity(0.06)))
    }

    // MARK: - Виджет

    private var widgetCard: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Виджет").font(.headline)
            Text("В виджете кошечка живёт без ограничения по времени: гуляет, нюхает, точит когти, умывается, охотится и спит. Зажми пустое место на экране → «+» → найди «Островок». Лучше всего — средний или большой размер.")
                .font(.caption)
                .foregroundStyle(.secondary)
            if CatBrain.isShared {
                Label("Виджет, островок и приложение — одна и та же кошечка", systemImage: "checkmark.circle.fill")
                    .font(.caption)
                    .foregroundStyle(.green)
            } else {
                Label("Установщик не выдал общую память: в виджете кормление и игры не связаны с приложением", systemImage: "info.circle.fill")
                    .font(.caption)
                    .foregroundStyle(.orange)
            }
        }
        .padding(18)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(RoundedRectangle(cornerRadius: 28).fill(.white.opacity(0.06)))
    }
}
