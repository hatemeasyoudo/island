import WidgetKit
import SwiftUI
import AppIntents

// MARK: - Кнопки в виджете

/// Действие из виджета. Выполняется в самом виджете, приложение открывать не нужно.
struct WidgetPetIntent: AppIntent {
    static var title: LocalizedStringResource = "Позаботиться о кошке (виджет)"
    static var isDiscoverable: Bool = false

    @Parameter(title: "Действие")
    var action: String

    init() {}

    init(action: PetAction) {
        self.action = action.rawValue
    }

    func perform() async throws -> some IntentResult {
        if let a = PetAction(rawValue: action) {
            CatBrain().apply(a, at: Date())
        }
        return .result() // после этого iOS сама перерисует виджет
    }
}

// MARK: - Расписание кадров

struct PetEntry: TimelineEntry {
    let date: Date
    let state: PetAttributes.ContentState
}

/// Настройки виджета: город для погоды за окном.
/// Нужен, когда у виджета нет общей памяти с приложением (оранжевая отметка в приложении).
struct CatWidgetConfig: WidgetConfigurationIntent {
    static var title: LocalizedStringResource = "Кошечка"
    static var description = IntentDescription("Город для погоды за окном.")

    @Parameter(title: "Город (погода за окном)")
    var city: String?

    init() {}
}

struct PetProvider: AppIntentTimelineProvider {
    func placeholder(in context: Context) -> PetEntry {
        PetEntry(date: Date(), state: .preview)
    }

    func snapshot(for configuration: CatWidgetConfig, in context: Context) async -> PetEntry {
        let now = Date()
        return PetEntry(date: now, state: CatBrain().state(at: now))
    }

    func timeline(for configuration: CatWidgetConfig, in context: Context) async -> Timeline<PetEntry> {
        // город из настроек виджета (если у виджета нет общей памяти с приложением)
        let city = (configuration.city ?? "").trimmingCharacters(in: .whitespaces)
        if !city.isEmpty, !WeatherStore.city.lowercased().hasPrefix(city.lowercased()) {
            _ = await WeatherStore.setCity(city)
        } else if (WeatherStore.current.map { Date().timeIntervalSince($0.updated) > 45 * 60 } ?? true) {
            // погоду подтягиваем только если она совсем устарела — чтобы кнопки отзывались быстро
            await WeatherStore.refresh(timeout: 2)
        }
        // Первые 4 минуты — действие каждые 3 секунды, дальше раз в 30 секунд.
        let now = Date()
        let frames = CatBrain().timeline(from: now, liveMinutes: 4, hours: 1)
        let entries = frames.map { PetEntry(date: $0.0, state: $0.1) }
        // когда кадры кончатся — iOS запросит новые (обычно сразу, но может и позже)
        return Timeline(entries: entries, policy: .atEnd)
    }
}

// MARK: - Вид виджета

struct PetWidgetView: View {
    @Environment(\.widgetFamily) private var family
    /// false — виджет показан без фона: так бывает в режиме StandBy
    @Environment(\.showsWidgetContainerBackground) private var showsBackground
    let entry: PetEntry

    var body: some View {
        let s = entry.state
        switch family {
        case .accessoryCircular:
            ZStack {
                AccessoryWidgetBackground()
                CatHead(state: s).padding(6)
            }
            .containerBackground(for: .widget) { Color.clear }

        case .accessoryRectangular:
            HStack(spacing: 8) {
                CatHead(state: s)
                    .frame(width: 40, height: 40)
                VStack(alignment: .leading, spacing: 1) {
                    Text("\(s.name) \(s.activity.emoji)")
                        .font(.headline)
                        .lineLimit(1)
                    Text(s.activity.status(toy: s.toy))
                        .font(.caption)
                        .lineLimit(2)
                }
                Spacer(minLength: 0)
            }
            .containerBackground(for: .widget) { Color.clear }

        case .systemSmall:
            if !showsBackground {
                // StandBy: только кошка, крупно, и она ходит по всей ширине
                CatRoom(state: s, widthShare: 0.75)
                    .padding(.horizontal, 4)
                    .containerBackground(for: .widget) { roomBackground }
            } else {
                VStack(spacing: 4) {
                    HStack {
                        Text(s.name).font(.caption.weight(.bold)).lineLimit(1)
                        Spacer(minLength: 0)
                        Text(s.activity.emoji).font(.caption)
                    }
                    CatRoom(state: s, widthShare: 0.8)
                    WidgetActionRow(compact: true)
                }
                .foregroundStyle(.white)
                .containerBackground(for: .widget) { roomBackground }
            }

        default: // medium и large — комната, по которой она переходит
            VStack(alignment: .leading, spacing: 6) {
                HStack(alignment: .firstTextBaseline) {
                    Text(s.name).font(.headline)
                    Text(s.activity.emoji)
                    Spacer(minLength: 0)
                    Text(s.phrase)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                }
                CatRoom(state: s, widthShare: 0.6)
                if family == .systemLarge {
                    StatusLine(state: s)
                }
                WidgetActionRow(compact: false)
            }
            .foregroundStyle(.white)
            .containerBackground(for: .widget) { roomBackground }
        }
    }

    private var roomBackground: some View {
        ZStack(alignment: .bottom) {
            LinearGradient(colors: [Color(hex: 0x3A2E58), Color(hex: 0x1A1428)],
                           startPoint: .top, endPoint: .bottom)
            // «пол»
            Rectangle()
                .fill(Color(hex: 0x2A2140))
                .frame(height: 40)
        }
    }
}

/// «Комната», по которой кошка ходит: место задаётся s.pos, шаги анимируются плавно.
struct CatRoom: View {
    let state: PetAttributes.ContentState
    /// какую долю ширины занимает сама кошка
    var widthShare: CGFloat

    var body: some View {
        GeometryReader { g in
            let h = g.size.height
            let w = min(g.size.width * widthShare, h * Sprite.box.width / Sprite.box.height)
            let x = w / 2 + CGFloat(state.pos) * (g.size.width - w)
            CatScene(state: state)
                .frame(width: w, height: h)
                // внутри кошки ничего не анимируется: кадры сменяются мгновенно
                .animation(nil, value: state)
                .position(x: x, y: h / 2)
                // плавно — только перемещение: 2,9 с на шаг при кадре раз в 3 с = почти без остановок
                .animation(.linear(duration: 2.9), value: state.pos)
        }
    }
}

struct WidgetActionRow: View {
    let compact: Bool

    var body: some View {
        HStack(spacing: compact ? 4 : 6) {
            button(.feed, "Еда", "fork.knife")
            button(.pet, "Гладить", "hand.raised.fill")
            button(.play, "Играть", "sparkles")
        }
        .tint(.catAccent)
    }

    @ViewBuilder
    private func button(_ action: PetAction, _ title: String, _ icon: String) -> some View {
        Button(intent: WidgetPetIntent(action: action)) {
            if compact {
                Image(systemName: icon)
                    .font(.caption)
                    .frame(maxWidth: .infinity)
            } else {
                Label(title, systemImage: icon)
                    .font(.caption2.weight(.semibold))
                    .frame(maxWidth: .infinity)
            }
        }
        .buttonStyle(.bordered)
    }
}

// MARK: - Сам виджет

struct PetHomeWidget: Widget {
    let kind = "PetHomeWidget"

    var body: some WidgetConfiguration {
        AppIntentConfiguration(kind: kind, intent: CatWidgetConfig.self, provider: PetProvider()) { entry in
            PetWidgetView(entry: entry)
        }
        .configurationDisplayName("Кошечка")
        .description("Живёт своей жизнью: спит, охотится, потягивается, смотрит в окно и иногда мяукает.")
        .supportedFamilies([.systemSmall, .systemMedium, .systemLarge, .accessoryRectangular, .accessoryCircular])
    }
}
