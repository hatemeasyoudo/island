import WidgetKit
import SwiftUI
import ActivityKit

@main
struct IslandPetsWidgetBundle: WidgetBundle {
    var body: some Widget {
        PetLiveActivity()
        PetHomeWidget()
    }
}

struct PetLiveActivity: Widget {
    var body: some WidgetConfiguration {
        ActivityConfiguration(for: PetAttributes.self) { context in
            // Экран блокировки и баннер
            LockScreenCatView(state: context.state)
                .activityBackgroundTint(Color(hex: 0x1E1830))
                .activitySystemActionForegroundColor(.white)
        } dynamicIsland: { context in
            let s = context.state
            return DynamicIsland {
                DynamicIslandExpandedRegion(.leading) {
                    CatScene(state: s, showEffects: false, small: true)
                        .frame(width: 70, height: 64)
                }
                DynamicIslandExpandedRegion(.trailing) {
                    Text(s.activity.emoji)
                        .font(.title2)
                        .padding(.trailing, 4)
                }
                DynamicIslandExpandedRegion(.center) {
                    VStack(spacing: 2) {
                        Text(s.name).font(.headline)
                        Text(s.phrase)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                            .lineLimit(2)
                            .multilineTextAlignment(.center)
                    }
                }
                DynamicIslandExpandedRegion(.bottom) {
                    VStack(spacing: 8) {
                        StatusLine(state: s)
                        ActionRow(state: s)
                    }
                    .padding(.horizontal, 4)
                }
            } compactLeading: {
                IslandCompactCat(state: s)
                    .frame(width: 34, height: 28)
            } compactTrailing: {
                IslandCompactTrailing(state: s)
            } minimal: {
                CatHead(state: s)
                    .frame(width: 22, height: 21)
            }
            .keylineTint(.catAccent)
        }
    }
}

struct LockScreenCatView: View {
    let state: PetAttributes.ContentState

    var body: some View {
        HStack(alignment: .center, spacing: 12) {
            CatScene(state: state, showEffects: false, small: true)
                .frame(width: 82, height: 76)
            VStack(alignment: .leading, spacing: 6) {
                HStack {
                    Text(state.name).font(.headline)
                    Text(state.activity.emoji)
                    Spacer()
                }
                Text(state.phrase)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
                StatusLine(state: state)
                ActionRow(state: state)
            }
        }
        .padding(14)
        .foregroundStyle(.white)
    }
}

/// Свёрнутый островок слева: картинка меняется раз в 3 минуты (если iOS обновила островок)
struct IslandCompactCat: View {
    let state: PetAttributes.ContentState

    var body: some View {
        Group {
            switch state.islandVariant {
            case 1:
                // вся кошка в текущей позе
                CatScene(state: state, showEffects: false, small: true)
            case 2:
                // мордочка выглядывает снизу, как из-за края островка
                CatHead(state: state)
                    .scaleEffect(1.5, anchor: .top)
                    .offset(y: 6)
                    .clipped()
            case 3:
                // лапка
                Image("isl_fx_paw").resizable().scaledToFit().padding(4)
            default:
                // мордочка по настроению
                CatHead(state: state)
            }
        }
        .id(state.islandVariant)
        .transition(.opacity)
    }
}

/// Свёрнутый островок справа: значок занятия или погода
struct IslandCompactTrailing: View {
    let state: PetAttributes.ContentState

    var body: some View {
        if state.islandVariant % 2 == 1, WeatherStore.current != nil {
            let w = WeatherStore.now()
            Text("\(Int(w.temperature.rounded()))°")
                .font(.caption2.weight(.semibold))
                .foregroundStyle(Color.catAccent)
        } else {
            Text(state.activity.emoji)
                .font(.caption)
        }
    }
}
