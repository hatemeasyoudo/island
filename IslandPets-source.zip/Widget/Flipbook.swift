import SwiftUI
import WidgetKit
import ClockHandRotationKit

// ЭКСПЕРИМЕНТ: покадровая анимация в виджете.
//
// iOS не даёт виджету проигрывать анимацию, но умеет непрерывно крутить «стрелку часов»
// (clockHandRotationEffect — недокументированная функция, ей пользуются виджеты с GIF).
// Все кадры лежат стопкой, каждый закрыт своим «сектором» огромного круга.
// Круг вращается как стрелка, и через окно виджета по очереди видно ровно один кадр.

struct Flipbook: View {
    let clip: Clip
    let size: CGSize

    var body: some View {
        let n = clip.widgetFrames.count
        ZStack {
            ForEach(0..<n, id: \.self) { i in
                Image(clip.widgetImage(clip.widgetFrames[i]))
                    .resizable()
                    .interpolation(.high)
                    .frame(width: size.width, height: size.height)
                    .mask {
                        WedgeMask(index: i, count: n, period: clip.widgetPeriod)
                    }
            }
        }
        .frame(width: size.width, height: size.height)
    }
}

/// Сектор огромного круга, центр которого далеко под картинкой.
/// Пока сектор «смотрит вверх», он целиком закрывает картинку — кадр виден.
struct WedgeMask: View {
    let index: Int
    let count: Int
    let period: Double

    var body: some View {
        GeometryReader { g in
            let R = max(g.size.width, g.size.height) * 40
            let step = 360.0 / Double(count)
            // против часовой — потому что «стрелка» крутится по часовой
            let center = -90.0 - Double(index) * step
            Wedge(from: center - step / 2 - 0.15, to: center + step / 2 + 0.15)
                .fill(Color.black)
                .frame(width: R * 2, height: R * 2)
                .clockHandRotationEffect(period: .custom(period), in: .current, anchor: .center)
                .position(x: g.size.width / 2, y: g.size.height / 2 + R)
        }
    }
}

struct Wedge: Shape {
    let from: Double
    let to: Double

    func path(in r: CGRect) -> Path {
        var p = Path()
        let c = CGPoint(x: r.midX, y: r.midY)
        p.move(to: c)
        p.addArc(center: c, radius: r.width / 2 * 0.75,
                 startAngle: .degrees(from), endAngle: .degrees(to), clockwise: false)
        p.closeSubpath()
        return p
    }
}

/// Аниматор для CatScene
let widgetFlipbook: ClipAnimator = { clip, size in
    AnyView(Flipbook(clip: clip, size: size))
}
